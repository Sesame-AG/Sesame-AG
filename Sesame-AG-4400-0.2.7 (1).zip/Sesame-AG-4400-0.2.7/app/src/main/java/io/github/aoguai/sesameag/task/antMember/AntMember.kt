package io.github.aoguai.sesameag.task.antMember

import io.github.aoguai.sesameag.task.antFarm.AntFarmRpcCall
import io.github.aoguai.sesameag.task.antForest.AntForest
import io.github.aoguai.sesameag.task.antOcean.AntOcean
import io.github.aoguai.sesameag.model.Model

import android.annotation.SuppressLint
import io.github.aoguai.sesameag.data.Status
import io.github.aoguai.sesameag.data.Status.Companion.canMemberPointExchangeBenefitToday
import io.github.aoguai.sesameag.data.Status.Companion.canMemberSignInToday
import io.github.aoguai.sesameag.data.Status.Companion.hasFlagToday
import io.github.aoguai.sesameag.data.Status.Companion.memberPointExchangeBenefitToday
import io.github.aoguai.sesameag.data.Status.Companion.memberSignInToday
import io.github.aoguai.sesameag.data.Status.Companion.setFlagToday
import io.github.aoguai.sesameag.data.StatusFlags
import io.github.aoguai.sesameag.entity.MapperEntity
import io.github.aoguai.sesameag.hook.AccountSessionCoordinator
import io.github.aoguai.sesameag.hook.ApplicationHook
import io.github.aoguai.sesameag.hook.ApplicationHookConstants
import io.github.aoguai.sesameag.hook.ExchangeOptionsRefreshBridge
import io.github.aoguai.sesameag.hook.HookReadyChecker
import io.github.aoguai.sesameag.hook.keepalive.PersistentScheduleKind
import io.github.aoguai.sesameag.hook.keepalive.PersistentScheduleRegistry
import io.github.aoguai.sesameag.hook.keepalive.PersistentScheduleState
import io.github.aoguai.sesameag.hook.keepalive.ScheduledTaskRouter
import io.github.aoguai.sesameag.hook.keepalive.UnifiedScheduler
import io.github.aoguai.sesameag.hook.internal.LocationHelper
import io.github.aoguai.sesameag.hook.internal.LocationHelper.requestLocationSuspend
import io.github.aoguai.sesameag.model.ModelFields
import io.github.aoguai.sesameag.model.ModelGroup
import io.github.aoguai.sesameag.model.withDesc
import io.github.aoguai.sesameag.model.modelFieldExt.BooleanModelField
import io.github.aoguai.sesameag.model.modelFieldExt.SelectModelField
import io.github.aoguai.sesameag.task.ModelTask
import io.github.aoguai.sesameag.task.TaskExecutionOutcome
import io.github.aoguai.sesameag.task.TaskExecutionReport
import kotlin.coroutines.EmptyCoroutineContext
import io.github.aoguai.sesameag.task.antOrchard.UrlUtil
import io.github.aoguai.sesameag.task.exchange.ExchangeCost
import io.github.aoguai.sesameag.hook.rpc.RpcDailyCircuit
import io.github.aoguai.sesameag.task.exchange.ExchangeEffectCatalog
import io.github.aoguai.sesameag.task.exchange.ExchangeEffectNeed
import io.github.aoguai.sesameag.task.exchange.ExchangeFetchPacing
import io.github.aoguai.sesameag.task.exchange.ExchangeItem
import io.github.aoguai.sesameag.task.exchange.ExchangeLimit
import io.github.aoguai.sesameag.task.exchange.ExchangeOptionRow
import io.github.aoguai.sesameag.task.exchange.ExchangeOptionsCache
import io.github.aoguai.sesameag.task.exchange.ExchangeOptionsSnapshot
import io.github.aoguai.sesameag.task.exchange.ExchangeReplenishResult
import io.github.aoguai.sesameag.task.exchange.ExchangeReplenisher
import io.github.aoguai.sesameag.task.exchange.ExchangeSafety
import io.github.aoguai.sesameag.task.exchange.ExchangeSafetyRules
import io.github.aoguai.sesameag.task.common.DeferredReason
import io.github.aoguai.sesameag.task.common.GameCenterPlayRpcCall
import io.github.aoguai.sesameag.task.common.NonDurationGameTask
import io.github.aoguai.sesameag.task.common.TaskFlowAction
import io.github.aoguai.sesameag.task.common.TaskFlowActionResult
import io.github.aoguai.sesameag.task.common.TaskFlowAdapter
import io.github.aoguai.sesameag.task.common.TaskFlowDecision
import io.github.aoguai.sesameag.task.common.TaskFlowEngine
import io.github.aoguai.sesameag.task.common.TaskFlowExecutionState
import io.github.aoguai.sesameag.task.common.TaskFlowItem
import io.github.aoguai.sesameag.task.common.TaskFlowPhase
import io.github.aoguai.sesameag.task.common.TaskFlowRunResult
import io.github.aoguai.sesameag.task.common.TaskFlowSnapshot
import io.github.aoguai.sesameag.task.common.TaskRpcFailureType
import io.github.aoguai.sesameag.util.CoroutineUtils
import io.github.aoguai.sesameag.util.Log
import io.github.aoguai.sesameag.util.Log.record
import io.github.aoguai.sesameag.util.ResChecker
import io.github.aoguai.sesameag.util.RpcOfflineRisk
import io.github.aoguai.sesameag.util.TaskBlacklist
import io.github.aoguai.sesameag.util.UserDataStoreManager
import io.github.aoguai.sesameag.util.TimeUtil
import io.github.aoguai.sesameag.util.maps.IdMapManager
import io.github.aoguai.sesameag.util.maps.BeanExchangeRightMap
import io.github.aoguai.sesameag.util.maps.MemberBenefitsMap
import io.github.aoguai.sesameag.util.maps.UserMap
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.runBlocking
import io.github.aoguai.sesameag.util.SerialTaskQueue

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.regex.Pattern
import kotlin.math.max

private fun isMemberMarketingRpcRisk(source: String, response: JSONObject): Boolean {
    return isMemberMarketingRpcRisk(
        source,
        RpcOfflineRisk.extractCode(response),
        RpcOfflineRisk.extractMessage(response)
    )
}

private fun isMemberMarketingRpcRisk(source: String, code: String, message: String): Boolean {
    if (!RpcOfflineRisk.isOfflineRisk(code, message)) {
        return false
    }
    RpcOfflineRisk.enterOfflineIfNeeded(source, code, message)
    return true
}

private fun stopMemberCoreTasksForRpcRisk(source: String, response: JSONObject): Boolean {
    val code = RpcOfflineRisk.extractCode(response)
    val sourceMethod = response.optString("offlineSourceMethod")
    // I07 保留的源错误只属于触发离线的那次请求，不能归因于随后被离线拦截的请求。
    if (code == "I07" && sourceMethod.isNotBlank() && sourceMethod == response.optString("rpcMethod")) {
        return stopMemberCoreTasksForRpcRisk(
            source,
            response.optString("offlineSourceCode"),
            response.optString("offlineSourceMessage")
        )
    }
    return stopMemberCoreTasksForRpcRisk(source, code, RpcOfflineRisk.extractMessage(response))
}

private fun stopMemberCoreTasksForRpcRisk(source: String, code: String, message: String): Boolean {
    if (!isMemberMarketingRpcRisk(source, code, message)) {
        return false
    }
    Log.member("会员签到/任务[$source]#检测到风控/验证，停止当前执行:$code/${message.take(160)}")
    return true
}

class AntMember : ModelTask() {
    override fun getName(): String {
        return "会员"
    }

    override fun getGroup(): ModelGroup {
        return ModelGroup.MEMBER
    }

    override fun getIcon(): String {
        return "AntMember.png"
    }

    internal var memberSign: BooleanModelField? = null
    internal var memberTask: BooleanModelField? = null
    private var memberSignPageTask: BooleanModelField? = null
    private var memberSignInAdTask: BooleanModelField? = null
    internal var yebExpGold: BooleanModelField? = null
    internal var memberPointExchangeBenefit: BooleanModelField? = null
    private var memberPointExchangeBenefitList: SelectModelField? = null
    private var collectInsuredGold: BooleanModelField? = null
    private var enableGameCenter: BooleanModelField? = null
    private var expressWelfare: BooleanModelField? = null
    internal var merchantSign: BooleanModelField? = null
    internal var merchantKmdk: BooleanModelField? = null
    internal var merchantMoreTask: BooleanModelField? = null
    internal var beanSignIn: BooleanModelField? = null
    internal var beanExchangeRight: BooleanModelField? = null
    internal var beanDrawPrize: BooleanModelField? = null
    private var beanExchangeRightList: SelectModelField? = null



    // 黄金票配置 - 签到
    internal var enableGoldTicket: BooleanModelField? = null

    // 黄金票配置 - 提取/兑换
    internal var enableGoldTicketConsume: BooleanModelField? = null

    /** 账单贴纸领取功能开关 */
    private var collectStickers: BooleanModelField? = null

    /** 账单拼贴世界自动推进功能开关 */
    private var billBlockWorld: BooleanModelField? = null
    private var billCoinExchangeList: SelectModelField? = null

    private val goldTicketTaskBlacklistModule = "黄金票"
    private val beanTaskCenterHandledLimitCodes = setOf(
        "10001013",
        "10001033",
        "10001034",
        "10001043",
        "10001044"
    )


    private enum class MemberTaskTargetBusinessType {
        BROWSE,
        CALL_APP,
        UNSUPPORTED
    }

    private data class ResolvedMemberTaskTargetBusiness(
        val raw: String = "",
        val type: MemberTaskTargetBusinessType = MemberTaskTargetBusinessType.UNSUPPORTED
    )

    private data class CurrentMemberTask(
        val taskConfigId: String,
        val taskProcessId: String,
        val title: String,
        val awardPoint: String,
        val targetBusiness: String,
        val targetBusinessType: MemberTaskTargetBusinessType = MemberTaskTargetBusinessType.UNSUPPORTED,
        val simpleTaskConfig: JSONObject,
        val adBizId: String,
        val status: String = "",
        val current: Int? = null,
        val limit: Int? = null
    )

    private data class MemberTaskProcessAward(
        val taskProcessId: String,
        val awardRelatedOutBizNo: String,
        val title: String,
        val awardPoint: Int,
        val stageIndex: Int
    )

    private enum class CurrentMemberTaskVerifyState {
        CONFIRMED,
        PARTIAL_REPEATABLE,
        UNCONFIRMED
    }

    private enum class CurrentMemberTaskListProcessState {
        COMPLETED,
        HANDLED_PENDING_CONFIRM,
        NO_ACTIONABLE_TASK,
        RETRY_LATER,
        NO_TASK,
        UNKNOWN
    }

    internal val memberFloatingBallQueue = SerialTaskQueue()

    private data class MemberFloatingBallTaskRef(
        val bizNo: String,
        val taskType: String,
        val adTaskType: String,
        val taskStatus: String,
        val endDt: Long,
        val executeTimeSeconds: Long
    )

    private enum class MemberFloatingBallTaskProcessState {
        PROCESSED,
        NO_TASK,
        RETRY_LATER,
        STOPPED_TODAY,
        UNKNOWN
    }


    private data class StickerFollowUpResult(
        val success: Boolean = true,
        val handled: Boolean = false
    )

    private data class MemberExchangeCandidate(
        val item: ExchangeItem,
        val benefitId: String,
        val itemId: String,
        val pointNeeded: String,
        val benefitMark: String,
        val itemSource: String,
        val requestSourceInfo: String = "",
        val sourcePassMap: JSONObject? = null
    )

    private data class BeanExchangeCandidate(
        val item: ExchangeItem,
        val rightsId: String,
        val assetAmount: Int,
        val needOrder: Int,
        val rightsMetaSubType: String
    )

    private enum class StickerRpcFailureType {
        BUSINESS_LIMIT,
        DUPLICATE_REWARD,
        NON_RETRYABLE
    }

    private enum class DailyTaskProcessResult {
        HANDLED,
        PENDING,
        RETRYABLE_FAILURE,
        UNKNOWN_FAILURE
    }

    private data class InsuredTaskCenterConfig(
        val taskCenterId: String,
        val sceneCode: String,
        val controlSolutionSceneCode: String? = null
    )

    private data class InsuredGoldCollectionPassResult(
        val availableCount: Int,
        val result: DailyTaskProcessResult
    )

    private data class BeanTaskCenterTaskListScanResult(
        val taskCount: Int,
        val result: DailyTaskProcessResult,
        val hasGuardianQuizCandidate: Boolean = false
    )

    private data class BeanTaskCenterScanResult(
        val taskCount: Int,
        val result: DailyTaskProcessResult,
        val hasGuardianQuizCandidate: Boolean
    )

    private data class BeanGuardianQuestion(
        val scriptId: String,
        val userDramaId: String,
        val rightAnswer: String,
        val sort: Int,
        val answerResult: String,
        val awardStatus: String,
        val questionText: String
    )

    private data class BeanGuardianQuestionDrama(
        val dramaId: String,
        val nextScriptId: String,
        val questions: List<BeanGuardianQuestion>
    )

    private enum class InsuredGoldRpcFailureType {
        BUSINESS_LIMIT,
        DUPLICATE_REWARD,
        RETRYABLE,
        NON_RETRYABLE
    }

    private enum class GuardianBeanAwardRpcFailureType {
        BUSINESS_LIMIT,
        DUPLICATE_REWARD,
        RETRYABLE,
        NON_RETRYABLE
    }

    private data class GoldTicketTaskFlowHandleResult(
        val querySuccess: Boolean,
        val canMarkDone: Boolean
    )

    private data class GameCenterPlatformTaskSnapshot(
        val taskId: String,
        val title: String,
        val subTitle: String,
        val status: String,
        val buttonText: String,
        val needSignUp: Boolean,
        val gameId: String,
        val appId: String,
        val pointAmount: Int
    )

    private data class GameCenterP2eQuerySnapshot(
        val source: String,
        val success: Boolean,
        val rawResponse: String,
        val responseObject: JSONObject
    )

    private val insuredTaskCenterConfigs = listOf(
        InsuredTaskCenterConfig("AP16236844", "TASK_LIST", "GIFT_GOLD_NORMAL_TASK_CONTROL"),
        InsuredTaskCenterConfig("AP19236833", "TOP_LIST", "GIFT_GOLD_TOP_TASK_CONTROL"),
        InsuredTaskCenterConfig("AP19301319", "BZJ_SWAP_TASK_CONSULT_CONTROL", "BZJ_SWAP_TASK_CONSULT_CONTROL"),
        InsuredTaskCenterConfig("AP12301346", "BZJ_SOFT_TASK_CONSULT_CONTROL", "BZJ_SOFT_TASK_CONSULT_CONTROL"),
        InsuredTaskCenterConfig("AP14273842", "BZJ_XUBAO_TASK_CONSULT")
    )

    override fun getFields(): ModelFields {
        val modelFields = ModelFields()
        modelFields.addField(BooleanModelField("memberSign", "会员积分 | 签到", false).withDesc(
            "执行会员中心每日签到并领取会员积分。"
        ).also {
            memberSign = it
        })
        modelFields.addField(BooleanModelField("memberTask", "会员积分 | 任务", false).withDesc(
            "执行会员浮球与阶段任务，完成后统一领取会员积分。"
        ).also {
            memberTask = it
        })
        modelFields.addField(BooleanModelField("memberSignPageTask", "会员积分 | 签到页任务", false).withDesc(
            "需开启“会员积分 | 任务”。查询并处理签到页任务。"
        ).also {
            memberSignPageTask = it
        })
        modelFields.addField(BooleanModelField("memberSignInAdTask", "会员积分 | 签到广告任务", false).withDesc(
            "需开启“会员积分 | 任务”。查询并处理签到广告任务。"
        ).also {
            memberSignInAdTask = it
        })
        modelFields.addField(BooleanModelField("yebExpGold", "余额宝体验金", false).withDesc(
            "处理余额宝体验金签到、可自动完成任务、待使用券和兑换。"
        ).also {
            yebExpGold = it
        })



        modelFields.addField(
            BooleanModelField(
                "memberPointExchangeBenefit", "会员积分 | 兑换权益", false
            ).withDesc("按“会员积分 | 兑换列表”处理已勾选权益；仅纯积分虚拟道具自动兑换，实付或下单权益只记录提醒。").also { memberPointExchangeBenefit = it })
        modelFields.addField(
            SelectModelField(
                "memberPointExchangeBenefitList",
                "会员积分 | 兑换列表",
                LinkedHashSet<String?>()
            ) {
                refreshMemberPointExchangeOptionsForSettings()
            }.withDesc("勾选需要处理的会员权益。需开启“会员积分 | 兑换权益”。").also { memberPointExchangeBenefitList = it })




        modelFields.addField(
            BooleanModelField(
                "collectInsuredGold", "蚂蚁保 | 保障金领取", false
            ).withDesc("领取蚂蚁保页面可收取的签到保障金和活动保障金。").also { collectInsuredGold = it })

        // 黄金票配置
        modelFields.addField(
            BooleanModelField(
                "enableGoldTicket", "黄金票 | 签到与收取", false
            ).withDesc("执行黄金票首页签到与日常收取，持续累积黄金票。").also { enableGoldTicket = it })
        modelFields.addField(
            BooleanModelField(
                "enableGoldTicketConsume", "黄金票 | 提取/兑换黄金", false
            ).withDesc("黄金票达到提取条件后自动兑换或提取黄金。").also { enableGoldTicketConsume = it })
        modelFields.addField(BooleanModelField("enableGameCenter", "游戏中心 | 签到", false).withDesc(
            "执行游戏中心签到、平台与外部游戏任务，领取玩乐豆和待领宝箱。"
        ).also {
            enableGameCenter = it
        })
        modelFields.addField(BooleanModelField("expressWelfare", "我的快递 | 福利任务", false)
            .withDesc("执行推荐与普通福利任务，领取积分、肥料、森林活力值和海洋碎片。")
            .also { expressWelfare = it })
        modelFields.addField(
            BooleanModelField(
                "merchantSign", "商家服务 | 签到", false
            ).withDesc("执行商家服务每日签到，包含可领取时会顺带处理招财金签到积分。").also { merchantSign = it })
        modelFields.addField(
            BooleanModelField(
                "merchantKmdk", "商家服务 | 开门打卡", false
            ).withDesc("执行商家服务开门打卡的报名与上午签到，需在可用时段内运行。").also { merchantKmdk = it })
        modelFields.addField(
            BooleanModelField(
                "merchantMoreTask", "商家服务 | 积分任务", false
            ).withDesc("执行商家服务积分任务，并顺带领取任务产出的积分球奖励。").also {
                merchantMoreTask = it
            })
        modelFields.addField(
            BooleanModelField(
                "beanSignIn", "安心豆 | 签到", false
            ).withDesc("执行安心豆每日签到，领取当天可得的安心豆奖励。").also { beanSignIn = it })
        modelFields.addField(
            BooleanModelField(
                "beanExchangeRight", "安心豆 | 兑换权益", false
            ).withDesc("按“安心豆 | 兑换列表”刷新并处理安心豆权益；涉及下单或外跳的权益只记录提醒。").also { beanExchangeRight = it })
        modelFields.addField(
            BooleanModelField(
                "beanDrawPrize", "安心豆 | 抽奖", false
            ).withDesc("查询并参与安心豆抽奖计划，每次消耗 1 豆，抽得现金红包自动到账。").also { beanDrawPrize = it })
        modelFields.addField(
            SelectModelField(
                "beanExchangeRightList",
                "安心豆 | 兑换列表",
                LinkedHashSet<String?>()
            ) {
                refreshBeanExchangeRightOptionsForSettings()
            }.withDesc("勾选允许处理的安心豆权益，需开启“安心豆 | 兑换权益”。").also { beanExchangeRightList = it })


        modelFields.addField(
            BooleanModelField("CollectStickers", "账单贴纸 | 领取", false).withDesc(
                "扫描并领取当前账单周期内可领取的贴纸奖励。"
            ).also { collectStickers = it }
        )
        modelFields.addField(SelectModelField(
            "billCoinExchangeList", "账单贴贴币 | 权益目录", LinkedHashSet<String?>()
        ) { loadBillCoinOptionsForSettings() }
            .withDesc("查看商品与兑换条件。")
            .also { billCoinExchangeList = it })
        modelFields.addField(
            BooleanModelField("billBlockWorld", "账单拼贴世界 | 自动推进", false).withDesc(
                "使用已有免费贴纸推进章节和繁荣度；允许为章节或新贴纸腾空间而移动、合成、回收原有画布贴纸，不购买贴纸、不新增消费。"
            ).also { billBlockWorld = it }
        )



        return modelFields
    }

    override fun runJava() {
        runBlocking(TaskExecutionReport.current()?.context ?: EmptyCoroutineContext) {
            try {
                Log.member("执行开始-${getName()}")
                requestLocationSuspend()

                val deferredTasks = mutableListOf<Deferred<Unit>>()
                val memberPointPlan = prepareMemberPointWorkflows(this, deferredTasks)

                if (collectInsuredGold?.value == true) {
                    deferredTasks.add(async(Dispatchers.IO) { collectInsuredGold() })
                }

                scheduleGoldTicketWorkflows(this, deferredTasks)

                if (enableGameCenter?.value == true) {
                    deferredTasks.add(async(Dispatchers.IO) {
                        enableGameCenter()
                        memberFloatingBallQueue.submit { runExternalGameCenter() }
                    })
                }
                if (expressWelfare?.value == true) {
                    deferredTasks.add(async(Dispatchers.IO) { doExpressWelfare() })
                }


                scheduleBeanWorkflows(this, deferredTasks)
                scheduleMerchantWorkflows(this, deferredTasks)

                if (collectStickers?.value == true) {
                    queryAndCollectStickers()
                }
                if (billBlockWorld?.value == true) {
                    runBillBlockWorld()
                }

                deferredTasks.awaitAll()
                finishMemberPointWorkflows(memberPointPlan)

            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                TaskExecutionReport.current()?.recordException()
                Log.printStackTrace(TAG, t)
            } finally {
                Log.member("执行结束-${getName()}")
            }
        }
    }

    private fun doExpressWelfare() {
        for (recommended in listOf(true, false)) {
            if (ApplicationHookConstants.isOffline()) return
            try {
                val adapter = ExpressTaskFlowAdapter(recommended)
                TaskFlowEngine(adapter, executionState = adapter.executionState).run()
            } catch (t: Throwable) {
                if (t is CancellationException || t is InterruptedException) throw t
                Log.printStackTrace(TAG, "我的快递福利任务失败", t)
            }
        }
    }

    private inner class ExpressTaskFlowAdapter(private val recommended: Boolean) : TaskFlowAdapter {
        override val moduleName = "AntMember"
        override val flowName = if (recommended) "快递推荐福利" else "快递普通福利"
        override val continueCurrentRoundOnRetryableFailure = true
        val executionState = TaskFlowExecutionState()
        private val signedUp = mutableSetOf<String>()
        private val rewardFlows = mutableMapOf<String, Pair<TaskFlowAdapter, TaskFlowExecutionState>>()

        override fun query(): JSONObject = JSONObject(AntMemberRpcCall.queryExpressTasks(recommended))
        override fun isQuerySuccess(response: JSONObject): Boolean = ResChecker.checkRes(TAG, response)
        override fun isQueryComplete(response: JSONObject): Boolean = response.optJSONArray("taskDetailList") != null

        override fun extractItems(response: JSONObject): List<TaskFlowItem> {
            val list = response.optJSONArray("taskDetailList") ?: return emptyList()
            return (0 until list.length()).mapNotNull { index ->
                val task = list.optJSONObject(index) ?: return@mapNotNull null
                val material = task.optJSONObject("taskMaterial")
                val type = material?.optString("taskCode").orEmpty()
                val id = task.optString("taskId").ifBlank { task.optString("appletId") }
                TaskFlowItem(
                    id = id,
                    title = task.optJSONObject("taskBaseInfo")?.optString("appletName").orEmpty().ifBlank { id },
                    status = task.optString("taskProcessStatus"), type = type, raw = task,
                    progress = "${task.optString("taskProcessStatus")}:${task.optBoolean("canAccess")}",
                )
            }
        }

        override fun isBlacklisted(item: TaskFlowItem): Boolean = isMemberTaskInBlacklist(item.id, item.title)

        override fun mapPhase(item: TaskFlowItem): TaskFlowPhase {
            val task = item.raw ?: return TaskFlowPhase.UNKNOWN
            if (item.id.isBlank()) return TaskFlowPhase.UNKNOWN
            if (item.status == "RECEIVE_SUCCESS") return TaskFlowPhase.TERMINAL
            if (executionState.pendingActionConfirmations.values.any { (previous, action) ->
                    previous.id == item.id && previous.progress == item.progress &&
                        action in setOf(TaskFlowAction.SIGNUP, TaskFlowAction.SEND)
                }) signedUp.add(item.id)
            if (item.status == "SIGNUP_EXPIRED") {
                return when {
                    item.id in signedUp -> TaskFlowPhase.SIGNUP_COMPLETE
                    task.optBoolean("canAccess") -> TaskFlowPhase.SIGNUP_REQUIRED
                    else -> TaskFlowPhase.BUSINESS_ACTION
                }
            }
            if (recommended) return if (task.optBoolean("canAccess")) TaskFlowPhase.SIGNUP_COMPLETE else TaskFlowPhase.TERMINAL
            if (task.optString("sendCampTriggerType") == "EVENT_TRIGGER") return TaskFlowPhase.BUSINESS_ACTION
            return if (item.status == "SIGNUP_COMPLETE" || item.id in signedUp) TaskFlowPhase.SIGNUP_COMPLETE
                else TaskFlowPhase.SIGNUP_REQUIRED
        }

        override fun shouldSkip(item: TaskFlowItem): Boolean =
            !recommended && item.raw?.optString("sendCampTriggerType") == "EVENT_TRIGGER"
        override fun isUnresolvedWhenSkipped(item: TaskFlowItem): Boolean = true

        override fun signup(item: TaskFlowItem): TaskFlowActionResult {
            val response = JSONObject(AntMemberRpcCall.triggerExpressTask(item.id, "signup"))
            if (!ResChecker.checkRes(TAG, response)) return failed(response, "signup")
            signedUp.add(item.id)
            return TaskFlowActionResult.success(refreshAfterAction = true, progressChanged = false)
        }

        override fun send(item: TaskFlowItem): TaskFlowActionResult {
            if (recommended && item.type in setOf("WELFARE_PLUS_ANT_FOREST", "WELFARE_PLUS_ANT_OCEAN")) {
                val (adapter, state) = rewardFlows.getOrPut(item.type) {
                    val adapter = if (item.type == "WELFARE_PLUS_ANT_FOREST") {
                        Model.getModel(AntForest::class.java)?.expressTaskFlowAdapter()
                    } else {
                        Model.getModel(AntOcean::class.java)?.expressTaskFlowAdapter()
                    } ?: return TaskFlowActionResult.failure(
                        TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW, message = "快递奖励所属模块不可用",
                        continueCurrentRoundOnFailure = true,
                    )
                    adapter to TaskFlowExecutionState()
                }
                val result = TaskFlowEngine(adapter, roundSleepMs = 425L, executionState = state).run()
                // 子流程独立保留真实失败；父流程回查入口，不重复记同一错误。
                if (!result.completed || result.failureCount > 0 || result.interrupted) {
                    return TaskFlowActionResult.defer(
                        DeferredReason.STATE_CONFIRMATION, "回查快递与所属奖励任务状态",
                        refreshAfterAction = !result.interrupted, stopCurrentRound = result.interrupted,
                    )
                }
                if (item.type == "WELFARE_PLUS_ANT_FOREST" ||
                    item.raw?.optString("sendCampTriggerType") == "EVENT_TRIGGER"
                ) {
                    return TaskFlowActionResult.defer(
                        DeferredReason.STATE_CONFIRMATION, "所属奖励流程已查询，等待快递事件任务回查确认",
                        refreshAfterAction = true,
                    )
                }
            }
            if (item.raw?.optString("sendCampTriggerType") == "EVENT_TRIGGER") {
                return TaskFlowActionResult.defer(
                    DeferredReason.PREREQUISITE_PENDING, "快递任务需所属业务事件触发发奖",
                )
            }
            val response = JSONObject(AntMemberRpcCall.triggerExpressTask(item.id, "send"))
            if (!ResChecker.checkRes(TAG, response)) return failed(response, "send")
            val prizes = response.optJSONArray("prizeSendInfo")
            val names = (0 until (prizes?.length() ?: 0)).mapNotNull { prizes?.optJSONObject(it) }
                .map { it.optString("prizeName").ifBlank { it.optJSONObject("extInfo")?.optString("promoCampName").orEmpty() } }
                .filter { it.isNotBlank() }
            Log.member("我的快递[${item.title}]发奖已受理 ${names.joinToString("、")}")
            return TaskFlowActionResult.success(progressChanged = false)
        }

        private fun failed(response: JSONObject, stage: String): TaskFlowActionResult = TaskFlowActionResult.failure(
            TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW, code = extractMemberDomainRpcCode(response),
            message = extractMemberDomainRpcMessage(response), rpc = "快递福利.$stage", raw = response.toString(),
            continueCurrentRoundOnFailure = true,
        )

        override fun logInfo(message: String) = Log.member(message)
        override fun logError(message: String) = Log.error(TAG, message)
    }

    internal suspend fun runMerchantWorkflow() {
        val needKmdkSignIn =
            merchantKmdk?.value == true &&
                !hasFlagToday(StatusFlags.FLAG_ANTMEMBER_MERCHANT_KMDK_SIGNIN_DONE) &&
                TimeUtil.isNowAfterTimeStr("0600") &&
                TimeUtil.isNowBeforeTimeStr("1200")
        val needKmdkSignUp =
            merchantKmdk?.value == true &&
                !hasFlagToday(StatusFlags.FLAG_ANTMEMBER_MERCHANT_KMDK_SIGNUP_DONE)
        val needMerchantSign =
            merchantSign?.value == true &&
                !hasFlagToday(StatusFlags.FLAG_ANTMEMBER_MERCHANT_SIGN_DONE)
        val needMerchantMoreTask =
            merchantMoreTask?.value == true &&
                !hasFlagToday(StatusFlags.FLAG_ANTMEMBER_MERCHANT_MORE_TASK_DONE)

        if (!(needKmdkSignIn || needKmdkSignUp || needMerchantSign || needMerchantMoreTask)) {
            Log.member("⏭️ 今天已处理过商家服务相关任务，跳过执行")
            return
        }

        if (!canRunMerchantService()) {
            return
        }

        if (needMerchantSign) {
            if (doMerchantSign()) {
                setFlagToday(StatusFlags.FLAG_ANTMEMBER_MERCHANT_SIGN_DONE)
                collectMerchantPointBalls()
            }
        }
        if (needMerchantMoreTask) {
            doMerchantMoreTask()
        }
        if (merchantKmdk?.value == true && (needKmdkSignIn || needKmdkSignUp)) {
            if (needKmdkSignIn) {
                if (kmdkSignIn()) {
                    setFlagToday(StatusFlags.FLAG_ANTMEMBER_MERCHANT_KMDK_SIGNIN_DONE)
                }
            } else if (TimeUtil.isNowAfterTimeStr("1200")) {
                setFlagToday(StatusFlags.FLAG_ANTMEMBER_MERCHANT_KMDK_SIGNIN_DONE)
            }
            if (needKmdkSignUp) {
                if (kmdkSignUp()) {
                    setFlagToday(StatusFlags.FLAG_ANTMEMBER_MERCHANT_KMDK_SIGNUP_DONE)
                }
            }
        }
    }


    /**
     * 会员积分0元兑，权益道具兑换
     */
    private fun refreshMemberPointExchangeOptionsForSettings(): List<MapperEntity> {
        val freshRows = ExchangeOptionsCache.loadTodaySnapshot(
            UserMap.currentUid, ExchangeOptionsRefreshBridge.TARGET_MEMBER_POINT
        )?.rows
        if (freshRows != null) {
            Log.member("会员积分🎐设置页使用新鲜缓存#${freshRows.size}")
            return freshRows
        }
        if (!HookReadyChecker.isCurrentProcessReadyForRpc(UserMap.currentUid)) {
            val cachedRows = ExchangeOptionsCache.loadForSettingsCache(
                UserMap.currentUid,
                ExchangeOptionsRefreshBridge.TARGET_MEMBER_POINT
            )
            if (!HookReadyChecker.isTargetAppReadyForRpc(UserMap.currentUid)) {
                Log.member("会员积分🎐目标应用未就绪，设置页先展示上次缓存列表；请打开目标应用后再刷新#${cachedRows.size}")
                return cachedRows
            }
            val refreshResult = ExchangeOptionsRefreshBridge.requestRefreshOptions(
                ExchangeOptionsRefreshBridge.TARGET_MEMBER_POINT,
                UserMap.currentUid
            )
            if (refreshResult.success) {
                Log.member("会员积分🎐设置页使用目标应用刷新列表#${refreshResult.options.size}")
                return refreshResult.options
            }
            if (cachedRows.isNotEmpty()) {
                Log.member("会员积分🎐远程刷新失败，设置页回退上次缓存快照#${cachedRows.size}#${refreshResult.message}")
                return cachedRows
            }
            Log.member("会员积分🎐远程刷新失败，且无可用缓存快照#${refreshResult.message}")
            return emptyList()
        }
        val rowsResult = runCatching {
            refreshMemberPointExchangeOptionsFromRpc()
        }.onFailure {
            Log.printStackTrace(TAG, "refreshMemberPointExchangeOptionsForSettings.currentRpc err:", it)
        }
        val rows = rowsResult.getOrElse { throwable ->
            val cachedRows = ExchangeOptionsCache.loadForSettingsCache(
                UserMap.currentUid,
                ExchangeOptionsRefreshBridge.TARGET_MEMBER_POINT
            )
            if (cachedRows.isNotEmpty()) {
                Log.member("会员积分🎐当前进程刷新失败，设置页回退上次缓存快照#${cachedRows.size}#${throwable.message}")
                cachedRows
            } else {
                Log.member("会员积分🎐当前进程刷新失败，且无可用缓存快照#${throwable.message}")
                emptyList()
            }
        }
        Log.member("会员积分🎐设置页刷新结构化列表#${rows.size}")
        return rows
    }

    private fun refreshMemberPointExchangeOptionsFromRpc(forceRefresh: Boolean = false): List<ExchangeOptionRow> {
        val userId = UserMap.currentUid
        val candidateMap = queryMemberExchangeCandidates(userId, null, 850L, forceRefresh = forceRefresh)
        val memberBenefitMap = IdMapManager.getInstance(MemberBenefitsMap::class.java)
        memberBenefitMap.load(userId)
        candidateMap.values.forEach { memberBenefitMap.add(it.item.id, it.item.displayName()) }
        memberBenefitMap.save(userId)
        return candidateMap.values.map { it.item.toOptionRow() }
    }

    internal fun refreshMemberPointExchangeOptionsForRemote(forceRefresh: Boolean = false): List<ExchangeOptionRow> =
        refreshMemberPointExchangeOptionsFromRpc(forceRefresh)

    private fun queryMemberExchangeCandidates(
        userId: String?,
        pointBalance: String?,
        sleepMillis: Long = 0L,
        forceRefresh: Boolean = false,
        onFailure: ((TaskFlowActionResult) -> Unit)? = null,
    ): LinkedHashMap<String, MemberExchangeCandidate> {
        fun parse(payload: JSONObject): LinkedHashMap<String, MemberExchangeCandidate> {
            val candidates = LinkedHashMap<String, MemberExchangeCandidate>()
            val shandie = payload.getJSONArray("shandie")
            for (i in 0 until shandie.length()) {
                addMemberExchangeCandidates(shandie.getJSONObject(i).getJSONArray("benefits"), candidates)
            }
            val delivery = payload.getJSONArray("delivery")
            for (i in 0 until delivery.length()) {
                val page = delivery.getJSONObject(i)
                val response = page.getJSONObject("response")
                val pageNum = page.getInt("pageNum")
                val uniqueId = page.getString("uniqueId")
                addMemberExchangeCandidates(response.optJSONArray("briefConfigInfos"), candidates, pageNum, 18, uniqueId)
                addMemberExchangeEntityCandidates(response.optJSONArray("entityInfoList"), candidates, pageNum, 18, uniqueId)
            }
            val navi = payload.optJSONArray("navi") ?: JSONArray()
            for (i in 0 until navi.length()) {
                val page = navi.getJSONObject(i)
                addMemberExchangeEntityCandidates(
                    page.getJSONObject("response").optJSONArray("entityInfoList"), candidates,
                    page.getInt("pageNum"), 18, page.getString("uniqueId"),
                    JSONObject().put("source", "mytab").put("innerSource", "").put("unid", "").put("dhNewItem", "true"),
                )
            }
            return candidates
        }
        val snapshot = ExchangeOptionsCache.getOrFetch(userId, ExchangeOptionsRefreshBridge.TARGET_MEMBER_POINT, forceRefresh) { session ->
            val info = session.read("memberInfo", JSONObject(), "积分查询参数") {
                if (pointBalance != null) JSONObject().put("success", true).put("pointBalance", pointBalance)
                else JSONObject(AntMemberRpcCall.queryMemberInfo())
            }
            check(ResChecker.checkRes(TAG, "会员积分兑换列表刷新失败:", info)) { "会员积分信息查询失败" }
            val balance = info.optString("pointBalance").ifEmpty { info.optInt("pointBalance", 0).toString() }
            session.commit(JSONObject().put("stage", "shandie").put("pageNum", 1), nextLabel = "闪兑第 1 页")
            val shandie = JSONArray()
            val delivery = JSONArray()
            var currentPage = 1
            var hasNextPage: Boolean
            do {
                if (sleepMillis > 0L) session.pageTurnDelay(baseMillis = sleepMillis)
                val response = session.read("shandie", JSONObject().put("pageNum", currentPage).put("pageSize", 18), "闪兑第 $currentPage 页") {
                    val raw = AntMemberRpcCall.queryShandieEntityList(userId.orEmpty(), balance, currentPage, 18)
                    if (raw.isEmpty()) {
                        onFailure?.invoke(TaskFlowActionResult.failure(TaskRpcFailureType.RETRYABLE_RPC,
                            rpc = "queryShandieEntityList", message = "空响应", raw = raw))
                        error("会员积分闪兑列表为空响应")
                    }
                    JSONObject(raw)
                }
                if (!ResChecker.checkRes(TAG, "会员积分闪兑列表查询失败:", response)) {
                    onFailure?.invoke(memberDomainTaskFailureResult(null, response, response.toString(), "queryShandieEntityList", "缺货补兑查询失败"))
                    error("会员积分闪兑列表查询失败")
                }
                val benefits = response.optJSONArray("benefits") ?: error("会员积分闪兑列表缺少 benefits")
                shandie.put(response)
                val next = response.optInt("nextPageNum", 0)
                check(next <= 0 || next > currentPage) { "会员积分闪兑分页未前进: currentPage=$currentPage nextPageNum=$next" }
                hasNextPage = next > currentPage
                check(!hasNextPage || benefits.length() > 0) { "会员积分闪兑分页未返回商品: currentPage=$currentPage nextPageNum=$next" }
                session.commit(JSONObject().put("stage", if (hasNextPage) "shandie" else "deliverySession").put("pageNum", next),
                    benefits.length(), if (hasNextPage) "闪兑第 $next 页" else "闪兑结束，准备积分专区")
                if (hasNextPage) currentPage = next
            } while (hasNextPage)

            val deliverySession = session.read("deliverySession", JSONObject(), "积分专区分页参数") {
                JSONObject().put("uniqueId", "${System.currentTimeMillis()}and99999999INTELLIGENT_SORT5000551494000SR2024110510425045,94000SR2025091714812006,94000SR2023102305988003")
            }
            val deliveryUniqueId = deliverySession.getString("uniqueId")
            session.commit(JSONObject().put("stage", "delivery").put("pageNum", 1).put("uniqueId", deliveryUniqueId), nextLabel = "积分专区第 1 页")
            currentPage = 1
            do {
                if (sleepMillis > 0L) session.pageTurnDelay(baseMillis = sleepMillis)
                val response = session.read("delivery", JSONObject().put("pageNum", currentPage).put("pageSize", 18)
                    .put("uniqueId", deliveryUniqueId), "积分专区第 $currentPage 页") {
                    JSONObject(AntMemberRpcCall.queryDeliveryZoneDetail(
                        pointBalance = balance, pageNum = currentPage, pageSize = 18, uniqueId = deliveryUniqueId
                    ))
                }
                if (!ResChecker.checkRes(TAG, "会员积分专区列表查询失败:", response)) {
                    onFailure?.invoke(memberDomainTaskFailureResult(null, response, response.toString(), "queryDeliveryZoneDetail", "缺货补兑查询失败"))
                    error("会员积分专区列表查询失败")
                }
                val briefConfigInfos = response.optJSONArray("briefConfigInfos")
                val entityInfoList = response.optJSONArray("entityInfoList")
                check(briefConfigInfos != null || entityInfoList != null) { "会员积分专区列表缺少商品数据" }
                delivery.put(JSONObject().put("response", response).put("pageNum", currentPage)
                    .put("uniqueId", response.optString("uniqueId", deliveryUniqueId)))
                val next = response.optInt("nextPageNum", 0)
                check(next <= 0 || next > currentPage) { "会员积分专区分页未前进: currentPage=$currentPage nextPageNum=$next" }
                hasNextPage = next > currentPage
                check(!hasNextPage || (briefConfigInfos?.length() ?: 0) + (entityInfoList?.length() ?: 0) > 0) {
                    "会员积分专区分页未返回商品: currentPage=$currentPage nextPageNum=$next"
                }
                session.commit(JSONObject().put("stage", if (hasNextPage) "delivery" else "navi").put("pageNum", next),
                    (briefConfigInfos?.length() ?: 0) + (entityInfoList?.length() ?: 0),
                    if (hasNextPage) "积分专区第 $next 页" else "积分专区结束，准备权益导航")
                if (hasNextPage) currentPage = next
            } while (hasNextPage)
            val navi = JSONArray()
            for (naviCode in listOf("", "14", "1", "11", "12")) {
                val naviSession = session.read("naviSession", JSONObject().put("naviCode", naviCode), "权益导航分页参数") {
                    JSONObject().put("uniqueId", "${System.currentTimeMillis()}${naviCode}0and99999999INTELLIGENT_SORT${userId.orEmpty()}")
                }
                var naviUniqueId = naviSession.getString("uniqueId")
                currentPage = 1
                do {
                    if (sleepMillis > 0L) session.pageTurnDelay(baseMillis = sleepMillis)
                    val response = session.read("navi", JSONObject().put("naviCode", naviCode).put("pageNum", currentPage)
                        .put("pageSize", 18).put("uniqueId", naviUniqueId), "权益导航[$naviCode]第 $currentPage 页") {
                        JSONObject(AntMemberRpcCall.queryIndexNaviBenefitFlowV2(naviCode, currentPage, 18, naviUniqueId))
                    }
                    if (!ResChecker.checkRes(TAG, "会员权益导航查询失败:", response)) {
                        onFailure?.invoke(memberDomainTaskFailureResult(null, response, response.toString(), "queryIndexNaviBenefitFlowV2", "权益导航查询失败"))
                        error("会员权益导航查询失败")
                    }
                    val entities = response.optJSONArray("entityInfoList") ?: error("会员权益导航缺少 entityInfoList")
                    naviUniqueId = response.optString("uniqueId").ifBlank { naviUniqueId }
                    navi.put(JSONObject().put("response", response).put("pageNum", currentPage).put("uniqueId", naviUniqueId))
                    val next = response.optInt("nextPageNum", 0)
                    check(next <= 0 || next > currentPage) { "会员权益导航分页未前进: currentPage=$currentPage nextPageNum=$next" }
                    hasNextPage = next > currentPage
                    check(!hasNextPage || entities.length() > 0) { "会员权益导航分页未返回商品: currentPage=$currentPage nextPageNum=$next" }
                    session.commit(JSONObject().put("stage", "navi").put("naviCode", naviCode).put("pageNum", next),
                        entities.length(), if (hasNextPage) "权益导航[$naviCode]第 $next 页" else "当前权益导航结束")
                    if (hasNextPage) currentPage = next
                } while (hasNextPage)
            }
            session.commit(JSONObject().put("stage", "navi").put("done", true), nextLabel = "权益目录结束，保存完整列表")
            val payload = JSONObject().put("shandie", shandie).put("delivery", delivery).put("navi", navi)
            ExchangeOptionsSnapshot(parse(payload).values.map { it.item.toOptionRow() }, payload)
        }
        return parse(snapshot.payload)
    }

    private fun addMemberExchangeCandidates(
        benefits: JSONArray?,
        candidateMap: LinkedHashMap<String, MemberExchangeCandidate>,
        pageNum: Int = 1,
        pageSize: Int = 18,
        uniqueId: String = ""
    ) {
        if (benefits == null || benefits.length() == 0) {
            return
        }
        for (i in 0 until benefits.length()) {
            val globalIndex = (pageNum - 1) * pageSize + i + 1
            val sourcePassMap = if (uniqueId.isNotBlank()) buildMemberDeliveryZoneSourcePassMap(uniqueId, globalIndex) else null
            val requestSourceInfo = uniqueId.takeIf { it.isNotBlank() }?.let { "SID:$it|$globalIndex" }.orEmpty()
            val candidate = buildMemberExchangeCandidate(
                benefits.optJSONObject(i) ?: continue,
                requestSourceInfo = requestSourceInfo,
                sourcePassMap = sourcePassMap
            ) ?: continue
            candidateMap.putIfAbsent(candidate.item.id, candidate)
        }
    }

    private fun addMemberExchangeEntityCandidates(
        entities: JSONArray?,
        candidateMap: LinkedHashMap<String, MemberExchangeCandidate>,
        pageNum: Int,
        pageSize: Int,
        uniqueId: String,
        sourcePassMap: JSONObject? = null,
    ) {
        if (entities == null || entities.length() == 0) {
            return
        }
        for (i in 0 until entities.length()) {
            val benefit = entities.optJSONObject(i)?.optJSONObject("benefitInfo") ?: continue
            val globalIndex = (pageNum - 1) * pageSize + i + 1
            val itemSourcePassMap = sourcePassMap?.let {
                JSONObject(it.toString()).put("uniqueId", uniqueId).put("feedsIndex", globalIndex.toString())
            } ?: buildMemberDeliveryZoneSourcePassMap(uniqueId, globalIndex)
            val candidate = buildMemberExchangeCandidate(
                benefit,
                requestSourceInfo = "SID:$uniqueId|$globalIndex",
                sourcePassMap = itemSourcePassMap
            ) ?: continue
            candidateMap.putIfAbsent(candidate.item.id, candidate)
        }
    }

    private fun buildMemberDeliveryZoneSourcePassMap(uniqueId: String, feedsIndex: Int): JSONObject {
        return JSONObject().apply {
            put("bid", "202412231259661040")
            put("feedsIndex", feedsIndex.toString())
            put("innerSource", "a159.b114660")
            put("isCpc", "")
            put("source", "")
            put("unid", "")
            put("uniqueId", uniqueId)
        }
    }

    private fun refreshBeanExchangeRightOptionsForSettings(): List<MapperEntity> {
        val freshBeanRows = ExchangeOptionsCache.loadTodaySnapshot(
            UserMap.currentUid, ExchangeOptionsRefreshBridge.TARGET_BEAN_RIGHT
        )?.rows
        if (freshBeanRows != null) {
            Log.member("安心豆🫘设置页使用新鲜缓存#${freshBeanRows.size}")
            return freshBeanRows
        }
        if (!HookReadyChecker.isCurrentProcessReadyForRpc(UserMap.currentUid)) {
            val cachedRows = ExchangeOptionsCache.loadForSettingsCache(
                UserMap.currentUid,
                ExchangeOptionsRefreshBridge.TARGET_BEAN_RIGHT
            )
            if (!HookReadyChecker.isTargetAppReadyForRpc(UserMap.currentUid)) {
                Log.member("安心豆🫘目标应用未就绪，设置页先展示上次缓存列表；请打开目标应用后再刷新#${cachedRows.size}")
                return cachedRows
            }
            val refreshResult = ExchangeOptionsRefreshBridge.requestRefreshOptions(
                ExchangeOptionsRefreshBridge.TARGET_BEAN_RIGHT,
                UserMap.currentUid
            )
            if (refreshResult.success) {
                Log.member("安心豆🫘设置页使用目标应用刷新列表#${refreshResult.options.size}")
                return refreshResult.options
            }
            if (cachedRows.isNotEmpty()) {
                Log.member("安心豆🫘远程刷新失败，设置页回退上次缓存快照#${cachedRows.size}#${refreshResult.message}")
                return cachedRows
            }
            Log.member("安心豆🫘远程刷新失败，且无可用缓存快照#${refreshResult.message}")
            return emptyList()
        }
        val rowsResult = runCatching {
            refreshBeanExchangeRightOptionsFromRpc()
        }.onFailure {
            Log.printStackTrace(TAG, "refreshBeanExchangeRightOptionsForSettings.currentRpc err:", it)
        }
        val rows = rowsResult.getOrElse { throwable ->
            val cachedRows = ExchangeOptionsCache.loadForSettingsCache(
                UserMap.currentUid,
                ExchangeOptionsRefreshBridge.TARGET_BEAN_RIGHT
            )
            if (cachedRows.isNotEmpty()) {
                Log.member("安心豆🫘当前进程刷新失败，设置页回退上次缓存快照#${cachedRows.size}#${throwable.message}")
                cachedRows
            } else {
                Log.member("安心豆🫘当前进程刷新失败，且无可用缓存快照#${throwable.message}")
                emptyList()
            }
        }
        Log.member("安心豆🫘设置页刷新结构化列表#${rows.size}")
        return rows
    }

    private fun refreshBeanExchangeRightOptionsFromRpc(forceRefresh: Boolean = false): List<ExchangeOptionRow> {
        try {
            val userId = UserMap.currentUid
            val candidateMap = queryBeanExchangeCandidates(null, forceRefresh)
            val beanRightMap = IdMapManager.getInstance(BeanExchangeRightMap::class.java)
            candidateMap.values.forEach { candidate ->
                beanRightMap.add(candidate.item.id, candidate.item.displayName())
            }
            beanRightMap.save(userId)
            val rows = candidateMap.values.map { it.item.toOptionRow() }
            Log.member("安心豆🫘刷新兑换列表#${rows.size}")
            return rows
        } catch (t: Throwable) {
            Log.printStackTrace(TAG, "refreshBeanExchangeRightOptionsFromRpc err:", t)
            throw t
        }
    }

    internal fun refreshBeanExchangeRightOptionsForRemote(forceRefresh: Boolean = false): List<ExchangeOptionRow> =
        refreshBeanExchangeRightOptionsFromRpc(forceRefresh)

    private fun queryBeanBizProperties(): List<String> {
        val fallbackBizProperties = listOf(
            "RED_PACKET_COUPON",
            "VOUCHER_CARD",
            "CASH_MEMBER",
            "HEALTH",
            "HOEM_DALIY",
            "MOTHER_BABY_TOYS",
            "FOOD_BEVERAGE",
            "ELECTRONICS_APPLIANCES",
            "OTHERS"
        )
        return runCatching {
            val response = JSONObject(AntMemberRpcCall.filterValidBizProperty())
            check(ResChecker.checkRes(TAG, response)) { "安心豆权益分类查询失败" }
            val validBizPropertyList = extractBeanExchangeResult(response).getJSONArray("validBizPropertyList")
            if (validBizPropertyList.length() == 0) {
                return@runCatching listOf("") + fallbackBizProperties
            }
            val dynamicBizProperties = (0 until validBizPropertyList.length())
                .mapNotNull { validBizPropertyList.optJSONObject(it) }
                .sortedBy { it.optInt("priority", Int.MAX_VALUE) }
                .mapNotNull { it.optString("bizPropertyCode").takeIf(String::isNotBlank) }
            listOf("") + dynamicBizProperties
        }.onFailure {
            Log.printStackTrace(TAG, "queryBeanBizProperties err:", it)
        }.getOrThrow().distinct()
    }

    private fun queryBeanExchangeCandidates(
        beanBalance: Int?,
        forceRefresh: Boolean = false
    ): LinkedHashMap<String, BeanExchangeCandidate> {
        fun parse(payload: JSONObject): LinkedHashMap<String, BeanExchangeCandidate> {
            val candidates = LinkedHashMap<String, BeanExchangeCandidate>()
            val responses = payload.getJSONArray("responses")
            for (i in 0 until responses.length()) {
                val response = responses.getJSONObject(i)
                val result = extractBeanExchangeResult(response)
                check(listOf("preExchangeDetailList", "couponRightsDTOList", "rightsList", "flowList")
                    .any { result.optJSONArray(it) != null }) { "安心豆权益列表缺少商品数据" }
                addBeanExchangeCandidates(response, candidates, fromHistory = false, beanBalance = beanBalance)
            }
            return candidates
        }
        val snapshot = ExchangeOptionsCache.getOrFetch(UserMap.currentUid, ExchangeOptionsRefreshBridge.TARGET_BEAN_RIGHT, forceRefresh) { session ->
            val categories = session.read("categories", JSONObject(), "权益分类") {
                JSONObject().put("categories", JSONArray(queryBeanBizProperties()))
            }.getJSONArray("categories")
            val bizProperties = (0 until categories.length()).map { categories.getString(it) }
            session.commit(JSONObject().put("categoryIndex", 0).put("pageStartIndex", 0), nextLabel = "权益推荐第一个分类")
            val responses = JSONArray()
            for ((categoryIndex, bizProperty) in bizProperties.withIndex()) {
                var pageStartIndex = 0
                while (true) {
                    val response = session.read("recommend", JSONObject().put("bizProperty", bizProperty)
                        .put("pageStartIndex", pageStartIndex).put("pageSize", 6), "${bizProperty.ifBlank { "全部权益" }}偏移 $pageStartIndex") {
                        JSONObject(AntMemberRpcCall.rightsRecommend(pageStartIndex = pageStartIndex, bizProperty = bizProperty))
                    }
                    check(ResChecker.checkRes(TAG, "安心豆权益推荐列表查询失败:", response)) { "安心豆权益推荐列表查询失败" }
                    responses.put(response)
                    val result = extractBeanExchangeResult(response)
                    val lists = listOfNotNull(result.optJSONArray("preExchangeDetailList"), result.optJSONArray("couponRightsDTOList"),
                        result.optJSONArray("rightsList"), result.optJSONArray("flowList"))
                    check(lists.isNotEmpty()) { "安心豆权益列表缺少商品数据: bizProperty=$bizProperty pageStartIndex=$pageStartIndex" }
                    val count = lists.sumOf { it.length() }
                    if (!result.optBoolean("hasNext", false)) {
                        session.commit(JSONObject().put("categoryIndex", categoryIndex + 1).put("pageStartIndex", 0), count,
                            "当前推荐分类结束，继续后续分类或预兑换列表")
                        break
                    }
                    val nextStartIndex = result.optInt("pageEndIndex", -1)
                    check(lists.any { it.length() > 0 } && nextStartIndex > pageStartIndex) {
                        "安心豆权益分页未前进: bizProperty=$bizProperty pageStartIndex=$pageStartIndex pageEndIndex=$nextStartIndex"
                    }
                    session.commit(JSONObject().put("categoryIndex", categoryIndex).put("pageStartIndex", nextStartIndex), count,
                        "${bizProperty.ifBlank { "全部权益" }}偏移 $nextStartIndex")
                    pageStartIndex = nextStartIndex
                    session.pageTurnDelay()
                }
            }
            var pageStartIndex = 0
            while (true) {
                val response = session.read("preExchange", JSONObject().put("pageStartIndex", pageStartIndex).put("pageSize", 99),
                    "预兑换列表偏移 $pageStartIndex") {
                    JSONObject(AntMemberRpcCall.queryRightsPreExchangeFlows(pageStartIndex = pageStartIndex, pageSize = 99))
                }
                check(ResChecker.checkRes(TAG, "安心豆预兑换列表查询失败:", response)) { "安心豆预兑换列表查询失败" }
                responses.put(response)
                val result = extractBeanExchangeResult(response)
                val lists = listOfNotNull(result.optJSONArray("preExchangeDetailList"), result.optJSONArray("couponRightsDTOList"),
                    result.optJSONArray("rightsList"), result.optJSONArray("flowList"))
                check(lists.isNotEmpty()) { "安心豆预兑换列表缺少商品数据: pageStartIndex=$pageStartIndex" }
                val count = lists.sumOf { it.length() }
                if (!result.optBoolean("hasNext", false)) {
                    session.commit(JSONObject().put("done", true), count, "预兑换列表结束，保存完整列表")
                    break
                }
                val nextStartIndex = result.optInt("pageEndIndex", -1)
                check(lists.any { it.length() > 0 } && nextStartIndex > pageStartIndex) {
                    "安心豆预兑换分页未前进: pageStartIndex=$pageStartIndex pageEndIndex=$nextStartIndex"
                }
                session.commit(JSONObject().put("stage", "preExchange").put("pageStartIndex", nextStartIndex), count,
                    "预兑换列表偏移 $nextStartIndex")
                pageStartIndex = nextStartIndex
                session.pageTurnDelay()
            }
            val payload = JSONObject().put("responses", responses)
            ExchangeOptionsSnapshot(parse(payload).values.map { it.item.toOptionRow() }, payload)
        }
        return parse(snapshot.payload)
    }

    internal fun memberPointExchangeBenefit() {
        val selectedIds = ExchangeReplenisher.remainingSelectedIds(
            memberPointExchangeBenefitList?.value, ::canMemberPointExchangeBenefitToday
        )
        if (selectedIds.isEmpty()) return
        try {
            val userId = UserMap.currentUid
            val memberInfo = JSONObject(AntMemberRpcCall.queryMemberInfo())
            if (!ResChecker.checkRes(TAG, "会员积分信息查询失败:", memberInfo)) {
                return
            }
            val pointBalance = memberInfo.optString("pointBalance")
                .ifEmpty { memberInfo.optInt("pointBalance", 0).toString() }
            val remainingSelectedIds: MutableSet<String>? = if (selectedIds.isNotEmpty()) {
                selectedIds.toMutableSet()
            } else {
                null
            }
            val memberBenefitMap = IdMapManager.getInstance(MemberBenefitsMap::class.java)
            Log.member("会员积分🎐兑换列表刷新..")
            val candidateMap = queryMemberExchangeCandidates(userId, pointBalance, 850L)
            memberBenefitMap.load(userId)
            candidateMap.values.forEach { candidate ->
                memberBenefitMap.add(candidate.item.id, candidate.item.displayName())
                if (!selectedIds.contains(candidate.item.id)) {
                    return@forEach
                }
                remainingSelectedIds?.remove(candidate.item.id)
                if (!canMemberPointExchangeBenefitToday(candidate.item.id)) {
                    Log.member("会员积分🎐跳过[${candidate.item.name}]#今日已处理")
                    return@forEach
                }
                when (candidate.item.safety) {
                    ExchangeSafety.LOG_ONLY -> {
                        Log.member("会员积分🎐已勾选[${candidate.item.displayName()}]#仅提醒，不自动兑换")
                    }
                    ExchangeSafety.AUTO, ExchangeSafety.UNAVAILABLE -> {
                        // 缓存中的临时不可兑状态不能替代本次详情复核。
                        if (exchangeMemberPointBenefit(candidate)) {
                            memberPointExchangeBenefitToday(candidate.item.id)
                        }
                    }
                }
            }
            memberBenefitMap.save(userId)
            if (candidateMap.isEmpty()) {
                Log.member("会员积分🎐未获取到可兑换列表")
            } else {
                Log.member("会员积分🎐兑换列表刷新完成#${candidateMap.size}")
            }
            remainingSelectedIds
                ?.filter { canMemberPointExchangeBenefitToday(it) }
                ?.forEach { Log.member("会员积分🎐已勾选[$it]#本次列表未返回，保留配置不删除") }
        } catch (t: Throwable) {
            Log.member("memberPointExchangeBenefit 运行异常: ${t.message}")
            Log.printStackTrace(TAG, t)
        }
    }

    private fun buildMemberExchangeCandidate(
        benefit: JSONObject,
        requestSourceInfo: String = "",
        sourcePassMap: JSONObject? = null
    ): MemberExchangeCandidate? {
        val benefitId = benefit.optString("benefitId").trim()
        val itemId = benefit.optString("itemId").trim()
        val name = benefit.optString("name", benefit.optString("shortTitle", "未知权益")).trim()
        if (benefitId.isEmpty()) {
            Log.member("会员积分🎐商品[$name]没有 benefitId，跳过")
            return null
        }
        val stableId = if (itemId.isEmpty()) benefitId else "$benefitId|$itemId"
        val pricePresentation = benefit.optJSONObject("pricePresentation")
        val pointNeeded = pricePresentation?.optString("point").orEmpty()
            .ifEmpty { benefit.optJSONObject("pointPriceForDisplay")?.optString("minPoint").orEmpty() }
        val yuan = pricePresentation?.optString("yuan").orEmpty()
        val channelPrice = benefit.optString("channelPrice")
        val nextQuantity = benefit.optInt("nextQuantity", -1)
        val reserve = benefit.optInt("reserve", -1)
        val reserveForDisplay = benefit.optString("reserveForDisplay")
        val stockText = when {
            nextQuantity > 0 -> "下轮库存$nextQuantity"
            reserveForDisplay.isNotEmpty() -> "库存$reserveForDisplay"
            reserve >= 0 -> "库存$reserve"
            else -> ""
        }
        val validText = formatExchangeWindow(
            benefit.optLong("nextExchangeStartTime", 0L).takeIf { it > 0L }
                ?: benefit.optLong("exchangeStartDt", 0L),
            benefit.optLong("nextExchangeEndTime", 0L).takeIf { it > 0L }
                ?: benefit.optLong("exchangeEndDt", 0L)
        )
        val benefitMark = benefit.optString("benefitMark")
        val itemSource = benefit.optString("itemSource")
        val actionUrl = benefit.optString("actionUrl")
        val extInfo = benefit.optJSONObject("extInfo")
        val linkInfo = benefit.optJSONObject("linkInfo")
        val statusParts = mutableListOf<String>()
        val serverUsable = when {
            benefit.has("usable") -> benefit.optBoolean("usable", false)
            benefit.has("exchangeable") -> benefit.optBoolean("exchangeable", false)
            else -> true
        }
        if (!serverUsable) {
            statusParts.add("服务端不可兑")
        }
        if (nextQuantity == 0 && reserve <= 0) {
            statusParts.add("库存不足")
        }
        if (benefit.optBoolean("needPartnerMember", false) || benefit.optBoolean("needCheckPartnerMember", false)) {
            statusParts.add("需合作会员")
        }
        extInfo?.optString("labelContent")
            ?.takeIf { it.isNotBlank() }
            ?.let { statusParts.add(it) }

        val (baseSafety, baseReason) = ExchangeSafetyRules.classify(
            cashValues = listOf(channelPrice, yuan),
            textValues = listOf(actionUrl, extInfo?.toString(), linkInfo?.toString()),
            defaultReason = "涉及实付或下单链路"
        )
        val safety = when {
            statusParts.any { it == "服务端不可兑" || it == "库存不足" } -> ExchangeSafety.UNAVAILABLE
            baseSafety == ExchangeSafety.LOG_ONLY -> ExchangeSafety.LOG_ONLY
            else -> ExchangeSafety.AUTO
        }
        val safetyReason = when {
            safety == ExchangeSafety.UNAVAILABLE -> statusParts.firstOrNull { it == "服务端不可兑" || it == "库存不足" }.orEmpty()
            baseReason.isNotEmpty() -> baseReason
            else -> ""
        }
        val effectTags = ExchangeEffectCatalog.tagsFor(ExchangeEffectCatalog.SOURCE_MEMBER_POINT, name)
        return MemberExchangeCandidate(
            item = ExchangeItem(
                id = stableId,
                name = name.ifEmpty { stableId },
                cost = ExchangeCost(
                    pointText = pointNeeded.takeIf { it.isNotBlank() }?.let { "${it}积分" }.orEmpty(),
                    cashText = yuan.takeIf { it.isNotBlank() && it != "0" }?.let { "${it}元" }
                        ?: channelPrice.takeIf { it.isNotBlank() && it != "0" }?.let { "${it}元" }.orEmpty()
                ),
                limit = ExchangeLimit(
                    statusText = statusParts.joinToString("、"),
                    stockText = stockText,
                    validText = validText
                ),
                safety = safety,
                safetyReason = safetyReason,
                effectTags = effectTags,
                displayMeta = ExchangeEffectCatalog.displayMeta(
                    ExchangeEffectCatalog.SOURCE_MEMBER_POINT,
                    name,
                    safety,
                    safetyReason,
                    effectTags
                )
            ),
            benefitId = benefitId,
            itemId = itemId,
            pointNeeded = pointNeeded,
            benefitMark = benefitMark,
            itemSource = itemSource,
            requestSourceInfo = requestSourceInfo,
            sourcePassMap = sourcePassMap
        )
    }

    private fun exchangeMemberPointBenefit(candidate: MemberExchangeCandidate, onFailure: ((TaskFlowActionResult) -> Unit)? = null): Boolean {
        return try {
            val cityCode = LocationHelper.requireCityCode()
            val detailResp = JSONObject(
                AntMemberRpcCall.querySingleBenefitDetail(
                    benefitId = candidate.benefitId,
                    cityCode = cityCode,
                    requestSourceInfo = candidate.requestSourceInfo,
                    sourcePassMap = candidate.sourcePassMap
                )
            )
            if (!ExchangeSafetyRules.isSuccessResponse(detailResp) &&
                !ResChecker.checkRes(TAG, "会员积分权益详情查询失败:", detailResp)
            ) {
                onFailure?.invoke(memberDomainTaskFailureResult(null, detailResp, detailResp.toString(), "querySingleBenefitDetail", "缺货补兑详情失败"))
                return false
            }
            val detailCandidate = detailResp.optJSONObject("benefitDetail")
                ?.let {
                    buildMemberExchangeCandidate(
                        it,
                        requestSourceInfo = candidate.requestSourceInfo,
                        sourcePassMap = candidate.sourcePassMap
                    )
                }
                ?: candidate
            if (detailCandidate.item.safety != ExchangeSafety.AUTO) {
                Log.member("会员积分🎐详情复核跳过[${detailCandidate.item.displayName()}]#${detailCandidate.item.safetyReason}")
                return false
            }

            val confirmResp = JSONObject(
                AntMemberRpcCall.queryPromoBenefitOrderConfirmInfo(
                    benefitId = detailCandidate.benefitId,
                    requestSourceInfo = detailCandidate.requestSourceInfo,
                    sourcePassMap = detailCandidate.sourcePassMap
                )
            )
            if (!ExchangeSafetyRules.isSuccessResponse(confirmResp) &&
                !ResChecker.checkRes(TAG, "会员积分兑换确认失败:", confirmResp)
            ) {
                onFailure?.invoke(memberDomainTaskFailureResult(null, confirmResp, confirmResp.toString(), "queryPromoBenefitOrderConfirmInfo", "缺货补兑确认失败"))
                return false
            }
            val confirmedCandidate = confirmResp.optJSONObject("promoBenefitOrderConfirmInfo")
                ?.let {
                    buildMemberExchangeCandidate(
                        it,
                        requestSourceInfo = detailCandidate.requestSourceInfo,
                        sourcePassMap = detailCandidate.sourcePassMap
                    )
                }
                ?: detailCandidate
            if (confirmedCandidate.item.safety != ExchangeSafety.AUTO) {
                Log.member("会员积分🎐确认页复核跳过[${confirmedCandidate.item.displayName()}]#${confirmedCandidate.item.safetyReason}")
                return false
            }
            if (confirmedCandidate.itemId.isBlank()) {
                Log.member("会员积分🎐跳过[${confirmedCandidate.item.name}]#exchangeBenefit 缺少 itemId")
                onFailure?.invoke(TaskFlowActionResult.failure(TaskRpcFailureType.NON_RETRYABLE_INVALID,
                    rpc = "exchangeMemberBenefit", message = "缺少 itemId", raw = confirmResp.toString()))
                return false
            }

            val exchangeResp = JSONObject(
                AntMemberRpcCall.exchangeMemberBenefit(
                    benefitId = confirmedCandidate.benefitId,
                    itemId = confirmedCandidate.itemId,
                    cityCode = cityCode,
                    requestSourceInfo = confirmedCandidate.requestSourceInfo,
                    sourcePassMap = confirmedCandidate.sourcePassMap
                )
            )
            if (!ExchangeSafetyRules.isSuccessResponse(exchangeResp) &&
                !ResChecker.checkRes(TAG, "会员积分兑换失败:", exchangeResp)
            ) {
                Log.member("会员积分🎐兑换失败[${confirmedCandidate.item.name}]#$exchangeResp")
                onFailure?.invoke(memberDomainTaskFailureResult(null, exchangeResp, exchangeResp.toString(), "exchangeMemberBenefit", "缺货补兑失败"))
                return false
            }
            val orderId = exchangeResp.optString("orderId")
            Log.member("会员积分🎐兑换[${confirmedCandidate.item.name}]#消耗${confirmedCandidate.pointNeeded}积分")
            if (orderId.isNotBlank()) {
                runCatching {
                    val orderResp = JSONObject(
                        AntMemberRpcCall.querySingleExchangeOrderDetail(
                            benefitId = confirmedCandidate.benefitId,
                            bizType = confirmedCandidate.itemSource.ifBlank { "PROMO" },
                            outBizNo = orderId,
                            sourcePassMap = confirmedCandidate.sourcePassMap
                        )
                    )
                    if (ExchangeSafetyRules.isSuccessResponse(orderResp) ||
                        ResChecker.checkRes(TAG, "会员积分兑换结果查询失败:", orderResp)
                    ) {
                        val detail = orderResp.optJSONObject("exchangeOrderDetailConfigInfo")
                        val status = detail?.optString("orderStatus").orEmpty().ifEmpty {
                            detail?.optString("status").orEmpty()
                        }
                        Log.member("会员积分🎐兑换结果[${confirmedCandidate.item.name}]#${status.ifBlank { "已提交" }}")
                    } else onFailure?.invoke(memberDomainTaskFailureResult(null, orderResp, orderResp.toString(),
                        "querySingleExchangeOrderDetail", "缺货补兑结果查询失败"))
                }.onFailure {
                    if (it is CancellationException) throw it
                    onFailure?.invoke(TaskFlowActionResult.failure(TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW,
                        rpc = "querySingleExchangeOrderDetail", message = it.message.orEmpty(), raw = it.toString()))
                    Log.printStackTrace(TAG, "exchangeMemberPointBenefit.queryOrderDetail err:", it)
                }
            }
            true
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            onFailure?.invoke(TaskFlowActionResult.failure(TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW,
                rpc = "exchangeMemberPointBenefit", message = t.message.orEmpty(), raw = t.toString()))
            Log.printStackTrace(TAG, "exchangeMemberPointBenefit err:", t)
            false
        }
    }

    private fun formatExchangeWindow(startMillis: Long, endMillis: Long): String {
        if (startMillis <= 0L && endMillis <= 0L) {
            return ""
        }
        val formatter = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault())
        val startText = startMillis.takeIf { it > 0L }?.let { formatter.format(Date(it)) }.orEmpty()
        val endText = endMillis.takeIf { it > 0L }?.let { formatter.format(Date(it)) }.orEmpty()
        return when {
            startText.isNotEmpty() && endText.isNotEmpty() -> "${startText}至${endText}"
            startText.isNotEmpty() -> "${startText}起"
            else -> "${endText}止"
        }
    }

    /**
     * 会员签到
     */
    /**
     * 会员签到
     */
    internal suspend fun doMemberSign(): Unit = CoroutineUtils.run {
        var signDoneToday = hasFlagToday(StatusFlags.FLAG_ANTMEMBER_MEMBER_SIGN_DONE)
        try {
            val uid = UserMap.currentUid
            if (!signDoneToday) {
                if (!canMemberSignInToday(uid)) {
                    signDoneToday = true
                } else {
                    val s = AntMemberRpcCall.queryMemberSigninCalendar()
                    val jo = JSONObject(s)
                    if (stopMemberCoreTasksForRpcRisk("AntMember.memberSign", jo)) {
                        return@run
                    }
                    if (ResChecker.checkRes(TAG, "会员签到失败:", jo)) {
                        val currentSigned = jo.optBoolean("currentSigninStatus") || jo.optBoolean("autoSignInSuccess")
                        if (currentSigned) {
                            val signPoint = jo.optString("signinPoint", "0")
                            val signDays = jo.optString("signinSumDay", "-")
                            val signStatus = if (jo.optBoolean("autoSignInSuccess")) "签到成功" else "已签到"
                            Log.member("会员签到📅[${signPoint}积分]#$signStatus${signDays}天")
                            memberSignInToday(uid)
                            signDoneToday = true
                        } else {
                            Log.member("会员签到📅[今日未自动签到]#$s")
                        }
                    } else {
                        val resultDesc = jo.optString("resultDesc", "")
                        if (resultDesc.contains("已签到") || resultDesc.contains("成功")) {
                            memberSignInToday(uid)
                            signDoneToday = true
                        }
                        Log.member("会员签到📅[$resultDesc]")
                        Log.member(s)
                    }
                }
            }
        } catch (t: Throwable) {
            Log.printStackTrace(TAG, "doMemberSign err:", t)
        } finally {
            if (signDoneToday) {
                setFlagToday(StatusFlags.FLAG_ANTMEMBER_MEMBER_SIGN_DONE)
            }
        }
    }

    internal fun doMemberGameEntrance() {
        try {
            val entrance = JSONObject(AntMemberRpcCall.queryGameEntranceInfo())
            if (!ResChecker.checkRes(TAG, entrance)) return
            val actionUrl = entrance.optString("actionUrl")
            if (actionUrl.isBlank()) return
            val launchUri = android.net.Uri.parse(actionUrl)
            val pageUri = android.net.Uri.parse(launchUri.getQueryParameter("url") ?: actionUrl)
            // 频道透传中的 sceneId 属于任务，不能用于外部乐园页面。
            val scene = pageUri.getQueryParameter("sceneId").orEmpty()
            val source = pageUri.getQueryParameter("chInfo")
                ?: launchUri.getQueryParameter("chInfo").orEmpty()
            val moduleId = pageUri.getQueryParameter("moduleId").orEmpty()
            val guideType = pageUri.getQueryParameter("guideType").orEmpty()
            val passThrough = GameCenterPlayRpcCall.describeTask(entrance)
                .urlParameters["channelTaskPassThrough"].orEmpty()
            if (source.isBlank()) {
                Log.error(TAG, "会员游戏入口缺少source:$entrance")
                return
            }
            if (pageUri.lastPathSegment == "index.html" && pageUri.getQueryParameter("tab") == "promote") {
                val home = GameCenterPlayRpcCall.queryGameCenterHome(
                    source = source,
                    trafficDriverId = pageUri.getQueryParameter("trafficDriverId").orEmpty(),
                    sourceTab = "promote",
                )
                if (!home.accepted) {
                    Log.error(TAG, "会员游戏中心访问失败[gamecenterhome.queryHomePage]:${home.raw}")
                    return
                }
                val walk = GameCenterPlayRpcCall.queryWalkMain(source, passThrough)
                if (!walk.accepted) {
                    Log.error(TAG, "会员游戏中心访问失败[walkgrid.queryWalkMain]:${walk.raw}")
                    return
                }
                val refreshedEntrance = JSONObject(AntMemberRpcCall.queryGameEntranceInfo())
                if (!ResChecker.checkRes(TAG, "会员游戏入口刷新失败:", refreshedEntrance)) return
                val before = entrance.optInt("gameEntrancePointNum", -1)
                val after = refreshedEntrance.optInt("gameEntrancePointNum", -1)
                val rewardMessage = walk.response?.optJSONObject("data")?.optString("globalToast").orEmpty()
                if (before > 0 && after >= 0 && after < before) {
                    Log.member("会员游戏中心🎮[访问奖励已确认] 入口积分:$before→$after $rewardMessage")
                } else if (before > 0) {
                    Log.member("会员游戏中心🎮[访问已提交，等待入口积分刷新] $rewardMessage")
                }
                return
            }
            if (pageUri.lastPathSegment != "externalGameCenter.html" || scene.isBlank()) {
                Log.error(TAG, "会员游戏入口页面或页面场景无效:$entrance")
                return
            }
            val home = GameCenterPlayRpcCall.queryExternalGameCenter(scene, moduleId, guideType, source, passThrough)
            if (!home.accepted) {
                Log.error(TAG, "会员游戏乐园访问失败:${home.raw}")
                return
            }
            val data = home.response?.optJSONObject("data") ?: return
            val taskId = data.optString("memberSignTaskId")
            val amount = data.optInt("memberSignAmount", 0)
            val afterSign = data.optLong("memberAssetBalanceAfterSign", -1L)
            TaskFlowEngine(object : TaskFlowAdapter {
                override val moduleName = "AntMember"
                override val flowName = "会员游戏乐园浏览奖励"
                private var firstQuery = true

                override fun query(): JSONObject {
                    val response = if (firstQuery) {
                        firstQuery = false
                        home.response
                    } else {
                        GameCenterPlayRpcCall.queryExternalGameCenter(scene, moduleId, guideType, source, passThrough).response
                    }
                    return response ?: JSONObject().put("success", false)
                }

                override fun isQuerySuccess(response: JSONObject): Boolean =
                    GameCenterPlayRpcCall.isAccepted(response) && response.optJSONObject("data") != null

                override fun extractItems(response: JSONObject): List<TaskFlowItem> {
                    val browse = response.optJSONObject("data")?.optJSONObject("browseTaskVO") ?: return emptyList()
                    return listOf(TaskFlowItem(
                        id = browse.optString("taskId"),
                        title = browse.optString("taskTitle", "游戏浏览奖励"),
                        status = "TODO",
                        raw = browse,
                    ))
                }

                override fun mapPhase(item: TaskFlowItem) = TaskFlowPhase.READY_TO_COMPLETE

                override fun complete(item: TaskFlowItem): TaskFlowActionResult {
                    val browse = item.raw ?: return TaskFlowActionResult.failure(
                        TaskRpcFailureType.NON_RETRYABLE_INVALID, message = "缺少浏览任务内容",
                    )
                    val sceneExtInfo = browse.optString("sceneExtInfo")
                    val appId = browse.optString("appId")
                    val gameSource = android.net.Uri.parse(browse.optString("gameJumpUrl"))
                        .getQueryParameter("chInfo").orEmpty()
                    val seconds = browse.optJSONObject("floatingBallVO")?.optInt("timeSeconds", 0) ?: 0
                    if (item.id.isBlank() || sceneExtInfo.isBlank() || appId.isBlank() || gameSource.isBlank() || seconds <= 0) {
                        return TaskFlowActionResult.failure(
                            TaskRpcFailureType.NON_RETRYABLE_INVALID,
                            message = "浏览任务缺少任务标识、场景签名或游戏时长参数",
                        )
                    }
                    val duration = GameCenterPlayRpcCall.advanceDuration(
                        stateKey = "memberGameBrowse:$scene:${item.id}:$sceneExtInfo",
                        contract = GameCenterPlayRpcCall.Contract(appId, Math.addExact(seconds, 1), gameSource),
                        firstChunkSeconds = 31,
                    )
                    if (!duration.success) return duration
                    val result = GameCenterPlayRpcCall.completeExternalBrowseTask(scene, sceneExtInfo)
                    return if (result.accepted) {
                        Log.member("会员游戏乐园🎮[${item.title}]已提交，刷新任务和积分")
                        TaskFlowActionResult.success()
                    } else {
                        TaskFlowActionResult.failure(
                            result.failureType, message = "会员游戏浏览奖励提交失败", raw = result.raw,
                        )
                    }
                }

                override fun afterDeferred(item: TaskFlowItem, action: TaskFlowAction, result: TaskFlowActionResult) {
                    result.deferredUntil?.let { scheduleMemberTaskContinuation("memberGameEntrance", it) }
                }

                override fun logInfo(message: String) = Log.member(message)
                override fun logError(message: String) = Log.error(TAG, message)
            }).run()
            val points = JSONObject(AntMemberRpcCall.queryPointCertV2(1, 20))
            if (!ResChecker.checkRes(TAG, points)) return
            if (taskId.isNotBlank() && amount > 0 && afterSign >= 0 && points.optLong("pointBalance", -1L) >= afterSign) {
                Log.member("会员游戏乐园🎮[入账${amount}积分] taskId=$taskId 余额=${points.optLong("pointBalance")}")
            }
        } catch (t: Throwable) {
            if (t is CancellationException || t is InterruptedException) throw t
            TaskExecutionReport.current()?.recordException()
            Log.printStackTrace(TAG, "会员游戏乐园入口处理失败", t)
        }
    }

    internal suspend fun doAllMemberAvailableTaskCompat(): Unit = CoroutineUtils.run {
        try {
            val floatingBallState = memberFloatingBallQueue.submit { processMemberFloatingBallTaskCompat() }
            val processedAnyTask = floatingBallState == MemberFloatingBallTaskProcessState.PROCESSED
            if (ApplicationHookConstants.isOffline()) {
                Log.member("会员任务[浮球]#检测到离线模式，本轮中断")
                return@run
            }

            when (floatingBallState) {
                MemberFloatingBallTaskProcessState.PROCESSED -> Unit

                MemberFloatingBallTaskProcessState.RETRY_LATER -> {
                    Log.member("会员任务[浮球]#等待后续调度，继续处理任务列表")
                }

                MemberFloatingBallTaskProcessState.UNKNOWN -> {
                    if (ApplicationHookConstants.isOffline()) return@run
                    Log.error(TAG, "会员浮球状态未确认，继续处理独立会员任务")
                }

                MemberFloatingBallTaskProcessState.STOPPED_TODAY -> {
                    Log.member("会员任务[浮球]#今日已停止请求，继续处理独立会员任务")
                }

                MemberFloatingBallTaskProcessState.NO_TASK -> {
                    Unit
                }
            }

            val taskListState = memberFloatingBallQueue.submit { processCurrentMemberTaskListCompat() }
            if (floatingBallState == MemberFloatingBallTaskProcessState.RETRY_LATER ||
                floatingBallState == MemberFloatingBallTaskProcessState.UNKNOWN ||
                floatingBallState == MemberFloatingBallTaskProcessState.STOPPED_TODAY
            ) return@run
            when (taskListState) {
                CurrentMemberTaskListProcessState.COMPLETED -> {
                    markMemberTaskDoneToday("会员任务#任务列表已处理完成，今日停止继续刷新")
                }

                CurrentMemberTaskListProcessState.HANDLED_PENDING_CONFIRM -> {
                    Log.member("会员任务#已提交的任务尚待确认，保留后续调度")
                }

                CurrentMemberTaskListProcessState.NO_ACTIONABLE_TASK -> {
                    markMemberTaskDoneToday("会员任务#当前列表无可执行任务，今日停止继续刷新")
                }

                CurrentMemberTaskListProcessState.NO_TASK -> {
                    if (!processedAnyTask) {
                        markMemberTaskDoneToday("会员任务#未发现可执行任务，今日停止继续刷新")
                    } else {
                        markMemberTaskDoneToday("会员任务#浮球任务已处理且未发现更多任务，今日停止继续刷新")
                    }
                }

                CurrentMemberTaskListProcessState.RETRY_LATER -> {
                    Log.member("会员任务#存在白名单任务但未确认完成，本轮结束，后续轮次继续查询")
                }

                CurrentMemberTaskListProcessState.UNKNOWN -> Unit
            }
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            TaskExecutionReport.current()?.recordException()
            Log.printStackTrace(TAG, "doAllMemberAvailableTaskCompat err:", t)
        }
    }

    private suspend fun processCurrentMemberTaskListCompat(): CurrentMemberTaskListProcessState = CoroutineUtils.run {
        try {
            val adapter = CurrentMemberTaskFlowAdapter()
            val runResult = TaskFlowEngine(adapter, roundSleepMs = 425L).run()
            return@run when {
                adapter.queryFailed -> CurrentMemberTaskListProcessState.UNKNOWN
                adapter.hasIncompleteQuery || adapter.hasRetryableFailure || adapter.hasBlockingFailure || runResult.stopped ->
                    CurrentMemberTaskListProcessState.RETRY_LATER

                adapter.hasPendingConfirmation || runResult.deferredCount > 0 ->
                    CurrentMemberTaskListProcessState.HANDLED_PENDING_CONFIRM
                runResult.completed -> CurrentMemberTaskListProcessState.COMPLETED
                adapter.supportedTaskCount == 0 && adapter.hasTaskSnapshot ->
                    CurrentMemberTaskListProcessState.NO_ACTIONABLE_TASK

                adapter.supportedTaskCount == 0 -> CurrentMemberTaskListProcessState.NO_TASK
                runResult.progressChanged || runResult.noProgressSuccess || adapter.hasPendingConfirmation ->
                    CurrentMemberTaskListProcessState.HANDLED_PENDING_CONFIRM

                else -> CurrentMemberTaskListProcessState.RETRY_LATER
            }
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            TaskExecutionReport.current()?.recordException()
            Log.printStackTrace(TAG, "processCurrentMemberTaskListCompat err:", t)
            return@run CurrentMemberTaskListProcessState.UNKNOWN
        }
    }

    private inner class CurrentMemberTaskFlowAdapter : TaskFlowAdapter {
        override val moduleName: String = memberTaskBlacklistModule
        override val flowName: String = "会员任务"

        var hasIncompleteQuery: Boolean = false
            private set
        var queryFailed: Boolean = false
            private set
        var hasTaskSnapshot: Boolean = false
            private set
        var supportedTaskCount: Int = 0
            private set
        var hasBlockingFailure: Boolean = false
            private set
        var hasRetryableFailure: Boolean = false
            private set
        var hasPendingConfirmation: Boolean = false
            private set

        private val appliedMemberTasks = LinkedHashMap<String, CurrentMemberTask>()
        private val loggedSkipKeys = LinkedHashSet<String>()

        override fun query(): JSONObject {
            val rawResponses = JSONArray()
            var stopReason = ""
            var stopScene = ""
            var stopObject: JSONObject? = null
            var rawResponse = ""

            fun appendTaskResponse(response: String, scene: String) {
                rawResponse = response
                val taskObject = JSONObject(response)
                val sceneStopReason = resolveMemberTaskQueryStopReason(taskObject)
                if (sceneStopReason != null) {
                    Log.error(TAG, "会员任务列表[$scene]查询失败:$taskObject")
                    stopReason = sceneStopReason
                    stopScene = scene
                    stopObject = taskObject
                    queryFailed = true
                    return
                }
                if (!ResChecker.checkRes(TAG, taskObject)) {
                    stopScene = scene
                    stopObject = taskObject
                    queryFailed = true
                    return
                }
                rawResponses.put(taskObject)
            }

            return try {
                val queries = buildList<Pair<String, () -> String>> {
                    if (memberSignInAdTask?.value == true) {
                        add("signInAd" to { AntMemberRpcCall.queryMemberTaskList() })
                    }
                    add("memberPoint" to { AntMemberRpcCall.queryMemberTaskProcessList() })
                }
                if (memberSignPageTask?.value == true) {
                    val session = java.util.UUID.randomUUID().toString()
                    val seenTaskIds = mutableSetOf<String>()
                    var page = 1
                    var paginationComplete = false
                    while (page <= 64 && stopReason.isBlank() && !queryFailed && !ApplicationHookConstants.isOffline()) {
                        appendTaskResponse(AntMemberRpcCall.signPageTaskList(page, session), "signPage:$page")
                        if (queryFailed) break
                        val pageResponse = rawResponses.optJSONObject(rawResponses.length() - 1) ?: break
                        val pageTaskIds = collectCurrentMemberTaskProcessObjects(pageResponse)
                            .mapNotNull(::resolveCurrentMemberTaskConfigId).toSet()
                        if (pageTaskIds.isEmpty()) {
                            paginationComplete = hasMemberTaskSnapshot(JSONArray().put(pageResponse))
                            break
                        }
                        if (!seenTaskIds.addAll(pageTaskIds)) break
                        page++
                    }
                    hasIncompleteQuery = !paginationComplete
                    if (hasIncompleteQuery) Log.member("会员签到页[分页未完整，保留后续查询] page=$page")
                }
                for ((scene, query) in queries) {
                    if (stopReason.isNotBlank() || ApplicationHookConstants.isOffline()) break
                    runCatching { appendTaskResponse(query(), scene) }.onFailure {
                        queryFailed = true
                        Log.printStackTrace(TAG, "会员任务列表[$scene]查询异常", it)
                    }
                }
                JSONObject()
                    .put("_taskFlowQuerySuccess", stopReason.isBlank() && !queryFailed && rawResponses.length() > 0 && !ApplicationHookConstants.isOffline())
                    .put("_taskFlowStopReason", stopReason)
                    .put("_taskFlowStopScene", stopScene)
                    .put("_taskFlowStopObject", stopObject ?: JSONObject())
                    .put("_rawResponse", rawResponse)
                    .put("_rawTaskResponses", rawResponses)
                    .put("_hasTaskSnapshot", hasMemberTaskSnapshot(rawResponses))
            } catch (t: Throwable) {
                JSONObject()
                    .put("_taskFlowQuerySuccess", false)
                    .put("_taskFlowStopScene", "query")
                    .put("resultDesc", "查询异常:${t.message}")
            }
        }

        override fun isQuerySuccess(response: JSONObject): Boolean {
            return response.optBoolean("_taskFlowQuerySuccess", false)
        }

        override fun extractItems(response: JSONObject): List<TaskFlowItem> {
            hasPendingConfirmation = false
            val rawResponses = response.optJSONArray("_rawTaskResponses") ?: JSONArray()
            hasTaskSnapshot = hasTaskSnapshot || response.optBoolean("_hasTaskSnapshot", false)
            val tasks = mutableListOf<CurrentMemberTask>()
            for (i in 0 until rawResponses.length()) {
                val taskObject = rawResponses.optJSONObject(i) ?: continue
                tasks.addAll(buildCurrentMemberTasks(taskObject, skipBlacklisted = false))
            }
            val dedupedTasks = dedupeCurrentMemberTasks(tasks)
            supportedTaskCount = max(supportedTaskCount, dedupedTasks.size)
            return dedupedTasks.map(::currentMemberTaskToFlowItem)
        }

        override fun mapPhase(item: TaskFlowItem): TaskFlowPhase {
            if (item.id.isBlank()) {
                return TaskFlowPhase.UNKNOWN
            }
            val originalTask = currentMemberTaskFromFlowItem(item)
            val taskKey = buildCurrentMemberTaskFlowKey(originalTask)
            val task = appliedMemberTasks[taskKey] ?: originalTask
            return when {
                task.simpleTaskConfig.optJSONObject("lightsAdExtMap") != null &&
                    taskKey !in appliedMemberTasks -> TaskFlowPhase.SIGNUP_REQUIRED
                task.adBizId.isNotBlank() -> TaskFlowPhase.READY_TO_COMPLETE
                task.taskProcessId.isBlank() -> TaskFlowPhase.SIGNUP_REQUIRED
                task.targetBusinessType == MemberTaskTargetBusinessType.UNSUPPORTED -> TaskFlowPhase.UNKNOWN
                else -> TaskFlowPhase.READY_TO_COMPLETE
            }
        }

        override fun shouldSkip(item: TaskFlowItem): Boolean = Thread.currentThread().isInterrupted

        override fun isBlacklisted(item: TaskFlowItem): Boolean {
            val blacklisted = super<TaskFlowAdapter>.isBlacklisted(item)
            if (blacklisted) {
                logMemberTaskSkipOnce(item, "任务在自动跳过列表(黑名单)中，跳过")
            }
            return blacklisted
        }

        override fun signup(item: TaskFlowItem): TaskFlowActionResult {
            val task = currentMemberTaskFromFlowItem(item)
            val adExtMap = task.simpleTaskConfig.optJSONObject("lightsAdExtMap")
            val waitKey = "memberTaskWait:ad:${TimeUtil.getDateStr2()}:${task.taskConfigId}:${task.adBizId}:${item.progress}"
            val adStore = if (adExtMap != null) {
                UserDataStoreManager.getInstance(AccountSessionCoordinator.currentUserId() ?: UserMap.currentUid)
                    ?: return TaskFlowActionResult.failure(
                        TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW, message = "无法保存广告任务报名状态",
                        detail = currentMemberTaskActionDetail(task, "apply"),
                    )
            } else null
            if (adStore?.get(waitKey, String::class.java) != null) {
                appliedMemberTasks[buildCurrentMemberTaskFlowKey(task)] = task
                return TaskFlowActionResult.success()
            }
            val batchApply = adExtMap == null && task.simpleTaskConfig.optString("sourceBusiness") == "signInAd"
            val applyResponse = when {
                adExtMap != null -> AntMemberRpcCall.applyAdTask(
                    task.adBizId, adExtMap.optString("adId"), task.awardPoint.toIntOrNull(), adExtMap,
                )
                batchApply -> AntMemberRpcCall.batchApplyMemberTasks(listOf(task.taskConfigId))
                else -> AntMemberRpcCall.applyMemberTask(task.taskConfigId)
            }
            val applyObject = JSONObject(applyResponse)
            if (stopMemberCoreTasksForRpcRisk("AntMember.memberTask.apply", applyObject)) {
                return memberDomainTaskFailureResult(
                    item = item,
                    responseObject = applyObject,
                    rawResponse = applyResponse,
                    rpc = "AntMemberRpcCall.applyMemberTask",
                    detail = currentMemberTaskActionDetail(task, "apply")
                )
            }
            if (isSkippableMemberTaskRejection(applyObject)) {
                return TaskFlowActionResult.failure(
                    failureType = TaskRpcFailureType.BUSINESS_LIMIT,
                    code = extractMemberDomainRpcCode(applyObject).ifBlank { "NOT_PROMO_RULE_QUALIFIED" },
                    message = extractMemberDomainRpcMessage(applyObject).ifBlank { "不满足任务的营销规则条件" },
                    rpc = "AntMemberRpcCall.applyMemberTask",
                    raw = applyResponse,
                    detail = currentMemberTaskActionDetail(task, "apply")
                )
            }
            if (!ResChecker.checkRes(TAG, "领取会员任务失败:", applyObject)) {
                return memberDomainTaskFailureResult(
                    item = item,
                    responseObject = applyObject,
                    rawResponse = applyResponse,
                    rpc = "AntMemberRpcCall.applyMemberTask",
                    detail = currentMemberTaskActionDetail(task, "apply")
                )
            }
            if (adExtMap != null) {
                adStore?.put(waitKey, JSONObject().put("readyAt", System.currentTimeMillis()).toString())
                appliedMemberTasks[buildCurrentMemberTaskFlowKey(task)] = task
                Log.member("会员广告[${task.title}]#报名成功")
                return TaskFlowActionResult.success()
            }
            if (batchApply) {
                val result = applyObject.optJSONObject("resultData")?.optJSONObject("resultMap")
                    ?.optString(task.taskConfigId).orEmpty()
                if (result != "SUCCESS") {
                    return TaskFlowActionResult.failure(
                        TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW, code = result,
                        message = "批量报名未确认当前任务成功", rpc = "AntMemberRpcCall.batchApplyMemberTasks",
                        raw = applyResponse, detail = currentMemberTaskActionDetail(task, "apply"),
                    )
                }
                Log.member("会员任务[${task.title}]#报名成功，回查当前阶段")
                return TaskFlowActionResult.success(refreshAfterAction = true)
            }
            val appliedTask = buildCurrentMemberTaskFromApplyResponse(task, applyObject)
                ?: return TaskFlowActionResult.failure(
                    failureType = TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW,
                    code = "TASK_PROCESS_MISSING",
                    message = "领取成功但缺少processId",
                    rpc = "AntMemberRpcCall.applyMemberTask",
                    raw = applyResponse,
                    detail = currentMemberTaskActionDetail(task, "apply")
                )
            appliedMemberTasks[buildCurrentMemberTaskFlowKey(task)] = appliedTask
            Log.member("会员任务[${appliedTask.title}]#领取任务")
            return TaskFlowActionResult.success()
        }

        override fun complete(item: TaskFlowItem): TaskFlowActionResult {
            val task = currentMemberTaskFromFlowItem(item)
            val taskKey = buildCurrentMemberTaskFlowKey(task)
            val executableTask = if (task.taskProcessId.isBlank()) {
                appliedMemberTasks[taskKey] ?: task
            } else {
                task
            }
            val result = completeCurrentMemberTask(executableTask, item)
            if (result.deferredReason != null) hasPendingConfirmation = true
            return result
        }

        override fun actionKey(item: TaskFlowItem, action: TaskFlowAction): String {
            val task = currentMemberTaskFromFlowItem(item)
            return "${action.logName}:${buildCurrentMemberTaskFlowKey(task)}:${item.status}:${item.progress}"
        }

        override fun afterSuccess(item: TaskFlowItem, action: TaskFlowAction, result: TaskFlowActionResult) {
            if (action == TaskFlowAction.COMPLETE &&
                (result.code == "VERIFY_PARTIAL" || result.code == "VERIFY_PENDING")
            ) {
                hasPendingConfirmation = true
            }
        }

        override fun afterFailure(
            item: TaskFlowItem,
            action: TaskFlowAction,
            result: TaskFlowActionResult,
            decision: TaskFlowDecision
        ) {
            when (decision) {
                TaskFlowDecision.RETRY_LATER -> hasRetryableFailure = true
                TaskFlowDecision.LOG_ONLY -> hasBlockingFailure = true
                TaskFlowDecision.MARK_HANDLED,
                TaskFlowDecision.STOP_TODAY_OR_CURRENT_CHAIN,
                TaskFlowDecision.BLACKLIST -> Unit
            }
        }

        override fun onAllTasksDone(snapshot: TaskFlowSnapshot) {
            logInfo("会员任务[已查询任务处理结束：${snapshot.completedTasks}/${snapshot.totalTasks}，分页完整=${!hasIncompleteQuery}]")
        }

        override fun onQueryFailed(response: JSONObject) {
            queryFailed = true
            val stopReason = response.optString("_taskFlowStopReason")
            val stopScene = response.optString("_taskFlowStopScene").ifBlank { "unknown" }
            val stopObject = response.optJSONObject("_taskFlowStopObject") ?: response
            if (stopReason.isNotBlank()) {
                Log.member("会员任务[$stopScene]#${buildMemberTaskQueryStopMessage(stopReason, stopObject)}")
                return
            }
            Log.error(
                "$TAG.processCurrentMemberTaskListCompat",
                "$flowName[任务查询失败] scene=$stopScene reason=" +
                    stopObject.optString("resultDesc").ifBlank {
                        stopObject.optString("errorMsg").ifBlank { response.optString("_rawResponse", response.toString()) }
                    }
            )
        }

        override fun onUnknownPhase(item: TaskFlowItem, phase: TaskFlowPhase) {
            hasBlockingFailure = true
            Log.error(
                TAG,
                "会员任务[${item.title}]#未知状态 module=$moduleName taskId=${item.id.ifBlank { "UNKNOWN" }} " +
                    "status=${item.status.ifBlank { "UNKNOWN" }} progress=${item.progress.ifBlank { "UNKNOWN" }} raw=${item.raw}"
            )
        }

        override fun logInfo(message: String) {
            Log.member(message)
        }

        override fun logError(message: String) {
            Log.error(TAG, message)
        }

        private fun hasMemberTaskSnapshot(rawResponses: JSONArray): Boolean {
            for (i in 0 until rawResponses.length()) {
                val taskObject = rawResponses.optJSONObject(i) ?: continue
                if (hasCurrentMemberTaskSnapshot(taskObject)) {
                    return true
                }
            }
            return false
        }

        private fun logMemberTaskSkipOnce(item: TaskFlowItem, reason: String) {
            val key = "$reason|${item.id}|${item.title}"
            if (loggedSkipKeys.add(key)) {
                Log.member("会员任务[${item.title}]#$reason")
            }
        }
    }

    private fun buildMemberTaskProcessAwards(jsonObject: JSONObject): List<MemberTaskProcessAward> {
        val taskProcessList = jsonObject.optJSONArray("availableTaskProcessList") ?: return emptyList()
        val awardList = mutableListOf<MemberTaskProcessAward>()
        val dedupKeys = LinkedHashSet<String>()
        for (i in 0 until taskProcessList.length()) {
            val taskProcess = taskProcessList.optJSONObject(i) ?: continue
            val taskProcessId = taskProcess.optString("taskProcessId")
            if (taskProcessId.isEmpty()) {
                continue
            }
            val taskConfig = taskProcess.optJSONObject("taskConfig")
            val taskTitle = taskConfig?.optString("title").orEmpty().ifEmpty {
                taskProcess.optString("title", "会员任务")
            }
            val stageProcessList = taskProcess.optJSONArray("stageProcessList") ?: continue
            for (stageIndexInList in 0 until stageProcessList.length()) {
                val stageProcess = stageProcessList.optJSONObject(stageIndexInList) ?: continue
                val stageStatus = stageProcess.optString("stageStatus")
                val awardRelatedOutBizNo = stageProcess.optString("awardRelatedOutBizNo")
                if (!stageStatus.equals("COMPLETE", true) || awardRelatedOutBizNo.isEmpty()) {
                    continue
                }
                val stageIndex = stageProcess.optInt("stageIndex", stageIndexInList + 1)
                val dedupKey = "$taskProcessId#$awardRelatedOutBizNo"
                if (!dedupKeys.add(dedupKey)) {
                    continue
                }
                awardList.add(
                    MemberTaskProcessAward(
                        taskProcessId = taskProcessId,
                        awardRelatedOutBizNo = awardRelatedOutBizNo,
                        title = taskTitle,
                        awardPoint = stageProcess.optInt("awardPoint", 0),
                        stageIndex = stageIndex
                    )
                )
            }
        }
        return awardList
    }

    internal suspend fun collectMemberTaskProcessAwards(): Int = CoroutineUtils.run {
        var claimedCount = 0
        try {
            TaskFlowEngine(object : TaskFlowAdapter {
                override val moduleName = memberTaskBlacklistModule
                override val flowName = "会员阶段奖励"
                override val continueCurrentRoundOnRetryableFailure = true
                private var awards = emptyMap<String, MemberTaskProcessAward>()

                override fun query(): JSONObject = JSONObject(AntMemberRpcCall.queryMemberTaskProcessList())

                override fun isQuerySuccess(response: JSONObject): Boolean =
                    !stopMemberCoreTasksForRpcRisk("AntMember.memberTask.awardQuery", response) &&
                        ResChecker.checkRes(TAG, response) && response.optJSONArray("availableTaskProcessList") != null

                override fun extractItems(response: JSONObject): List<TaskFlowItem> {
                    awards = buildMemberTaskProcessAwards(response).associateBy {
                        "${it.taskProcessId}#${it.awardRelatedOutBizNo}"
                    }
                    return awards.map { (id, award) ->
                        TaskFlowItem(id = id, title = award.title, status = "COMPLETE",
                            type = "MEMBER_STAGE_AWARD", progress = award.stageIndex.toString())
                    }
                }

                override fun mapPhase(item: TaskFlowItem) = TaskFlowPhase.REWARD_READY

                override fun receive(item: TaskFlowItem): TaskFlowActionResult {
                    val award = awards.getValue(item.id)
                    val raw = AntMemberRpcCall.awardMemberTaskProcess(award.awardRelatedOutBizNo, award.taskProcessId)
                    val response = JSONObject(raw)
                    if (stopMemberCoreTasksForRpcRisk("AntMember.memberTask.awardClaim", response) ||
                        !ResChecker.checkRes(TAG, response)
                    ) {
                        return memberDomainTaskFailureResult(item, response, raw,
                            "AntMemberRpcCall.awardMemberTaskProcess", "stageIndex=${award.stageIndex}")
                            .copy(continueCurrentRoundOnFailure = true, stopCurrentRound = false)
                    }
                    val stageSuffix = if (award.stageIndex > 0) "-阶段${award.stageIndex}" else ""
                    if (award.awardPoint > 0) {
                        Log.member("会员任务[${award.title}$stageSuffix]#获得积分${award.awardPoint}")
                    } else {
                        Log.member("会员任务[${award.title}$stageSuffix]#领取阶段奖励")
                    }
                    claimedCount++
                    return TaskFlowActionResult.success(refreshAfterAction = true)
                }

                override fun logInfo(message: String) = Log.member(message)
                override fun logError(message: String) = Log.error(TAG, message)
            }, roundSleepMs = 255L).run()
        } catch (t: Throwable) {
            if (t is CancellationException || t is InterruptedException) throw t
            TaskExecutionReport.current()?.recordException()
            Log.printStackTrace(TAG, "collectMemberTaskProcessAwards err:", t)
        }
        claimedCount
    }

    private fun resolveMemberTaskQueryStopReason(jsonObject: JSONObject): String? {
        if (RpcDailyCircuit.isStopResponse(jsonObject)) return "RPC_DAILY_RISK_STOP"
        if (stopMemberCoreTasksForRpcRisk("AntMember.memberTask", jsonObject)) {
            return "AUTH_LIKE"
        }
        if (ApplicationHookConstants.isOffline()) {
            return "OFFLINE_MODE"
        }
        val code = RpcOfflineRisk.extractCode(jsonObject)
        val desc = RpcOfflineRisk.extractMessage(jsonObject)
        if (code == "I07" || desc.contains("离线模式")) {
            return "OFFLINE_MODE"
        }
        return null
    }

    private fun buildMemberTaskQueryStopMessage(stopReason: String, jsonObject: JSONObject): String {
        val detail = sequenceOf(
            jsonObject.optString("resultDesc"),
            jsonObject.optString("memo"),
            jsonObject.optString("desc"),
            jsonObject.optString("errorMessage"),
            jsonObject.optString("errorMsg")
        ).firstOrNull { it.isNotBlank() }.orEmpty()
        return when (stopReason) {
            "RPC_DAILY_RISK_STOP" -> "该 RPC 今日因硬阻塞停止，结束当前执行($detail)"
            "AUTH_LIKE" -> "检测到验证/访问异常($detail)，停止当前执行"
            "OFFLINE_MODE" -> "检测到离线模式($detail)，停止当前执行"
            else -> "检测到异常($detail)，停止当前执行"
        }
    }

    private fun buildCurrentMemberTasks(
        jsonObject: JSONObject,
        skipBlacklisted: Boolean = true
    ): List<CurrentMemberTask> {
        val taskProcessObjects = collectCurrentMemberTaskProcessObjects(jsonObject)
        if (taskProcessObjects.isEmpty()) {
            return emptyList()
        }
        val taskList = mutableListOf<CurrentMemberTask>()
        val dedupKeys = LinkedHashSet<String>()
        for (taskProcessObject in taskProcessObjects) {
            if (isMemberTaskProcessFinished(taskProcessObject)) {
                continue
            }
            val simpleTaskConfig = resolveCurrentMemberTaskConfigObject(taskProcessObject) ?: continue
            // 累计福利由阶段奖励链读取实际领奖状态，不作为独立浏览动作。
            if (simpleTaskConfig.optString("taskStyle") == "WELFARE_TASK" &&
                simpleTaskConfig.optJSONArray("stageProcessList") != null
            ) continue
            val title = simpleTaskConfig.optString("title").ifEmpty {
                simpleTaskConfig.optString("name").ifEmpty { "会员任务" }
            }
            val unsupportedAdTaskReason = resolveUnsupportedMemberAdTaskReason(taskProcessObject, simpleTaskConfig)
            if (unsupportedAdTaskReason != null) {
                logSkippedMemberAdTask(title, unsupportedAdTaskReason)
                continue
            }
            val adBizId = resolveMemberAdTaskBizId(taskProcessObject, simpleTaskConfig)
            val taskConfigId = resolveCurrentMemberTaskConfigId(taskProcessObject) ?: continue
            if (skipBlacklisted && isMemberTaskInBlacklist(taskConfigId, title)) {
                Log.member("会员任务[$title]#任务在自动跳过列表(黑名单)中，跳过")
                continue
            }
            val targetBusiness = resolveSupportedMemberTaskTargetBusiness(
                taskProcessObject.optJSONArray("targetBusiness") ?: simpleTaskConfig.optJSONArray("targetBusiness")
            )
            val taskProcessId = taskProcessObject.optString("processId").ifEmpty {
                taskProcessObject.optString("taskProcessId")
            }
            val dedupKey = when {
                taskProcessId.isNotEmpty() -> taskProcessId
                adBizId.isNotEmpty() -> "$taskConfigId#$adBizId"
                else -> taskConfigId
            }
            if (!dedupKeys.add(dedupKey)) {
                continue
            }
            taskList.add(
                CurrentMemberTask(
                    taskConfigId = taskConfigId,
                    taskProcessId = taskProcessId,
                    title = title.ifEmpty { "任务$taskConfigId" },
                    awardPoint = extractMemberTaskAwardPoint(simpleTaskConfig),
                    targetBusiness = targetBusiness.raw,
                    targetBusinessType = targetBusiness.type,
                    simpleTaskConfig = JSONObject(simpleTaskConfig.toString()).apply {
                        taskProcessObject.optJSONObject("lightsAdExtMap")?.let { put("lightsAdExtMap", it) }
                        if (taskProcessObject.optJSONObject("extInfo")?.optString("memberTaskType") == "游戏任务") {
                            put("gameAppId", GameCenterPlayRpcCall.describeTask(simpleTaskConfig).gameAppId)
                        }
                    },
                    adBizId = adBizId,
                    status = taskProcessObject.optString("status").ifEmpty {
                        taskProcessObject.optString("subStatus")
                    },
                    current = extractCurrentMemberTaskCurrent(taskProcessObject),
                    limit = extractCurrentMemberTaskLimit(taskProcessObject)
                )
            )
        }
        return taskList
    }

    private fun currentMemberTaskToFlowItem(task: CurrentMemberTask): TaskFlowItem {
        val raw = JSONObject()
            .put("taskConfigId", task.taskConfigId)
            .put("taskProcessId", task.taskProcessId)
            .put("title", task.title)
            .put("awardPoint", task.awardPoint)
            .put("targetBusiness", task.targetBusiness)
            .put("targetBusinessType", task.targetBusinessType.name)
            .put("adBizId", task.adBizId)
            .put("simpleTaskConfig", task.simpleTaskConfig)
        return TaskFlowItem(
            id = task.taskConfigId,
            title = task.title,
            status = task.status,
            type = when {
                task.adBizId.isNotBlank() -> "AD_TASK"
                task.targetBusinessType == MemberTaskTargetBusinessType.CALL_APP -> "CALL_APP"
                task.targetBusinessType == MemberTaskTargetBusinessType.BROWSE -> "BROWSE"
                else -> "UNSUPPORTED"
            },
            actionType = when {
                task.adBizId.isNotBlank() -> "taskFinish"
                task.targetBusinessType == MemberTaskTargetBusinessType.CALL_APP -> "verifyCallApp"
                else -> "executeTask"
            },
            blacklistKeys = listOf(task.taskConfigId, task.title).filter { it.isNotBlank() },
            raw = raw,
            progress = buildCurrentMemberTaskProgress(task.current, task.limit),
            current = task.current,
            limit = task.limit
        )
    }

    private fun currentMemberTaskFromFlowItem(item: TaskFlowItem): CurrentMemberTask {
        val raw = item.raw ?: JSONObject()
        val targetBusiness = raw.optString("targetBusiness")
        val targetBusinessType = raw.optString("targetBusinessType").ifBlank {
            resolveSupportedMemberTaskTargetBusinessType(targetBusiness).name
        }
        return CurrentMemberTask(
            taskConfigId = raw.optString("taskConfigId").ifBlank { item.id },
            taskProcessId = raw.optString("taskProcessId"),
            title = raw.optString("title").ifBlank { item.title },
            awardPoint = raw.optString("awardPoint"),
            targetBusiness = targetBusiness,
            targetBusinessType = resolveMemberTaskTargetBusinessType(targetBusinessType),
            simpleTaskConfig = raw.optJSONObject("simpleTaskConfig") ?: JSONObject(),
            adBizId = raw.optString("adBizId"),
            status = item.status,
            current = item.current,
            limit = item.limit
        )
    }

    private fun buildCurrentMemberTaskFlowKey(task: CurrentMemberTask): String {
        return when {
            task.taskProcessId.isNotBlank() -> task.taskProcessId
            task.adBizId.isNotBlank() -> "${task.taskConfigId}#${task.adBizId}"
            else -> task.taskConfigId.ifBlank { task.title }
        }
    }

    private fun buildCurrentMemberTaskProgress(current: Int?, limit: Int?): String {
        return if (current != null && limit != null && limit > 0) {
            "$current/$limit"
        } else {
            ""
        }
    }

    private fun extractCurrentMemberTaskCurrent(taskProcessObject: JSONObject): Int? {
        val directCurrent = taskProcessObject.optInt("currentCount", Int.MIN_VALUE)
        if (directCurrent != Int.MIN_VALUE) {
            return directCurrent
        }
        return taskProcessObject.optJSONObject("extInfo")
            ?.optString("PERIOD_CURRENT_COUNT")
            ?.toIntOrNull()
    }

    private fun extractCurrentMemberTaskLimit(taskProcessObject: JSONObject): Int? {
        val directLimit = taskProcessObject.optInt("targetCount", Int.MIN_VALUE)
        if (directLimit != Int.MIN_VALUE) {
            return directLimit
        }
        return taskProcessObject.optJSONObject("extInfo")
            ?.optString("PERIOD_TARGET_COUNT")
            ?.toIntOrNull()
    }

    private fun collectCurrentMemberTaskProcessObjects(responseObject: JSONObject): List<JSONObject> {
        val taskProcessObjects = mutableListOf<JSONObject>()
        appendCurrentMemberTaskProcessObjects(taskProcessObjects, responseObject.optJSONArray("availableTaskProcessList"))
        appendCurrentMemberTaskProcessObjects(taskProcessObjects, responseObject.optJSONArray("availableTaskConfigList"))

        val resultData = responseObject.optJSONObject("resultData") ?: responseObject
        appendCurrentMemberTaskProcessObjects(taskProcessObjects, resultData.optJSONArray("taskProcessVOList"))
        appendCurrentMemberTaskProcessObjects(taskProcessObjects, resultData.optJSONArray("taskHistoryVOList"))
        appendCurrentMemberTaskProcessObjects(taskProcessObjects, resultData.optJSONArray("pureTaskList"))
        appendCurrentMemberTaskProcessObjects(taskProcessObjects, resultData.optJSONArray("adTaskList"))
        appendCurrentMemberTaskProcessObjects(taskProcessObjects, resultData.optJSONArray("alipayGrowthTaskList"))
        appendCurrentMemberCategoryTaskProcessObjects(taskProcessObjects, resultData.optJSONArray("categoryTaskList"))
        appendCurrentMemberCategoryTaskProcessObjects(taskProcessObjects, resultData.optJSONArray("categoryTaskVOList"))
        return taskProcessObjects
    }

    private fun appendCurrentMemberTaskProcessObjects(target: MutableList<JSONObject>, taskArray: JSONArray?) {
        if (taskArray == null) {
            return
        }
        for (i in 0 until taskArray.length()) {
            taskArray.optJSONObject(i)?.let(target::add)
        }
    }

    private fun appendCurrentMemberCategoryTaskProcessObjects(target: MutableList<JSONObject>, categoryArray: JSONArray?) {
        if (categoryArray == null) {
            return
        }
        for (i in 0 until categoryArray.length()) {
            val categoryObject = categoryArray.optJSONObject(i) ?: continue
            appendCurrentMemberTaskProcessObjects(target, categoryObject.optJSONArray("taskProcessVOList"))
        }
    }

    private fun resolveCurrentMemberTaskConfigObject(taskProcessObject: JSONObject): JSONObject? {
        return taskProcessObject.optJSONObject("simpleTaskConfig")
            ?: taskProcessObject.optJSONObject("taskConfigInfo")
            ?: taskProcessObject.optJSONObject("taskConfig")
    }

    private fun hasCurrentMemberTaskSnapshot(jsonObject: JSONObject): Boolean {
        if (jsonObject.has("availableTaskProcessList") || jsonObject.has("availableTaskConfigList")) {
            return true
        }
        val resultData = jsonObject.optJSONObject("resultData") ?: return false
        return resultData.has("taskProcessVOList") ||
            resultData.has("taskHistoryVOList") ||
            resultData.has("categoryTaskList") ||
            resultData.has("categoryTaskVOList") ||
            resultData.has("pureTaskList") ||
            resultData.has("adTaskList") ||
            resultData.optString("playInstanceId").isNotBlank()
    }

    private fun dedupeCurrentMemberTasks(tasks: List<CurrentMemberTask>): List<CurrentMemberTask> {
        val dedupKeys = LinkedHashSet<String>()
        return tasks.filter { task ->
            val dedupKey = when {
                task.taskProcessId.isNotEmpty() -> task.taskProcessId
                task.adBizId.isNotEmpty() -> "${task.taskConfigId}#${task.adBizId}"
                else -> task.taskConfigId
            }
            dedupKeys.add(dedupKey)
        }
    }

    private fun markMemberTaskDoneToday(message: String) {
        setFlagToday(StatusFlags.FLAG_ANTMEMBER_MEMBER_TASK_EMPTY_TODAY)
        Log.member(message)
    }

    private suspend fun processMemberFloatingBallTaskCompat(): MemberFloatingBallTaskProcessState = CoroutineUtils.run {
        if (hasFlagToday(StatusFlags.FLAG_ANTMEMBER_MEMBER_FLOATING_BALL_FAILED_TODAY)) {
            return@run MemberFloatingBallTaskProcessState.STOPPED_TODAY
        }
        try {
            val floatingBallResponse = AntMemberRpcCall.querySignFloatingBall()
            val floatingBallObject = JSONObject(floatingBallResponse)
            val stopReason = resolveMemberTaskQueryStopReason(floatingBallObject)
            if (stopReason != null) {
                Log.error(TAG, "会员任务[浮球]#${buildMemberTaskQueryStopMessage(stopReason, floatingBallObject)}")
                return@run MemberFloatingBallTaskProcessState.UNKNOWN
            }
            if (!ResChecker.checkRes(TAG, floatingBallObject)) {
                Log.error(
                    "$TAG.processMemberFloatingBallTaskCompat",
                    "会员浮球查询失败: " + floatingBallObject.optString("resultDesc", floatingBallResponse)
                )
                return@run MemberFloatingBallTaskProcessState.UNKNOWN
            }
            if (floatingBallObject.optBoolean("allTaskCompleted")) {
                Log.member("会员任务[浮球]#今日浮球任务已全部完成")
                return@run MemberFloatingBallTaskProcessState.NO_TASK
            }
            val taskRef = buildMemberFloatingBallTaskRef(floatingBallObject)
                ?: return@run MemberFloatingBallTaskProcessState.NO_TASK
            if (isMemberTaskProcessFinishedStatus(taskRef.taskStatus)) {
                Log.member("会员任务[浮球]#当前浮球任务已完成，停止本轮继续刷新")
                return@run MemberFloatingBallTaskProcessState.NO_TASK
            }
            // video 入口也返回 MULTIPLE_TIMER_TASK，但应先处理广告任务，不能直接领取计时奖励。
            if (floatingBallObject.optString("playType").equals("video", ignoreCase = true)) {
                return@run if (tryProcessMemberFloatingBallAdTask(taskRef)) {
                    MemberFloatingBallTaskProcessState.RETRY_LATER
                } else {
                    MemberFloatingBallTaskProcessState.UNKNOWN
                }
            }
            if (!taskRef.taskType.equals("MULTIPLE_TIMER_TASK", true)) {
                Log.member("会员任务[浮球]#未适配任务类型${taskRef.taskType}，停止本轮继续刷新")
                return@run MemberFloatingBallTaskProcessState.UNKNOWN
            }

            if (taskRef.endDt > System.currentTimeMillis()) {
                scheduleMemberFloatingBallTask(taskRef)
                return@run MemberFloatingBallTaskProcessState.RETRY_LATER
            }

            val triggered = JSONObject(AntMemberRpcCall.triggerSignFloatingBall(taskRef.bizNo, taskRef.taskType))
            if (stopMemberCoreTasksForRpcRisk("AntMember.triggerSignFloatingBall", triggered)) {
                Log.error(TAG, "会员浮球完成受限[triggerSignFloatingBall]:$triggered")
                return@run MemberFloatingBallTaskProcessState.UNKNOWN
            }
            if (!ResChecker.checkRes(TAG, "会员浮球完成失败[triggerSignFloatingBall]:", triggered)) {
                Log.error(
                    TAG,
                    "会员浮球完成失败上下文: bizNo=${taskRef.bizNo}, taskType=${taskRef.taskType}, " +
                        "领取前快照=$floatingBallObject",
                )
                return@run MemberFloatingBallTaskProcessState.UNKNOWN
            }
            val completedTask = triggered.optJSONObject("currentTaskInfo")
            if (completedTask == null || completedTask.optString("bizNo") != taskRef.bizNo ||
                completedTask.optString("taskStatus") != "SUCCESS"
            ) {
                Log.member("会员任务[浮球]#完成动作已接受，等待当前轮状态确认")
                return@run MemberFloatingBallTaskProcessState.RETRY_LATER
            }
            UnifiedScheduler.cancelPersistentByDedupeKey(
                ApplicationHook.appContext,
                "$PERSISTENT_FLOATING_BALL_KIND:${AccountSessionCoordinator.currentUserId()}:${taskRef.bizNo}",
            )
            Log.member("会员任务[浮球]#本轮完成，奖励${completedTask.optInt("awardNum", 0)}积分")
            val nextTask = buildMemberFloatingBallTaskRef(triggered)
                ?.takeIf {
                    !triggered.optBoolean("allTaskCompleted") && it.bizNo != taskRef.bizNo &&
                        !isMemberTaskProcessFinishedStatus(it.taskStatus)
                }
            if (nextTask != null) scheduleMemberFloatingBallTask(nextTask)
            if (!tryProcessMemberFloatingBallAdTask(taskRef)) {
                if (hasFlagToday(StatusFlags.FLAG_ANTMEMBER_MEMBER_FLOATING_BALL_FAILED_TODAY)) {
                    return@run MemberFloatingBallTaskProcessState.UNKNOWN
                }
                Log.member("会员任务[浮球]#后续广告任务待确认，后续调度继续查询")
                return@run MemberFloatingBallTaskProcessState.RETRY_LATER
            }
            return@run if (nextTask != null) MemberFloatingBallTaskProcessState.RETRY_LATER
                else MemberFloatingBallTaskProcessState.PROCESSED
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            TaskExecutionReport.current()?.recordException()
            Log.printStackTrace(TAG, "processMemberFloatingBallTaskCompat err:", t)
            return@run MemberFloatingBallTaskProcessState.UNKNOWN
        }
    }.also { state ->
        if (state == MemberFloatingBallTaskProcessState.UNKNOWN) {
            setFlagToday(StatusFlags.FLAG_ANTMEMBER_MEMBER_FLOATING_BALL_FAILED_TODAY)
        }
    }

    private fun scheduleMemberTaskContinuation(waitKey: String, triggerAt: Long) {
        val context = ApplicationHook.appContext ?: return
        val owner = AccountSessionCoordinator.currentUserId()?.takeIf { it.isNotBlank() } ?: return
        val epoch = AccountSessionCoordinator.currentSessionEpoch()
        val childId = "$PERSISTENT_FLOATING_BALL_KIND:$owner:$waitKey:$triggerAt"
        val payload = JSONObject().put("child_kind", PERSISTENT_FLOATING_BALL_KIND)
            .put("owner_user_id", owner).put("session_epoch", epoch)
            .put("task_list", true).put("wait_key", waitKey)
        val schedule = UnifiedScheduler.schedulePersistentTrigger(
            context = context, name = "会员任务计时与回查", kind = PersistentScheduleKind.MODULE_CHILD,
            triggerAtMs = triggerAt, dedupeKey = childId, payloadJson = payload.toString(),
            ownerUserId = owner, sessionEpoch = epoch,
        )
        if (schedule.state == PersistentScheduleState.FAILED) {
            Log.error(TAG, "会员任务持久调度注册失败:${schedule.lastError}")
        }
        if (!hasChildTask(childId)) {
            addChildTask(ChildModelTask(
                id = childId, group = PERSISTENT_FLOATING_BALL_KIND, execTime = triggerAt,
                suspendRunnable = {
                    if (schedule.state == PersistentScheduleState.FAILED) {
                        triggerPersistentMemberFloatingBall(payload.toString(), schedule.id, "member_task_timer", persistent = false)
                    } else ScheduledTaskRouter.fire(context, schedule, "member_task_timer")
                },
            ))
        }
    }

    private fun scheduleMemberFloatingBallTask(taskRef: MemberFloatingBallTaskRef) {
        val context = ApplicationHook.appContext ?: return
        val ownerUserId = AccountSessionCoordinator.currentUserId()?.takeIf { it.isNotBlank() } ?: return
        val sessionEpoch = AccountSessionCoordinator.currentSessionEpoch()
        val childId = "$PERSISTENT_FLOATING_BALL_KIND:$ownerUserId:${taskRef.bizNo}"
        val triggerAt = max(System.currentTimeMillis(), taskRef.endDt)
        val payload = JSONObject()
            .put("child_kind", PERSISTENT_FLOATING_BALL_KIND)
            .put("owner_user_id", ownerUserId)
            .put("session_epoch", sessionEpoch)
        val schedule = UnifiedScheduler.schedulePersistentTrigger(
            context = context,
            name = "会员签到浮球",
            kind = PersistentScheduleKind.MODULE_CHILD,
            triggerAtMs = triggerAt,
            dedupeKey = childId,
            payloadJson = payload.toString(),
            ownerUserId = ownerUserId,
            sessionEpoch = sessionEpoch,
        )
        if (schedule.state == PersistentScheduleState.FAILED) {
            Log.error(TAG, "会员浮球持久调度注册失败:${schedule.lastError}，保留进程内等待")
        }
        if (!hasChildTask(childId)) {
            addChildTask(ChildModelTask(
                id = childId,
                group = PERSISTENT_FLOATING_BALL_KIND,
                execTime = triggerAt,
                suspendRunnable = {
                    if (schedule.state == PersistentScheduleState.FAILED) {
                        triggerPersistentMemberFloatingBall(schedule.payloadJson, schedule.id, "member_timer", persistent = false)
                    } else {
                        ScheduledTaskRouter.fire(context, schedule, "member_timer")
                    }
                },
            ))
        }
        if (schedule.state == PersistentScheduleState.SCHEDULED) {
            Log.member("会员任务[浮球]#已安排${TimeUtil.getCommonDate(triggerAt)}继续领取")
        }
    }

    internal fun triggerPersistentMemberFloatingBall(
        payloadJson: String,
        scheduleId: String,
        source: String,
        persistent: Boolean = true,
    ): Boolean {
        val payload = JSONObject(payloadJson)
        val ownerUserId = payload.optString("owner_user_id")
        return executePersistentChild(
            scheduleId = scheduleId,
            ownerUserId = ownerUserId,
            sessionEpoch = payload.optLong("session_epoch"),
            source = "member_floating_ball:$source",
            workflowQueue = memberFloatingBallQueue,
            persistent = persistent,
        ) {
            if (!isEnable()) return@executePersistentChild TaskExecutionOutcome.SKIPPED
            when (payload.optString("wait_key")) {
                "goldTicketBigPrize" -> {
                    if (enableGoldTicket?.value != true) return@executePersistentChild TaskExecutionOutcome.SKIPPED
                    doGoldTicketTask(doSignIn = true, doConsume = false)
                    return@executePersistentChild TaskExecutionReport.current()?.outcome() ?: TaskExecutionOutcome.DEFERRED
                }
                "goldTicketConsumePending" -> {
                    if (enableGoldTicketConsume?.value != true ||
                        UserDataStoreManager.getInstance(ownerUserId)
                            ?.get("goldTicketConsumePending", String::class.java).isNullOrBlank()
                    ) return@executePersistentChild TaskExecutionOutcome.SKIPPED
                    doGoldTicketConsume(allowReplenish = false)
                    return@executePersistentChild TaskExecutionReport.current()?.outcome() ?: TaskExecutionOutcome.DEFERRED
                }
                "memberGameEntrance" -> {
                    if ((memberSign?.value != true && memberTask?.value != true) ||
                        hasFlagToday(StatusFlags.FLAG_ANTMEMBER_MEMBER_TASK_EMPTY_TODAY)
                    ) return@executePersistentChild TaskExecutionOutcome.SKIPPED
                    doMemberGameEntrance()
                    return@executePersistentChild TaskExecutionReport.current()?.outcome() ?: TaskExecutionOutcome.DEFERRED
                }
                "memberExternalGameCenter" -> {
                    if (enableGameCenter?.value != true) return@executePersistentChild TaskExecutionOutcome.SKIPPED
                    runExternalGameCenter()
                    return@executePersistentChild TaskExecutionReport.current()?.outcome() ?: TaskExecutionOutcome.DEFERRED
                }
            }
            if (memberTask?.value != true) return@executePersistentChild TaskExecutionOutcome.SKIPPED
            if (hasFlagToday(StatusFlags.FLAG_ANTMEMBER_MEMBER_TASK_EMPTY_TODAY)) {
                return@executePersistentChild TaskExecutionOutcome.SUCCESS
            }
            if (payload.optBoolean("task_list")) {
                val result = processCurrentMemberTaskListCompat()
                if (!ApplicationHookConstants.isOffline()) {
                    collectMemberTaskProcessAwards()
                    queryPointCert(1, 20)
                }
                when (result) {
                    CurrentMemberTaskListProcessState.COMPLETED -> {
                        UserDataStoreManager.getInstance(ownerUserId)?.remove(payload.optString("wait_key"))
                        TaskExecutionOutcome.SUCCESS
                    }
                    CurrentMemberTaskListProcessState.UNKNOWN -> TaskExecutionOutcome.FAILED
                    else -> TaskExecutionOutcome.DEFERRED
                }
            } else {
                when (processMemberFloatingBallTaskCompat()) {
                    MemberFloatingBallTaskProcessState.UNKNOWN -> TaskExecutionOutcome.FAILED
                    MemberFloatingBallTaskProcessState.STOPPED_TODAY -> TaskExecutionOutcome.SKIPPED
                    MemberFloatingBallTaskProcessState.RETRY_LATER -> TaskExecutionOutcome.DEFERRED
                    MemberFloatingBallTaskProcessState.PROCESSED,
                    MemberFloatingBallTaskProcessState.NO_TASK -> TaskExecutionOutcome.SUCCESS
                }
            }
        }
    }

    private fun isMemberTaskProcessInProgressStatus(status: String): Boolean {
        return status.uppercase(Locale.ROOT) in setOf(
            "PROCESSING",
            "RUNNING",
            "IN_PROGRESS",
            "PENDING",
            "WAITING",
            "WAIT_COMPLETE",
        )
    }

    private fun buildMemberFloatingBallTaskRef(jsonObject: JSONObject): MemberFloatingBallTaskRef? {
        val currentTaskInfo = jsonObject.optJSONObject("currentTaskInfo")
        val nextTaskInfo = jsonObject.optJSONObject("nextTaskInfo")
        val activeTaskInfo = when {
            currentTaskInfo == null -> nextTaskInfo
            isMemberTaskProcessFinishedStatus(currentTaskInfo.optString("taskStatus")) &&
                nextTaskInfo != null &&
                !isMemberTaskProcessFinishedStatus(nextTaskInfo.optString("taskStatus")) -> nextTaskInfo

            else -> currentTaskInfo
        } ?: return null
        val bizNo = sequenceOf(
            activeTaskInfo.optString("bizNo"),
            jsonObject.optString("bizNo")
        ).firstOrNull { it.isNotBlank() }.orEmpty()
        val taskType = sequenceOf(
            jsonObject.optString("taskType"),
            activeTaskInfo.optString("taskType")
        ).firstOrNull { it.isNotBlank() }.orEmpty()
        if (bizNo.isBlank() || taskType.isBlank()) {
            return null
        }
        val adTaskType = resolveMemberFloatingBallAdTaskType(jsonObject, activeTaskInfo)
        return MemberFloatingBallTaskRef(
            bizNo = bizNo,
            taskType = taskType,
            adTaskType = adTaskType,
            taskStatus = activeTaskInfo.optString("taskStatus"),
            endDt = activeTaskInfo.optLong("endDt", 0L),
            executeTimeSeconds = activeTaskInfo.optLong("executeTime", 0L)
        )
    }

    private suspend fun tryProcessMemberFloatingBallAdTask(taskRef: MemberFloatingBallTaskRef): Boolean = CoroutineUtils.run {
        try {
            if (TaskBlacklist.isTaskInBlacklist(memberTaskBlacklistModule, memberFloatingBallAdTaskTitle)) {
                Log.member("会员任务[浮球]#$memberFloatingBallAdTaskTitle 已在黑名单，跳过后续广告任务")
                return@run true
            }
            val adTaskResponse = AntMemberRpcCall.querySignFloatingBallAdTask(taskRef.bizNo, taskRef.adTaskType)
            val adTaskObject = JSONObject(adTaskResponse)
            if (!ResChecker.checkRes(TAG, adTaskObject)) {
                Log.error(
                    "$TAG.tryProcessMemberFloatingBallAdTask",
                    "会员浮球广告任务查询失败: " + adTaskObject.optString("resultDesc", adTaskResponse)
                )
                setFlagToday(StatusFlags.FLAG_ANTMEMBER_MEMBER_FLOATING_BALL_FAILED_TODAY)
                return@run false
            }
            val adTaskInfoObjects = listOfNotNull(
                adTaskObject.optJSONObject("taskInfo"),
                adTaskObject.optJSONObject("currentTaskInfo"),
                adTaskObject.optJSONObject("nextTaskInfo"),
                adTaskObject.optJSONObject("videoTaskInfo"),
            )
            val inProgressStatus = adTaskInfoObjects
                .asSequence()
                .map { it.optString("taskStatus") }
                .firstOrNull { isMemberTaskProcessInProgressStatus(it) }
            if (inProgressStatus != null) {
                Log.member("会员任务[浮球]#广告任务状态${inProgressStatus}，尚未确认完成")
                return@run false
            }
            val floatingBallAdTask = buildCurrentMemberTaskFromFloatingBallAdResponse(adTaskObject)
            if (floatingBallAdTask == null) {
                Log.member("会员任务[浮球]#广告查询成功，当前未返回可执行的广告对象")
                return@run false
            }
            val result = finishMemberAdTask(
                floatingBallAdTask.taskConfigId,
                floatingBallAdTask.title,
                floatingBallAdTask.awardPoint,
                floatingBallAdTask.adBizId
            )
            if (!result.success) {
                setFlagToday(StatusFlags.FLAG_ANTMEMBER_MEMBER_FLOATING_BALL_FAILED_TODAY)
            }
            return@run result.success
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            TaskExecutionReport.current()?.recordException()
            Log.printStackTrace(TAG, "tryProcessMemberFloatingBallAdTask err:", t)
            setFlagToday(StatusFlags.FLAG_ANTMEMBER_MEMBER_FLOATING_BALL_FAILED_TODAY)
            return@run false
        }
    }

    private fun resolveMemberFloatingBallAdTaskType(
        jsonObject: JSONObject,
        activeTaskInfo: JSONObject
    ): String {
        val explicitAdTaskType = sequenceOf(
            activeTaskInfo.optString("adType"),
            activeTaskInfo.optString("adTaskType"),
            jsonObject.optString("adType"),
            jsonObject.optString("adTaskType")
        ).firstOrNull { it.isNotBlank() }
        if (!explicitAdTaskType.isNullOrBlank()) {
            return explicitAdTaskType
        }
        val playType = jsonObject.optString("playType")
        return when (playType.lowercase(Locale.ROOT)) {
            "treasure" -> "AD_MIXED_TASK"
            "video" -> "AD_VIDEO_TASK"
            else -> if (jsonObject.optBoolean("openGuessPrice", false)) {
                "AD_MIXED_TASK"
            } else {
                "AD_VIDEO_TASK"
            }
        }
    }

    private fun buildCurrentMemberTaskFromFloatingBallAdResponse(responseObject: JSONObject): CurrentMemberTask? {
        val taskConfigObject = responseObject.optJSONObject("taskInfo")
            ?: responseObject.optJSONObject("currentTaskInfo")
            ?: responseObject.optJSONObject("nextTaskInfo")
            ?: responseObject.optJSONObject("videoTaskInfo")
            ?: responseObject
        val adBizId = resolveMemberAdTaskBizId(responseObject, taskConfigObject)
            .ifEmpty { resolveMemberAdTaskBizId(taskConfigObject, taskConfigObject) }
        if (adBizId.isBlank()) {
            return null
        }
        val taskConfigId = resolveCurrentMemberTaskConfigId(taskConfigObject)
            ?: resolveFallbackMemberTaskConfigId(responseObject, taskConfigObject)
            ?: return null
        val title = sequenceOf(
            taskConfigObject.optString("title"),
            taskConfigObject.optString("name"),
            responseObject.optJSONObject("extendInfo")?.optJSONObject("taskInfo")?.optString("taskTitle")
        ).firstOrNull { !it.isNullOrBlank() }.orEmpty().ifEmpty { "会员任务$taskConfigId" }
        val awardPoint = sequenceOf(
            taskConfigObject.optString("awardNum"),
            responseObject.optJSONObject("extendInfo")?.optJSONObject("rewardInfo")?.optString("rewardAmount")
        ).firstOrNull { !it.isNullOrBlank() }.orEmpty()
        return CurrentMemberTask(
            taskConfigId = taskConfigId,
            taskProcessId = "",
            title = title,
            awardPoint = awardPoint,
            targetBusiness = "",
            simpleTaskConfig = taskConfigObject,
            adBizId = adBizId
        )
    }

    private fun resolveFallbackMemberTaskConfigId(responseObject: JSONObject, taskConfigObject: JSONObject): String? {
        val directCandidate = sequenceOf(
            responseObject.optString("configId"),
            taskConfigObject.optString("configId"),
            responseObject.optString("taskConfigId"),
            taskConfigObject.optString("taskConfigId")
        ).firstOrNull { it.isNotBlank() }
        if (!directCandidate.isNullOrBlank()) {
            return directCandidate
        }
        val taskId = taskConfigObject.optLong("id", 0L)
        return if (taskId > 0) taskId.toString() else null
    }

    private fun completeCurrentMemberTask(
        task: CurrentMemberTask,
        item: TaskFlowItem
    ): TaskFlowActionResult {
        if (task.adBizId.isNotEmpty()) {
            return finishMemberAdTask(
                task.taskConfigId, task.title, task.awardPoint, task.adBizId, item, task.simpleTaskConfig,
            )
        }

        if (task.taskProcessId.isBlank()) {
            return TaskFlowActionResult.failure(
                failureType = TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW,
                code = "TASK_PROCESS_ID_MISSING",
                message = "缺少taskProcessId，无法执行任务",
                rpc = "AntMemberRpcCall.executeMemberTask",
                detail = currentMemberTaskActionDetail(task, "execute")
            )
        }

        if (task.targetBusinessType == MemberTaskTargetBusinessType.CALL_APP) {
            return when (checkCurrentMemberTaskFinishedWithRetry(task)) {
                CurrentMemberTaskVerifyState.CONFIRMED -> {
                    if (task.awardPoint.isNotEmpty()) {
                        Log.member("会员任务[${task.title}]#CALL_APP任务已完成，获得积分${task.awardPoint}")
                    } else {
                        Log.member("会员任务[${task.title}]#CALL_APP任务已完成")
                    }
                    TaskFlowActionResult(success = true, code = "CONFIRMED", refreshAfterAction = true)
                }

                CurrentMemberTaskVerifyState.PARTIAL_REPEATABLE -> {
                    Log.member("会员任务[${task.title}]#CALL_APP任务本次完成但周期进度未满，等待后续调度确认")
                    TaskFlowActionResult(
                        success = true,
                        code = "VERIFY_PARTIAL",
                        refreshAfterAction = true,
                        progressChanged = false
                    )
                }

                CurrentMemberTaskVerifyState.UNCONFIRMED -> {
                    TaskFlowActionResult.failure(
                        failureType = TaskRpcFailureType.RETRYABLE_RPC,
                        code = "VERIFY_PENDING",
                        message = "CALL_APP任务领取后详情未确认完成",
                        rpc = "AntMemberRpcCall.querySingleTaskProcessDetail",
                        detail = currentMemberTaskActionDetail(task, "verifyCallApp"),
                        stopCurrentRound = true
                    )
                }
            }
        }

        if (task.targetBusinessType != MemberTaskTargetBusinessType.BROWSE) {
            return TaskFlowActionResult.failure(
                failureType = TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW,
                code = "TARGET_BUSINESS_UNSUPPORTED",
                message = "任务执行目标尚未解析，保留后续查询",
                rpc = "AntMemberRpcCall.executeMemberTask",
                detail = currentMemberTaskActionDetail(task, "execute")
            )
        }

        val targetBusinessArray = task.targetBusiness.split('#').dropLastWhile { it.isEmpty() }
        if (targetBusinessArray.size < 3) {
            return TaskFlowActionResult.failure(
                failureType = TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW,
                code = "TARGET_BUSINESS_INVALID",
                message = "缺少可闭环BROWSE字段",
                rpc = "AntMemberRpcCall.executeMemberTask",
                detail = currentMemberTaskActionDetail(task, "execute")
            )
        }

        val seconds = task.simpleTaskConfig.optInt("browseSeconds", 0).coerceAtLeast(0)
        val game = GameCenterPlayRpcCall.describeTask(task.simpleTaskConfig).contract
        val waitKey = "memberTaskWait:${task.taskProcessId}:${item.progress}"
        val store = UserDataStoreManager.getInstance(AccountSessionCoordinator.currentUserId() ?: UserMap.currentUid)
            ?: return TaskFlowActionResult.failure(
                TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW, message = "无法保存会员任务计时状态",
                detail = currentMemberTaskActionDetail(task, "wait"),
            )
        val now = System.currentTimeMillis()
        val saved = store.get(waitKey, String::class.java)
        val wait = saved?.let { JSONObject(it) } ?: JSONObject()
        if (wait.optBoolean("submitted")) {
            when (checkCurrentMemberTaskFinished(task)) {
                CurrentMemberTaskVerifyState.CONFIRMED -> {
                    store.remove(waitKey)
                    return TaskFlowActionResult.success(refreshAfterAction = true)
                }
                CurrentMemberTaskVerifyState.PARTIAL_REPEATABLE -> {
                    store.remove(waitKey)
                    return TaskFlowActionResult.success(refreshAfterAction = true, progressChanged = false)
                }
                CurrentMemberTaskVerifyState.UNCONFIRMED -> {
                    val attempts = wait.optInt("confirmAttempts")
                    if (attempts < MEMBER_CALL_APP_VERIFY_RETRY_LIMIT) {
                        wait.put("confirmAttempts", attempts + 1).put("readyAt", now)
                        store.put(waitKey, wait.toString())
                        scheduleMemberTaskContinuation(waitKey, wait.getLong("readyAt"))
                    }
                    return TaskFlowActionResult.defer(
                        DeferredReason.STATE_CONFIRMATION, message = "执行已提交，等待同一阶段完成确认",
                        rpc = "AntMemberRpcCall.querySingleTaskProcessDetail",
                        detail = currentMemberTaskActionDetail(task, "verify"),
                    )
                }
            }
        }
        if (game != null && seconds > 0) {
            var reported = wait.optInt("reported")
            while (reported < seconds) {
                if (ApplicationHookConstants.isOffline() || Thread.currentThread().isInterrupted) {
                    return TaskFlowActionResult.defer(
                        DeferredReason.STATE_CONFIRMATION, message = "会员游戏时长执行已中断", stopCurrentRound = true,
                    )
                }
                val chunk = minOf(30, seconds - reported)
                val ack = GameCenterPlayRpcCall.submitForAck(game.copy(playTime = chunk))
                if (!ack.accepted) return TaskFlowActionResult.failure(
                    ack.failureType, message = "会员游戏时长上报失败", raw = ack.raw,
                    rpc = "GameCenterPlayRpcCall.submit", detail = currentMemberTaskActionDetail(task, "duration"),
                )
                reported += chunk
                wait.put("reported", reported)
                store.put(waitKey, wait.toString())
            }
        }
        val bizType = targetBusinessArray[0]
        val bizSubType = targetBusinessArray[1]
        val bizParam = targetBusinessArray[2]
        wait.put("submitted", true).put("readyAt", now)
        store.put(waitKey, wait.toString())
        var executeResponse = ""
        val executeObject = try {
            executeResponse = AntMemberRpcCall.executeMemberTask(bizParam, bizSubType, bizType)
            JSONObject(executeResponse)
        } catch (t: Exception) {
            scheduleMemberTaskContinuation(waitKey, wait.getLong("readyAt"))
            if (t is kotlinx.coroutines.CancellationException) throw t
            return TaskFlowActionResult.failure(
                TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW, message = "会员任务提交结果未确认:${t.message}",
                rpc = "AntMemberRpcCall.executeMemberTask", raw = executeResponse,
                detail = currentMemberTaskActionDetail(task, "execute"), continueCurrentRoundOnFailure = true,
            )
        }
        val executeFailure = when {
            stopMemberCoreTasksForRpcRisk("AntMember.memberTask.execute", executeObject) ->
                memberDomainTaskFailureResult(item, executeObject, executeResponse,
                    "AntMemberRpcCall.executeMemberTask", currentMemberTaskActionDetail(task, "execute"))
            isSkippableMemberTaskRejection(executeObject) -> TaskFlowActionResult.failure(
                failureType = TaskRpcFailureType.BUSINESS_LIMIT,
                code = extractMemberDomainRpcCode(executeObject).ifBlank { "NOT_PROMO_RULE_QUALIFIED" },
                message = extractMemberDomainRpcMessage(executeObject).ifBlank { "不满足任务的营销规则条件" },
                rpc = "AntMemberRpcCall.executeMemberTask", raw = executeResponse,
                detail = currentMemberTaskActionDetail(task, "execute"),
            )
            !ResChecker.checkRes(TAG, "执行会员任务失败:", executeObject) ->
                memberDomainTaskFailureResult(item, executeObject, executeResponse,
                    "AntMemberRpcCall.executeMemberTask", currentMemberTaskActionDetail(task, "execute"))
            else -> null
        }
        if (executeFailure != null) {
            if ((executeObject.has("success") && !executeObject.optBoolean("success")) ||
                executeFailure.failureType !in setOf(TaskRpcFailureType.RETRYABLE_RPC, TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW)) {
                wait.remove("submitted")
                wait.remove("confirmAttempts")
                store.put(waitKey, wait.toString())
            } else {
                scheduleMemberTaskContinuation(waitKey, wait.getLong("readyAt"))
            }
            return executeFailure
        }

        return when (checkCurrentMemberTaskFinished(task)) {
            CurrentMemberTaskVerifyState.CONFIRMED -> {
                store.remove(waitKey)
                if (task.awardPoint.isNotEmpty()) {
                    Log.member("会员任务[${task.title}]#获得积分${task.awardPoint}")
                } else {
                    Log.member("会员任务[${task.title}]#任务完成")
                }
                TaskFlowActionResult(success = true, code = "CONFIRMED", refreshAfterAction = true)
            }

            CurrentMemberTaskVerifyState.PARTIAL_REPEATABLE -> {
                store.remove(waitKey)
                Log.member("会员任务[${task.title}]#本次完成但周期进度未满，等待后续调度确认")
                TaskFlowActionResult(
                    success = true,
                    code = "VERIFY_PARTIAL",
                    progressChanged = false
                )
            }

            CurrentMemberTaskVerifyState.UNCONFIRMED -> {
                scheduleMemberTaskContinuation(waitKey, wait.getLong("readyAt"))
                TaskFlowActionResult.defer(
                    DeferredReason.STATE_CONFIRMATION,
                    message = "执行成功，等待详情确认完成",
                    rpc = "AntMemberRpcCall.querySingleTaskProcessDetail",
                    detail = currentMemberTaskActionDetail(task, "verify"),
                )
            }
        }
    }

    private fun buildCurrentMemberTaskFromApplyResponse(
        original: CurrentMemberTask,
        applyObject: JSONObject
    ): CurrentMemberTask? {
        val taskProcessObject = applyObject.optJSONObject("resultData")?.optJSONObject("taskProcessVO")
            ?: applyObject.optJSONObject("taskProcessVO")
            ?: return null
        val simpleTaskConfig = JSONObject(original.simpleTaskConfig.toString()).apply {
            resolveCurrentMemberTaskConfigObject(taskProcessObject)?.let { config ->
                config.keys().forEach { key -> put(key, config.get(key)) }
            }
        }
        val taskConfigId = resolveCurrentMemberTaskConfigId(taskProcessObject) ?: original.taskConfigId
        val processId = taskProcessObject.optString("processId").ifEmpty {
            taskProcessObject.optString("taskProcessId")
        }
        val targetBusiness = resolveSupportedMemberTaskTargetBusiness(
            taskProcessObject.optJSONArray("targetBusiness") ?: simpleTaskConfig.optJSONArray("targetBusiness")
        )
        if (processId.isBlank()) {
            return null
        }
        return original.copy(
            taskConfigId = taskConfigId,
            taskProcessId = processId,
            title = simpleTaskConfig.optString("title").ifEmpty { original.title },
            awardPoint = extractMemberTaskAwardPoint(simpleTaskConfig).ifEmpty { original.awardPoint },
            targetBusiness = targetBusiness.raw,
            targetBusinessType = targetBusiness.type,
            simpleTaskConfig = simpleTaskConfig
        )
    }

    private fun checkCurrentMemberTaskFinished(task: CurrentMemberTask): CurrentMemberTaskVerifyState {
        return try {
            if (task.taskProcessId.isEmpty()) {
                return CurrentMemberTaskVerifyState.UNCONFIRMED
            }

            val detailResponse = AntMemberRpcCall.querySingleTaskProcessDetail(task.taskProcessId)
            val detailObject = JSONObject(detailResponse)
            if (stopMemberCoreTasksForRpcRisk("AntMember.memberTask.detail", detailObject)) {
                return CurrentMemberTaskVerifyState.UNCONFIRMED
            }
            if (!ResChecker.checkRes(TAG, "查询会员任务详情失败:", detailObject)) {
                Log.error(
                    "$TAG.checkCurrentMemberTaskFinished",
                    "会员任务详情响应失败: " + detailObject.optString("resultDesc", detailResponse)
                )
                return CurrentMemberTaskVerifyState.UNCONFIRMED
            }

            val taskProcessObject = detailObject.optJSONObject("resultData")?.optJSONObject("taskProcessVO")
                ?: detailObject.optJSONObject("taskProcessVO")
            when {
                isMemberTaskProcessFinished(taskProcessObject) -> CurrentMemberTaskVerifyState.CONFIRMED
                isRepeatableMemberTaskProgressIncomplete(taskProcessObject) -> CurrentMemberTaskVerifyState.PARTIAL_REPEATABLE
                else -> CurrentMemberTaskVerifyState.UNCONFIRMED
            }
        } catch (_: JSONException) {
            CurrentMemberTaskVerifyState.UNCONFIRMED
        }
    }

    private fun checkCurrentMemberTaskFinishedWithRetry(task: CurrentMemberTask): CurrentMemberTaskVerifyState {
        var lastState = CurrentMemberTaskVerifyState.UNCONFIRMED
        for (i in 0 until MEMBER_CALL_APP_VERIFY_RETRY_LIMIT) {
            lastState = checkCurrentMemberTaskFinished(task)
            if (lastState != CurrentMemberTaskVerifyState.UNCONFIRMED) {
                return lastState
            }
        }
        return lastState
    }

    private fun isRepeatableMemberTaskProgressIncomplete(taskProcessObject: JSONObject?): Boolean {
        val extInfo = taskProcessObject?.optJSONObject("extInfo") ?: return false
        val currentCount = extInfo.optString("PERIOD_CURRENT_COUNT").toIntOrNull() ?: return false
        val targetCount = extInfo.optString("PERIOD_TARGET_COUNT").toIntOrNull() ?: return false
        return targetCount > 0 && currentCount in 0 until targetCount
    }

    private fun resolveCurrentMemberTaskConfigId(taskObject: JSONObject): String? {
        val directValue = taskObject.optString("taskConfigId")
        if (directValue.isNotEmpty()) {
            return directValue
        }
        val simpleTaskConfig = taskObject.optJSONObject("simpleTaskConfig")
            ?: taskObject.optJSONObject("taskConfigInfo")
            ?: taskObject.optJSONObject("taskConfig")
        if (simpleTaskConfig != null) {
            val configId = simpleTaskConfig.optString("configId")
            if (configId.isNotEmpty()) {
                return configId
            }
            val taskConfigId = simpleTaskConfig.optString("taskConfigId")
            if (taskConfigId.isNotEmpty()) {
                return taskConfigId
            }
            val id = simpleTaskConfig.optLong("id", 0L)
            if (id > 0) {
                return id.toString()
            }
        }
        val id = taskObject.optLong("id", 0L)
        return if (id > 0) id.toString() else null
    }

    private fun isMemberTaskProcessFinished(taskProcessObject: JSONObject?): Boolean {
        if (taskProcessObject == null) {
            return false
        }
        val status = taskProcessObject.optString("status")
        if (isMemberTaskProcessFinishedStatus(status)) {
            return true
        }
        val subStatus = taskProcessObject.optString("subStatus")
        if (isMemberTaskProcessFinishedStatus(subStatus)) {
            return true
        }
        val currentCount = taskProcessObject.optLong("currentCount", -1L)
        val targetCount = taskProcessObject.optLong("targetCount", -1L)
        if (targetCount > 0 && currentCount >= targetCount) {
            return true
        }
        val extInfo = taskProcessObject.optJSONObject("extInfo")
        if (extInfo != null) {
            if (extInfo.optString("awardCurrentPoint").isNotEmpty() || extInfo.optString("awardSuccessTime").isNotEmpty()) {
                return true
            }
        }
        return false
    }

    private fun isMemberTaskProcessFinishedStatus(status: String): Boolean {
        return status.equals("AWARDED", true) ||
            status.equals("SUCCESS", true) ||
            status.equals("COMPLETE", true) ||
            status.equals("DONE", true) ||
            status.equals("FINISHED", true) ||
            status.equals("EXPIRED", true)
    }

    private fun extractMemberTaskAwardPoint(simpleTaskConfig: JSONObject): String {
        val stageVOList = simpleTaskConfig.optJSONArray("stageVOList")
        if (stageVOList != null && stageVOList.length() > 0) {
            val stageObject = stageVOList.optJSONObject(0)
            val awardParam = stageObject?.optJSONObject("awardParam")
            val awardPoint = awardParam?.optString("awardParamPoint").orEmpty()
            if (awardPoint.isNotEmpty()) {
                return awardPoint
            }
        }
        return simpleTaskConfig.optJSONObject("awardParam")?.optString("awardParamPoint").orEmpty()
    }

    private fun isSkippableMemberTaskRejection(response: JSONObject): Boolean {
        val resultCode = response.optString("resultCode").ifEmpty {
            response.optString("errorCode")
        }
        val resultDesc = response.optString("resultDesc").ifEmpty {
            response.optString("errorMsg")
        }
        return resultCode == "NOT_PROMO_RULE_QUALIFIED" ||
            resultDesc.contains("不满足任务的营销规则条件")
    }

    private fun memberDomainTaskFailureResult(
        item: TaskFlowItem?,
        responseObject: JSONObject,
        rawResponse: String,
        rpc: String,
        detail: String
    ): TaskFlowActionResult {
        val code = extractMemberDomainRpcCode(responseObject)
        val message = extractMemberDomainRpcMessage(responseObject)
        val failureType = classifyMemberDomainTaskFailure(code, message, responseObject)
        stopMemberCoreTasksForRpcRisk("AntMember.memberTask.$rpc", code, message)
        return TaskFlowActionResult.failure(
            failureType = failureType,
            code = code,
            message = message,
            rpc = rpc,
            raw = rawResponse,
            detail = detail.ifBlank {
                item?.let {
                    "taskId=${it.id} taskName=${it.title} status=${it.status} actionType=${it.actionType}"
                }.orEmpty()
            },
            stopCurrentRound = failureType == TaskRpcFailureType.RETRYABLE_RPC
        )
    }

    private fun extractMemberDomainRpcCode(responseObject: JSONObject): String {
        val data = responseObject.optJSONObject("data")
        return sequenceOf(
            responseObject.optString("resultCode"),
            responseObject.optString("code"),
            responseObject.optString("errorCode"),
            responseObject.optString("errCode"),
            responseObject.opt("error")?.toString().orEmpty(),
            responseObject.optString("errorTip"),
            data?.optString("resultCode").orEmpty(),
            data?.optString("errorCode").orEmpty()
        ).firstOrNull { it.isNotBlank() && it != "0" }.orEmpty()
    }

    private fun extractMemberDomainRpcMessage(responseObject: JSONObject): String {
        val data = responseObject.optJSONObject("data")
        return sequenceOf(
            responseObject.optString("resultDesc"),
            responseObject.optString("resultMsg"),
            responseObject.optString("memo"),
            responseObject.optString("errorMessage"),
            responseObject.optString("errorMsg"),
            responseObject.optString("errMsg"),
            responseObject.optString("resultView"),
            responseObject.optString("desc"),
            data?.optString("resultDesc").orEmpty(),
            data?.optString("errorMsg").orEmpty()
        ).firstOrNull { it.isNotBlank() }.orEmpty().ifBlank {
            responseObject.toString()
        }
    }

    internal fun classifyMemberDomainTaskFailure(
        code: String,
        message: String,
        responseObject: JSONObject
    ): TaskRpcFailureType {
        return when {
            containsAny(
                message,
                "已领取",
                "已经领取",
                "重复领取",
                "重复领奖",
                "重复完成",
                "已完成",
                "已报名",
                "已经报名",
                "重复报名",
                "今日已签到",
                "任务已完结",
                "任务已结束"
            ) -> TaskRpcFailureType.TERMINAL_DONE

            code == "400000040" ||
                containsAny(message, "不支持rpc调用", "不支持RPC完成") ->
                TaskRpcFailureType.UNSUPPORTED_NO_CLOSURE

            code in setOf("20020012", "TASK_ID_INVALID", "ILLEGAL_ARGUMENT", "PROMISE_TEMPLATE_NOT_EXIST") ||
                containsAny(message, "参数错误", "参数非法", "任务ID非法", "模板不存在", "生活记录模板不存在") ->
                TaskRpcFailureType.NON_RETRYABLE_INVALID

            isMemberDomainMarkedRetryable(responseObject) ||
                code in setOf("3000", "1009", "I07", "REMOTE_INVOKE_EXCEPTION", "OP_REPEAT_CHECK", "SYSTEM_BUSY", "NETWORK_ERROR") ||
                containsAny(message, "系统出错", "系统繁忙", "稍后", "繁忙", "频繁", "重试", "需要验证", "访问异常") ->
                TaskRpcFailureType.RETRYABLE_RPC

            code.startsWith("100010") ||
                code.contains("LIMIT", ignoreCase = true) ||
                code == "NOT_PROMO_RULE_QUALIFIED" ||
                containsAny(message, "上限", "限制", "受限", "不可领取", "资格不足", "风控", "风险", "不满足任务的营销规则条件", "访问被拒绝") ->
                TaskRpcFailureType.BUSINESS_LIMIT

            else -> TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW
        }
    }

    private fun isMemberDomainMarkedRetryable(responseObject: JSONObject): Boolean {
        return listOf("retryable", "retriable", "canRetry").any { key ->
            responseObject.has(key) && responseObject.optBoolean(key, false)
        }
    }

    private fun currentMemberTaskActionDetail(task: CurrentMemberTask, action: String): String {
        return "taskConfigId=${task.taskConfigId.ifBlank { "UNKNOWN" }} " +
            "taskProcessId=${task.taskProcessId.ifBlank { "UNKNOWN" }} " +
            "taskName=${task.title.ifBlank { "UNKNOWN" }} status=${task.status.ifBlank { "UNKNOWN" }} " +
            "action=$action targetBusiness=${task.targetBusiness.ifBlank { "UNKNOWN" }} " +
            "adBizId=${task.adBizId.ifBlank { "NONE" }} progress=${buildCurrentMemberTaskProgress(task.current, task.limit).ifBlank { "UNKNOWN" }}"
    }

    private fun resolveInsuredGoldEntrance(vararg candidates: String?): String {
        return candidates.firstOrNull { !it.isNullOrBlank() } ?: AntMemberRpcCall.INSURED_GOLD_DEFAULT_ENTRANCE
    }

    /**
     * 保障金领取
     */
    private suspend fun collectInsuredGold(): Unit = CoroutineUtils.run {
        try {
            if (hasFlagToday(StatusFlags.FLAG_ANTMEMBER_INSURED_GOLD_DONE)) {
                Log.member("保障金🏥[今日已处理，跳过]")
                return@run
            }

            val insuredGoldEntrance = resolveInsuredGoldEntrance()
            var allHandled = warmUpInsuredGoldEntrance(insuredGoldEntrance)

            val handledInsuredGoldFlowNos = mutableSetOf<String>()
            var insuredGoldQueryRound = 0
            var shouldRecheckInsuredGold: Boolean
            do {
                insuredGoldQueryRound++
                val passResult = collectAvailableInsuredGoldOnce(handledInsuredGoldFlowNos, insuredGoldEntrance)
                if (passResult.result != DailyTaskProcessResult.HANDLED) {
                    allHandled = false
                }
                shouldRecheckInsuredGold = passResult.availableCount > 0 &&
                    insuredGoldQueryRound < INSURED_GOLD_WAIT_LIST_QUERY_LIMIT
                if (shouldRecheckInsuredGold) {
                    Log.member("保障金🏥[待领取气泡]#本轮处理${passResult.availableCount}项，复查是否还有新奖励")
                    if (!refreshInsuredGoldOpenState(insuredGoldEntrance)) {
                        allHandled = false
                    }
                }
            } while (shouldRecheckInsuredGold)

            val taskCenterResult = collectInsuredTaskCenterRewards(insuredGoldEntrance)
            if (allHandled && taskCenterResult == DailyTaskProcessResult.HANDLED) {
                setFlagToday(StatusFlags.FLAG_ANTMEMBER_INSURED_GOLD_DONE)
            }
        } catch (t: Throwable) {
            Log.printStackTrace("$TAG.collectInsuredGold", t)
        }
    }

    private fun collectAvailableInsuredGoldOnce(
        handledFlowNos: MutableSet<String>,
        entrance: String
    ): InsuredGoldCollectionPassResult {
        var availableCount = 0
        var passResult = DailyTaskProcessResult.HANDLED
        val response = AntMemberRpcCall.queryAvailableCollectInsuredGold(entrance)
        val responseObject = JSONObject(response)
        if (!ResChecker.checkRes(TAG, responseObject)) {
            Log.error("$TAG.collectInsuredGold.queryInsuredHome", "保障金🏥[响应失败]#$response")
            return InsuredGoldCollectionPassResult(availableCount, DailyTaskProcessResult.UNKNOWN_FAILURE)
        }
        val data = responseObject.optJSONObject("data")
        if (data == null) {
            Log.error("$TAG.collectInsuredGold.queryInsuredHome", "保障金🏥[响应缺少data]#$response")
            return InsuredGoldCollectionPassResult(availableCount, DailyTaskProcessResult.UNKNOWN_FAILURE)
        }

        val signInBall = data.optJSONObject("signInDTO")
        if (signInBall != null &&
            signInBall.optInt("sendFlowStatus") == 1 &&
            signInBall.optInt("sendType") == 1
        ) {
            val sendFlowNo = signInBall.optString("sendFlowNo")
            if (sendFlowNo.isBlank() || handledFlowNos.add(sendFlowNo)) {
                availableCount++
                passResult = mergeDailyTaskProcessResult(
                    passResult,
                    collectSingleInsuredGold(
                        signInBall,
                        true,
                        resolveInsuredGoldEntrance(
                            data.optString("entrance"),
                            data.optString("channelType"),
                            entrance,
                        ),
                    ),
                )
            }
        }

        val responseEntrance = resolveInsuredGoldEntrance(
            data.optString("entrance"),
            data.optString("channelType"),
            entrance,
        )
        val otherBallList = data.optJSONArray("eventToWaitDTOList") ?: JSONArray()
        for (i in 0 until otherBallList.length()) {
            val anotherBall = otherBallList.optJSONObject(i) ?: continue
            if (anotherBall.optInt("sendType") != 1) {
                continue
            }
            val sendFlowNo = anotherBall.optString("sendFlowNo")
            if (sendFlowNo.isNotBlank() && !handledFlowNos.add(sendFlowNo)) {
                continue
            }
            availableCount++
            passResult = mergeDailyTaskProcessResult(passResult, collectSingleInsuredGold(anotherBall, false, responseEntrance))
        }

        return InsuredGoldCollectionPassResult(availableCount, passResult)
    }

    private fun warmUpInsuredGoldEntrance(entrance: String): Boolean {
        return try {
            val response = AntMemberRpcCall.queryInsuredOpenAndAllowAndUpgrade(entrance)
            val responseObject = JSONObject(response)
            var success = if (ResChecker.checkRes("$TAG.collectInsuredGold.queryOpenAndAllowAndUpgrade", responseObject)) {
                true
            } else {
                Log.member("保障金🏥[访问预热]#响应失败，继续查询待领取奖励:$response")
                false
            }

            val homeRenderResponse = AntMemberRpcCall.queryInsuredGiftHomeRender(entrance)
            val homeRenderObject = JSONObject(homeRenderResponse)
            if (!ResChecker.checkRes("$TAG.collectInsuredGold.giftHomeRender", homeRenderObject)) {
                Log.member("保障金🏥[访问预热]#页面渲染失败，继续查询待领取奖励:$homeRenderResponse")
                success = false
            }
            refreshInsuredGoldOpenState(entrance) && success
        } catch (t: Throwable) {
            Log.printStackTrace("$TAG.collectInsuredGold.queryOpenAndAllowAndUpgrade", t)
            false
        }
    }

    private fun refreshInsuredGoldOpenState(entrance: String): Boolean {
        return runCatching {
            val response = AntMemberRpcCall.queryInsuredOpenAndAllow(entrance)
            val responseObject = JSONObject(response)
            if (ResChecker.checkRes("$TAG.collectInsuredGold.queryOpenAndAllow", responseObject)) {
                return@runCatching true
            }
            Log.member("保障金🏥[开放状态查询]#响应失败，继续当前链路:$response")
            false
        }.onFailure {
            Log.printStackTrace("$TAG.collectInsuredGold.queryOpenAndAllow", it)
        }.getOrDefault(false)
    }

    private fun collectSingleInsuredGold(
        goldBall: JSONObject,
        isSignIn: Boolean,
        entrance: String
    ): DailyTaskProcessResult {
        val title = resolveInsuredGoldTitle(goldBall, isSignIn)
        if (goldBall.optString("sendFlowNo").isBlank()) {
            Log.member("保障金🏥[$title]#缺少sendFlowNo，跳过")
            return DailyTaskProcessResult.UNKNOWN_FAILURE
        }
        val resolvedEntrance = resolveInsuredGoldEntrance(
            goldBall.optString("entrance"),
            goldBall.optString("channelType"),
            entrance,
        )
        val requestObject = buildInsuredGoldGainRequest(goldBall, isSignIn, resolvedEntrance)
        val response = AntMemberRpcCall.collectInsuredGold(requestObject)
        val responseObject = JSONObject(response)
        if (!ResChecker.checkRes(TAG, responseObject)) {
            return logInsuredGoldFailure(title, responseObject, response)
        }
        val gainGold = extractInsuredGoldGainYuan(responseObject)
        if (gainGold.isBlank()) {
            Log.member("保障金🏥[$title]#领取成功，返回未包含金额")
        } else {
            Log.member("保障金🏥[$title]#+" + gainGold + "元")
        }
        return DailyTaskProcessResult.HANDLED
    }

    private suspend fun collectInsuredTaskCenterRewards(entrance: String): DailyTaskProcessResult {
        var overallResult = DailyTaskProcessResult.HANDLED
        var taskCount = 0
        for (config in insuredTaskCenterConfigs) {
            val adapter = InsuredTaskCenterFlowAdapter(config, entrance)
            val runResult = TaskFlowEngine(adapter, roundSleepMs = 425L).run()
            taskCount += adapter.taskCount
            val configResult = when {
                adapter.queryFailed || adapter.hasBlockingFailure -> DailyTaskProcessResult.UNKNOWN_FAILURE
                adapter.hasRetryableFailure || runResult.stopped -> DailyTaskProcessResult.RETRYABLE_FAILURE
                adapter.hasPendingManualTask -> DailyTaskProcessResult.PENDING
                else -> DailyTaskProcessResult.HANDLED
            }
            overallResult = mergeDailyTaskProcessResult(overallResult, configResult)
        }
        if (taskCount == 0 && overallResult == DailyTaskProcessResult.HANDLED) {
            Log.member("保障金🏥[任务中心]#无可处理任务")
        }
        return overallResult
    }

    private fun insuredTaskCenterDoneFlag(config: InsuredTaskCenterConfig): String =
        StatusFlags.FLAG_ANTMEMBER_INSURED_TASK_CENTER_DONE_PREFIX + config.taskCenterId + "::" + config.sceneCode

    private inner class InsuredTaskCenterFlowAdapter(
        private val config: InsuredTaskCenterConfig,
        private val entrance: String
    ) : TaskFlowAdapter {
        override val moduleName: String = insuredTaskBlacklistModule
        override val flowName: String = "保障金🏥任务中心(${config.sceneCode})"

        var queryFailed: Boolean = false
            private set
        var hasBlockingFailure: Boolean = false
            private set
        var hasRetryableFailure: Boolean = false
            private set
        var hasPendingManualTask: Boolean = false
            private set
        var taskCount: Int = 0
            private set

        private val signedUpTaskKeys = LinkedHashSet<String>()
        private val completedTaskKeys = LinkedHashSet<String>()
        private val loggedSkipTaskKeys = LinkedHashSet<String>()

        override fun isFlowHandledToday(): Boolean =
            hasFlagToday(insuredTaskCenterDoneFlag(config))

        override fun query(): JSONObject {
            return try {
                val response = AntMemberRpcCall.queryInsuredTaskListV2(
                    config.taskCenterId,
                    config.sceneCode,
                    entrance,
                    config.controlSolutionSceneCode
                )
                val responseObject = JSONObject(response)
                val hasData = responseObject.optJSONObject("data") != null
                val success = ResChecker.checkRes(TAG, responseObject) && hasData
                if (!hasData) {
                    responseObject.put("_taskFlowResultDesc", "响应缺少data")
                }
                responseObject
                    .put("_taskFlowQuerySuccess", success)
                    .put("_rawResponse", response)
                    .put("_taskCenterId", config.taskCenterId)
                    .put("_sceneCode", config.sceneCode)
            } catch (t: Throwable) {
                JSONObject()
                    .put("_taskFlowQuerySuccess", false)
                    .put("resultDesc", "查询异常:${t.message}")
                    .put("_taskCenterId", config.taskCenterId)
                    .put("_sceneCode", config.sceneCode)
            }
        }

        override fun isQuerySuccess(response: JSONObject): Boolean {
            return response.optBoolean("_taskFlowQuerySuccess", false)
        }

        override fun extractItems(response: JSONObject): List<TaskFlowItem> {
            val taskList = response.optJSONObject("data")?.optJSONArray("taskDetailList") ?: JSONArray()
            taskCount = max(taskCount, taskList.length())
            val items = mutableListOf<TaskFlowItem>()
            for (i in 0 until taskList.length()) {
                val task = taskList.optJSONObject(i) ?: continue
                val taskId = resolveInsuredTaskId(task)
                val title = resolveInsuredTaskTitle(task, taskId)
                val customInfo = resolveInsuredTaskCustomInfo(task)
                val taskMainType = task.optString("taskMainType")
                val taskType = customInfo.optString("taskType").ifBlank { taskMainType }
                val operationType = customInfo.optString("taskOperationType").ifBlank {
                    task.optString("operationType")
                }
                val rawTask = JSONObject(task.toString())
                    .put("_taskCenterId", config.taskCenterId)
                    .put("_sceneCode", config.sceneCode)
                    .put("_controlSolutionSceneCode", config.controlSolutionSceneCode.orEmpty())
                items.add(
                    TaskFlowItem(
                        id = taskId,
                        title = title,
                        status = task.optString("taskProcessStatus").trim(),
                        type = taskType,
                        sceneCode = config.sceneCode,
                        actionType = operationType,
                        blacklistKeys = listOf(taskId, title).filter { it.isNotBlank() },
                        raw = rawTask,
                        progress = resolveInsuredTaskPrizeText(task)
                    )
                )
            }
            return items
        }

        override fun mapPhase(item: TaskFlowItem): TaskFlowPhase {
            if (item.id.isBlank()) {
                return TaskFlowPhase.UNKNOWN
            }
            val taskKey = buildInsuredTaskFlowKey(item)
            if (taskKey in completedTaskKeys || hasInsuredTaskSendOrder(item.raw ?: JSONObject())) {
                return TaskFlowPhase.TERMINAL
            }

            return when (item.status.uppercase(Locale.ROOT)) {
                "TO_RECEIVE",
                "WAIT_RECEIVE",
                "FINISHED",
                "COMPLETE" -> TaskFlowPhase.REWARD_READY

                "",
                "NONE",
                "NONE_SIGNUP",
                "SIGNUP_EXPIRED" -> if (taskKey in signedUpTaskKeys) {
                    TaskFlowPhase.SIGNUP_COMPLETE
                } else {
                    TaskFlowPhase.SIGNUP_REQUIRED
                }

                "SIGNUP_COMPLETE" -> TaskFlowPhase.SIGNUP_COMPLETE

                "TODO",
                "NOT_DONE",
                "WAIT_COMPLETE" -> TaskFlowPhase.READY_TO_COMPLETE

                "SEND_SUCCESS",
                "RECEIVE_SUCCESS",
                "HAS_RECEIVED",
                "RECEIVED",
                "DONE",
                "COMPLETED",
                "COMPLETE_SUCCESS",
                "SUCCESS" -> TaskFlowPhase.TERMINAL

                else -> TaskFlowPhase.UNKNOWN
            }
        }

        override fun shouldSkip(item: TaskFlowItem): Boolean {
            val task = item.raw ?: return false
            if (item.id.isBlank()) {
                return false
            }
            if (buildInsuredTaskFlowKey(item) in completedTaskKeys ||
                hasInsuredTaskSendOrder(task) ||
                isInsuredTaskRewardReadyStatus(item.status)
            ) {
                return false
            }
            if (isSupportedInsuredBrowseTask(task)) {
                return false
            }

            if (isBlacklisted(item)) {
                logInsuredTaskSkipOnce(item, "任务在自动跳过列表(黑名单)中，跳过")
                return true
            }

            hasPendingManualTask = true
            logPendingInsuredTask(task, item.id, item.title)
            return true
        }

        override fun receive(item: TaskFlowItem): TaskFlowActionResult {
            return verifyInsuredTaskRewardAction(item, "receive")
        }

        override fun complete(item: TaskFlowItem): TaskFlowActionResult {
            return sendInsuredTaskAndVerify(item, TaskFlowAction.COMPLETE)
        }

        override fun signup(item: TaskFlowItem): TaskFlowActionResult {
            return triggerInsuredTaskStageAction(item, "signup")
        }

        override fun send(item: TaskFlowItem): TaskFlowActionResult {
            return sendInsuredTaskAndVerify(item, TaskFlowAction.SEND)
        }

        override fun actionKey(item: TaskFlowItem, action: TaskFlowAction): String {
            return "${action.logName}:${buildInsuredTaskFlowKey(item)}:${item.status}:${item.actionType}"
        }

        override fun afterSuccess(item: TaskFlowItem, action: TaskFlowAction, result: TaskFlowActionResult) {
            rememberSuccessfulInsuredTaskStage(item, action)
        }

        override fun afterFailure(
            item: TaskFlowItem,
            action: TaskFlowAction,
            result: TaskFlowActionResult,
            decision: TaskFlowDecision
        ) {
            when (decision) {
                TaskFlowDecision.MARK_HANDLED -> rememberSuccessfulInsuredTaskStage(item, action)
                TaskFlowDecision.RETRY_LATER -> hasRetryableFailure = true
                TaskFlowDecision.LOG_ONLY -> hasBlockingFailure = true
                TaskFlowDecision.STOP_TODAY_OR_CURRENT_CHAIN,
                TaskFlowDecision.BLACKLIST -> Unit
            }
        }

        override fun onAllTasksDone(snapshot: TaskFlowSnapshot) {
            if (!queryFailed && !hasBlockingFailure && !hasRetryableFailure && !hasPendingManualTask) {
                setFlagToday(insuredTaskCenterDoneFlag(config))
            }
            logInfo("$flowName[任务列表已处理完成：${snapshot.completedTasks}/${snapshot.totalTasks}]")
        }

        override fun onQueryFailed(response: JSONObject) {
            queryFailed = true
            val reason = response.optString("_taskFlowResultDesc")
                .ifBlank { response.optString("resultDesc") }
                .ifBlank { response.optString("memo") }
                .ifBlank { response.optString("errorMsg") }
                .ifBlank { response.toString() }
            Log.error(
                "$TAG.collectInsuredTaskCenterRewards.queryTaskListV2",
                "$flowName[任务查询失败] taskCenterId=${config.taskCenterId} sceneCode=${config.sceneCode} reason=$reason raw=${response.optString("_rawResponse")}"
            )
        }

        override fun onUnknownPhase(item: TaskFlowItem, phase: TaskFlowPhase) {
            hasBlockingFailure = true
            Log.error(
                TAG,
                "保障金🏥[任务中心-${item.title}]#未知状态 module=$moduleName taskId=${item.id.ifBlank { "UNKNOWN" }} " +
                    "status=${item.status.ifBlank { "UNKNOWN" }} actionType=${item.actionType.ifBlank { "UNKNOWN" }} raw=${item.raw}"
            )
        }

        override fun logInfo(message: String) {
            Log.member(message)
        }

        override fun logError(message: String) {
            Log.error(TAG, message)
        }

        private fun sendInsuredTaskAndVerify(
            item: TaskFlowItem,
            action: TaskFlowAction
        ): TaskFlowActionResult {
            val sendResult = triggerInsuredTaskStageAction(item, "send")
            if (!sendResult.success) {
                return sendResult
            }
            return verifyInsuredTaskRewardAction(item, action.logName)
        }

        private fun triggerInsuredTaskStageAction(
            item: TaskFlowItem,
            stageCode: String
        ): TaskFlowActionResult {
            if (item.id.isBlank()) {
                return invalidInsuredTaskActionResult(item, "taskTriggerv2/$stageCode")
            }
            val appletId = resolveInsuredTaskAppletId(item.raw ?: JSONObject())
            if (appletId.isBlank()) {
                return TaskFlowActionResult.failure(
                    failureType = TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW,
                    code = "TASK_APPLET_ID_MISSING",
                    message = "任务配置缺少appletId",
                    rpc = "AntMemberRpcCall.triggerInsuredTaskV2/$stageCode",
                    detail = insuredTaskActionDetail(item, stageCode) +
                        " taskConfigId=${item.raw?.optString("taskConfigId").orEmpty()} appletId=<empty>"
                )
            }
            val response = AntMemberRpcCall.triggerInsuredTaskV2(
                appletId,
                config.taskCenterId,
                config.sceneCode,
                stageCode
            )
            if (response.isBlank()) {
                return TaskFlowActionResult.failure(
                    failureType = TaskRpcFailureType.RETRYABLE_RPC,
                    message = "taskTriggerv2/$stageCode 返回空",
                    rpc = "AntMemberRpcCall.triggerInsuredTaskV2/$stageCode",
                    detail = insuredTaskActionDetail(item, stageCode),
                    stopCurrentRound = true
                )
            }
            val responseObject = JSONObject(response)
            if (!ResChecker.checkRes(TAG, responseObject)) {
                return insuredTaskActionFailureResult(
                    item = item,
                    stage = "taskTriggerv2/$stageCode",
                    responseObject = responseObject,
                    rawResponse = response,
                    rpc = "AntMemberRpcCall.triggerInsuredTaskV2/$stageCode"
                )
            }
            Log.member("保障金🏥[任务中心-${item.title}]#$stageCode 成功")
            return TaskFlowActionResult.success()
        }

        private fun verifyInsuredTaskRewardAction(
            item: TaskFlowItem,
            action: String
        ): TaskFlowActionResult {
            if (item.id.isBlank()) {
                return invalidInsuredTaskActionResult(item, "taskCenterConsultById")
            }
            val response = AntMemberRpcCall.consultInsuredTaskCenterById(config.taskCenterId, item.id)
            if (response.isBlank()) {
                return TaskFlowActionResult.failure(
                    failureType = TaskRpcFailureType.RETRYABLE_RPC,
                    message = "taskCenterConsultById返回空",
                    rpc = "AntMemberRpcCall.consultInsuredTaskCenterById",
                    detail = insuredTaskActionDetail(item, action),
                    stopCurrentRound = true
                )
            }
            val responseObject = JSONObject(response)
            if (!ResChecker.checkRes(TAG, responseObject)) {
                return insuredTaskActionFailureResult(
                    item = item,
                    stage = "taskCenterConsultById",
                    responseObject = responseObject,
                    rawResponse = response,
                    rpc = "AntMemberRpcCall.consultInsuredTaskCenterById"
                )
            }
            val taskDetail = responseObject.optJSONObject("data")?.optJSONObject("taskDetailWithFilterDTO")
            if (taskDetail == null) {
                return TaskFlowActionResult.failure(
                    failureType = TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW,
                    code = "TASK_DETAIL_MISSING",
                    message = "回查缺少taskDetailWithFilterDTO",
                    rpc = "AntMemberRpcCall.consultInsuredTaskCenterById",
                    raw = response,
                    detail = insuredTaskActionDetail(item, action)
                )
            }
            if (isInsuredTaskRewardConfirmed(taskDetail)) {
                val prizeText = resolveInsuredTaskPrizeText(taskDetail)
                val status = taskDetail.optString("taskProcessStatus")
                if (prizeText.isBlank()) {
                    Log.member("保障金🏥[任务中心-${item.title}]#领取完成:$status")
                } else {
                    Log.member("保障金🏥[任务中心-${item.title}]#$prizeText:$status")
                }
                return TaskFlowActionResult.success()
            }

            return TaskFlowActionResult.failure(
                failureType = TaskRpcFailureType.RETRYABLE_RPC,
                code = "VERIFY_PENDING",
                message = "回查未确认完成",
                rpc = "AntMemberRpcCall.consultInsuredTaskCenterById",
                raw = response,
                detail = insuredTaskActionDetail(item, action) +
                    " verifyStatus=${taskDetail.optString("taskProcessStatus").ifBlank { "UNKNOWN" }}",
                stopCurrentRound = true
            )
        }

        private fun rememberSuccessfulInsuredTaskStage(item: TaskFlowItem, action: TaskFlowAction) {
            val taskKey = buildInsuredTaskFlowKey(item)
            when (action) {
                TaskFlowAction.SIGNUP -> signedUpTaskKeys.add(taskKey)
                TaskFlowAction.RECEIVE,
                TaskFlowAction.COMPLETE,
                TaskFlowAction.SEND -> completedTaskKeys.add(taskKey)
            }
        }

        private fun buildInsuredTaskFlowKey(item: TaskFlowItem): String {
            return "${config.taskCenterId}|${item.id.ifBlank { item.title }}|${item.title}"
        }

        private fun logInsuredTaskSkipOnce(item: TaskFlowItem, reason: String) {
            val key = "$reason|${buildInsuredTaskFlowKey(item)}"
            if (loggedSkipTaskKeys.add(key)) {
                Log.member("保障金🏥[任务中心-${item.title}]#$reason:${item.id}")
            }
        }

        private fun invalidInsuredTaskActionResult(item: TaskFlowItem, stage: String): TaskFlowActionResult {
            return TaskFlowActionResult.failure(
                failureType = TaskRpcFailureType.NON_RETRYABLE_INVALID,
                code = "TASK_ID_INVALID",
                message = "任务ID为空",
                rpc = "AntMemberRpcCall.$stage",
                detail = insuredTaskActionDetail(item, stage)
            )
        }

        private fun insuredTaskActionFailureResult(
            item: TaskFlowItem,
            stage: String,
            responseObject: JSONObject,
            rawResponse: String,
            rpc: String
        ): TaskFlowActionResult {
            val code = extractInsuredTaskRpcCode(responseObject)
            val message = extractInsuredTaskRpcMessage(responseObject)
            val failureType = classifyInsuredTaskFailure(code, message, responseObject)
            return TaskFlowActionResult.failure(
                failureType = failureType,
                code = code,
                message = message,
                rpc = rpc,
                raw = rawResponse,
                detail = insuredTaskActionDetail(item, stage),
                stopCurrentRound = failureType == TaskRpcFailureType.RETRYABLE_RPC
            )
        }

        private fun insuredTaskActionDetail(item: TaskFlowItem, action: String): String {
            val raw = item.raw
            val customInfo = raw?.let { resolveInsuredTaskCustomInfo(it) } ?: JSONObject()
            val taskCategory = raw?.optString("taskCategory").orEmpty().ifBlank {
                customInfo.optString("taskCategorize")
            }
            return "taskCenterId=${config.taskCenterId} sceneCode=${config.sceneCode} " +
                "taskId=${item.id.ifBlank { "UNKNOWN" }} taskName=${item.title.ifBlank { "UNKNOWN" }} " +
                "status=${item.status.ifBlank { "UNKNOWN" }} action=$action " +
                "taskMainType=${raw?.optString("taskMainType").orEmpty().ifBlank { "UNKNOWN" }} " +
                "taskType=${item.type.ifBlank { "UNKNOWN" }} " +
                "operationType=${item.actionType.ifBlank { "UNKNOWN" }} " +
                "category=${taskCategory.ifBlank { "UNKNOWN" }}"
        }
    }

    private fun mergeDailyTaskProcessResult(
        current: DailyTaskProcessResult,
        next: DailyTaskProcessResult
    ): DailyTaskProcessResult {
        return when {
            current == DailyTaskProcessResult.UNKNOWN_FAILURE ||
                next == DailyTaskProcessResult.UNKNOWN_FAILURE -> DailyTaskProcessResult.UNKNOWN_FAILURE

            current == DailyTaskProcessResult.RETRYABLE_FAILURE ||
                next == DailyTaskProcessResult.RETRYABLE_FAILURE -> DailyTaskProcessResult.RETRYABLE_FAILURE

            current == DailyTaskProcessResult.PENDING ||
                next == DailyTaskProcessResult.PENDING -> DailyTaskProcessResult.PENDING

            else -> DailyTaskProcessResult.HANDLED
        }
    }

    private fun resolveInsuredTaskId(task: JSONObject): String {
        return task.optString("taskId").ifBlank {
            task.optJSONObject("taskConfig")?.optString("appletId").orEmpty()
        }
    }

    private fun resolveInsuredTaskAppletId(task: JSONObject): String {
        return task.optJSONObject("taskConfig")?.optString("appletId").orEmpty().ifBlank {
            task.optString("appletId")
        }.trim()
    }

    private fun resolveInsuredTaskTitle(task: JSONObject, fallback: String): String {
        val customInfo = resolveInsuredTaskCustomInfo(task)
        return customInfo.optString("taskMainTitle").ifBlank {
            task.optJSONObject("taskDisplayInfo")?.optString("taskMainTitle").orEmpty()
        }.ifBlank {
            task.optJSONObject("taskConfig")?.optString("appletName").orEmpty()
        }.ifBlank {
            fallback.ifBlank { "蚂蚁保任务" }
        }
    }

    private fun resolveInsuredTaskCustomInfo(task: JSONObject): JSONObject {
        return task.optJSONObject("taskDisplayInfo")?.optJSONObject("customInfo") ?: JSONObject()
    }

    private fun isInsuredTaskRewardConfirmed(task: JSONObject): Boolean {
        val status = task.optString("taskProcessStatus").trim().uppercase(Locale.ROOT)
        return status in setOf(
            "SEND_SUCCESS",
            "RECEIVE_SUCCESS",
            "HAS_RECEIVED",
            "RECEIVED",
            "DONE",
            "COMPLETED",
            "COMPLETE_SUCCESS",
            "SUCCESS"
        ) ||
            hasInsuredTaskSendOrder(task)
    }

    private fun hasInsuredTaskSendOrder(task: JSONObject): Boolean {
        val sendOrderList = task.optJSONArray("sendPrizeSendOrderList") ?: return false
        for (i in 0 until sendOrderList.length()) {
            val sendOrder = sendOrderList.optJSONObject(i) ?: continue
            val sendStatus = sendOrder.optString("sendStatus")
            if (sendStatus == "SUCCESS") {
                return true
            }
        }
        return false
    }

    private fun isSupportedInsuredBrowseTask(task: JSONObject): Boolean {
        val customInfo = resolveInsuredTaskCustomInfo(task)
        val taskMainType = task.optString("taskMainType")
        val taskType = customInfo.optString("taskType").ifBlank { taskMainType }
        val operationType = customInfo.optString("taskOperationType").ifBlank {
            task.optString("operationType")
        }
        val taskCategory = task.optString("taskCategory").ifBlank {
            customInfo.optString("taskCategorize")
        }
        if (taskMainType == "ISSUED_TASK" ||
            taskType == "ISSUED_TASK" ||
            taskMainType == "EXPLAIN_INTELLIGENCE" ||
            taskType == "EXPLAIN_INTELLIGENCE" ||
            taskCategory == "TRANSFER"
        ) {
            return false
        }

        return taskMainType == "BROWSE_PAGE" ||
            taskType == "BROWSE_PAGE" ||
            taskMainType == "BROWSE_TASK" ||
            taskType == "BROWSE_TASK" ||
            operationType == "BROWSE_TASK" ||
            operationType == "CLICK_TASK" ||
            operationType == "NORMAL_PENDANT_CLICK_TASK"
    }

    private fun logPendingInsuredTask(task: JSONObject, taskId: String, title: String) {
        val customInfo = resolveInsuredTaskCustomInfo(task)
        val taskMainType = task.optString("taskMainType")
        val taskType = customInfo.optString("taskType").ifBlank { taskMainType }
        val operationType = customInfo.optString("taskOperationType")
        val taskCategory = task.optString("taskCategory").ifBlank {
            customInfo.optString("taskCategorize")
        }
        val status = task.optString("taskProcessStatus")
        val reason = resolvePendingInsuredTaskReason(taskMainType, taskType, operationType, taskCategory)
        Log.member(
            "保障金🏥[任务中心-$title]#待手动闭环 reason=$reason " +
                "taskId=$taskId status=$status taskType=$taskType " +
                "operationType=$operationType category=$taskCategory"
        )
    }

    private fun resolvePendingInsuredTaskReason(
        taskMainType: String,
        taskType: String,
        operationType: String,
        taskCategory: String
    ): String {
        return when {
            taskMainType == "ISSUED_TASK" || taskType == "ISSUED_TASK" || taskCategory == "TRANSFER" ->
                "投保/转账类任务暂未确认稳定领奖闭环"

            taskMainType == "EXPLAIN_INTELLIGENCE" || taskType == "EXPLAIN_INTELLIGENCE" ->
                "讲解/视频类任务暂未确认稳定播放完成闭环"

            taskMainType == "COMMON_TASK" || taskType == "COMMON_TASK" || operationType == "COMMON_TASK" ->
                "COMMON_TASK已观察到状态机，但暂未确认稳定发奖闭环"

            else -> "任务类型待后续抓包确认闭环"
        }
    }

    private fun resolveInsuredTaskPrizeText(task: JSONObject): String {
        val customInfo = resolveInsuredTaskCustomInfo(task)
        val goldPrize = customInfo.optString("goldPrize")
        if (goldPrize.isNotBlank()) {
            return "+${goldPrize}元保障金"
        }
        return resolveInsuredTaskPrizeText(task.optJSONArray("validPrizeDetailList")).ifBlank {
            resolveInsuredTaskPrizeText(task.optJSONArray("taskPrizeDetailList"))
        }
    }

    private fun resolveInsuredTaskPrizeText(prizeList: JSONArray?): String {
        if (prizeList == null) {
            return ""
        }
        for (i in 0 until prizeList.length()) {
            val prize = prizeList.optJSONObject(i) ?: continue
            val priceYuan = prize.optJSONObject("priceStrategyDTO")
                ?.optJSONObject("maxPriceYuan")
                ?.optString("value")
                .orEmpty()
            if (priceYuan.isNotBlank()) {
                return "+${priceYuan}元"
            }
            val customMemo = prize.optJSONObject("extProperties")?.optString("CUSTOM_MEMO").orEmpty()
            if (customMemo.isNotBlank()) {
                return customMemo
            }
        }
        return ""
    }

    private fun isInsuredTaskRewardReadyStatus(status: String): Boolean {
        return status.trim().uppercase(Locale.ROOT) in setOf(
            "TO_RECEIVE",
            "WAIT_RECEIVE",
            "FINISHED",
            "COMPLETE"
        )
    }

    private fun extractInsuredTaskRpcCode(responseObject: JSONObject): String {
        val data = responseObject.optJSONObject("data")
        return sequenceOf(
            responseObject.optString("resultCode"),
            responseObject.optString("code"),
            responseObject.optString("errorCode"),
            responseObject.optString("errCode"),
            data?.optString("queryErrorCode").orEmpty()
        ).firstOrNull { it.isNotBlank() }.orEmpty()
    }

    private fun extractInsuredTaskRpcMessage(responseObject: JSONObject): String {
        val data = responseObject.optJSONObject("data")
        return sequenceOf(
            responseObject.optString("resultDesc"),
            responseObject.optString("resultMsg"),
            responseObject.optString("memo"),
            responseObject.optString("errorMessage"),
            responseObject.optString("errorMsg"),
            responseObject.optString("desc"),
            data?.optString("queryErrorMsg").orEmpty()
        ).firstOrNull { it.isNotBlank() }.orEmpty().ifBlank {
            responseObject.toString()
        }
    }

    private fun classifyInsuredTaskFailure(
        code: String,
        message: String,
        responseObject: JSONObject
    ): TaskRpcFailureType {
        return when {
            code == "AE15140290002002" -> TaskRpcFailureType.BUSINESS_LIMIT

            containsAny(
                message,
                "已领取",
                "已经领取",
                "重复领取",
                "重复领奖",
                "重复完成",
                "重复",
                "已完成",
                "任务已完结",
                "任务已结束"
            ) -> TaskRpcFailureType.TERMINAL_DONE

            code == "400000040" ||
                containsAny(message, "不支持rpc调用", "不支持RPC完成") ->
                TaskRpcFailureType.UNSUPPORTED_NO_CLOSURE

            code in setOf("20020012", "TASK_ID_INVALID", "ILLEGAL_ARGUMENT", "PROMISE_TEMPLATE_NOT_EXIST") ||
                containsAny(message, "参数错误", "任务ID非法", "模板不存在", "生活记录模板不存在") ->
                TaskRpcFailureType.NON_RETRYABLE_INVALID

            isInsuredTaskMarkedRetryable(responseObject) ||
                code in setOf("3000", "REMOTE_INVOKE_EXCEPTION", "OP_REPEAT_CHECK", "SYSTEM_BUSY", "NETWORK_ERROR") ||
                containsAny(message, "系统出错", "系统繁忙", "稍后", "繁忙", "频繁", "重试", "需要验证", "访问被拒绝") ->
                TaskRpcFailureType.RETRYABLE_RPC

            code.startsWith("100010") ||
                code.contains("LIMIT", ignoreCase = true) ||
                containsAny(message, "次数超过限制", "上限", "限制", "受限", "不可领取", "资格不足", "风控", "风险") ->
                TaskRpcFailureType.BUSINESS_LIMIT

            else -> TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW
        }
    }

    private fun isInsuredTaskMarkedRetryable(responseObject: JSONObject): Boolean {
        return listOf("retryable", "retriable", "canRetry").any { key ->
            responseObject.has(key) && responseObject.optBoolean(key, false)
        }
    }

    private fun buildInsuredGoldGainRequest(
        goldBall: JSONObject,
        isSignIn: Boolean,
        entrance: String
    ): JSONObject {
        val requestObject = JSONObject(goldBall.toString())
        if (!requestObject.has("bizData")) {
            requestObject.put("bizData", JSONObject())
        }
        requestObject.put("entrance", resolveInsuredGoldEntrance(requestObject.optString("entrance"), entrance))
        if (!requestObject.has("helpGain")) {
            requestObject.put("helpGain", false)
        }
        val showYuan = requestObject.optString("sendSumInsuredYuan").ifBlank {
            requestObject.optString("realSendSumInsuredYuan")
        }
        if (showYuan.isNotBlank() && requestObject.optString("showYuan").isBlank()) {
            requestObject.put("showYuan", showYuan)
        }
        val title = resolveInsuredGoldTitle(requestObject, isSignIn)
        if (title.isNotBlank() && requestObject.optString("title").isBlank()) {
            requestObject.put("title", title)
        }
        if (isSignIn) {
            if (!requestObject.has("disabled")) {
                requestObject.put("disabled", false)
            }
            if (!requestObject.optBoolean("isSignIn", false)) {
                requestObject.put("isSignIn", true)
            }
            if (!requestObject.has("isTodayContinuousSignIn")) {
                requestObject.put("isTodayContinuousSignIn", false)
            }
        }
        return requestObject
    }

    private fun resolveInsuredGoldTitle(goldBall: JSONObject, isSignIn: Boolean): String {
        if (isSignIn || goldBall.optString("channel") == "DAILY_SIGN_IN") {
            return "签到"
        }
        return when (goldBall.optString("channel")) {
            "ALIPAY_LOGIN" -> "登录奖励"
            "ANT_COVERAGE_LOGIN" -> "访问蚂蚁保"
            else -> goldBall.optString("title").ifBlank { "领取保证金" }
        }
    }

    private fun extractInsuredGoldGainYuan(responseObject: JSONObject): String {
        val data = responseObject.optJSONObject("data") ?: return ""
        val gainDto = data.optJSONObject("gainSumInsuredDTO")
        return gainDto?.optString("gainSumInsuredYuan").orEmpty().ifBlank {
            data.optString("gainSumInsuredYuan").ifBlank {
                data.optString("sendSumInsuredYuan")
            }
        }
    }

    private fun logInsuredGoldFailure(
        title: String,
        responseObject: JSONObject,
        rawResponse: String
    ): DailyTaskProcessResult {
        val code = sequenceOf(
            responseObject.optString("resultCode"),
            responseObject.optString("code"),
            responseObject.optString("errorCode")
        ).firstOrNull { it.isNotBlank() }.orEmpty()
        val message = sequenceOf(
            responseObject.optString("resultDesc"),
            responseObject.optString("resultMsg"),
            responseObject.optString("memo"),
            responseObject.optString("errorMessage"),
            responseObject.optString("errorMsg"),
            responseObject.optString("desc")
        ).firstOrNull { it.isNotBlank() }.orEmpty()
        val detail = when {
            code.isNotBlank() && message.isNotBlank() -> "$code/$message"
            code.isNotBlank() -> code
            message.isNotBlank() -> message
            else -> rawResponse
        }
        return when (classifyInsuredGoldFailure(code, message)) {
            InsuredGoldRpcFailureType.DUPLICATE_REWARD -> {
                Log.member("保障金🏥[$title]#已领取或重复领取，跳过:$detail")
                DailyTaskProcessResult.HANDLED
            }

            InsuredGoldRpcFailureType.BUSINESS_LIMIT -> {
                Log.member("保障金🏥[$title]#业务受限，本轮跳过:$detail")
                DailyTaskProcessResult.HANDLED
            }

            InsuredGoldRpcFailureType.RETRYABLE -> {
                Log.member("保障金🏥[$title]#暂时不可领取，保留后续重试:$detail")
                DailyTaskProcessResult.RETRYABLE_FAILURE
            }

            InsuredGoldRpcFailureType.NON_RETRYABLE -> {
                Log.error("$TAG.collectInsuredGold.collectInsuredGold", "保障金🏥[$title]#响应失败:$detail")
                DailyTaskProcessResult.UNKNOWN_FAILURE
            }
        }
    }

    private fun classifyInsuredGoldFailure(code: String, message: String): InsuredGoldRpcFailureType {
        return when {
            code == "AE13116030004362" && message.contains("领金成功") ->
                InsuredGoldRpcFailureType.DUPLICATE_REWARD

            message.contains("已领取") ||
                message.contains("重复") ||
                message.contains("已经领取") -> InsuredGoldRpcFailureType.DUPLICATE_REWARD

            message.contains("稍后") ||
                message.contains("频繁") ||
                message.contains("繁忙") -> InsuredGoldRpcFailureType.RETRYABLE

            code.contains("LIMIT", ignoreCase = true) ||
                message.contains("上限") ||
                message.contains("限制") ||
                message.contains("受限") ||
                message.contains("不可领取") -> InsuredGoldRpcFailureType.BUSINESS_LIMIT

            else -> InsuredGoldRpcFailureType.NON_RETRYABLE
        }
    }

    private fun resolveSupportedMemberTaskTargetBusiness(targetBusinessArray: JSONArray?): ResolvedMemberTaskTargetBusiness {
        if (targetBusinessArray == null || targetBusinessArray.length() <= 0) {
            return ResolvedMemberTaskTargetBusiness()
        }
        for (i in 0 until targetBusinessArray.length()) {
            val targetBusiness = targetBusinessArray.optString(i)
            val targetBusinessType = resolveSupportedMemberTaskTargetBusinessType(targetBusiness)
            if (targetBusinessType != MemberTaskTargetBusinessType.UNSUPPORTED) {
                return ResolvedMemberTaskTargetBusiness(targetBusiness, targetBusinessType)
            }
        }
        return ResolvedMemberTaskTargetBusiness()
    }

    private fun resolveSupportedMemberTaskTargetBusinessType(targetBusiness: String): MemberTaskTargetBusinessType {
        if (targetBusiness.isBlank()) {
            return MemberTaskTargetBusinessType.UNSUPPORTED
        }
        val targetParts = targetBusiness.split("#")
        val bizType = targetParts.getOrNull(0).orEmpty()
        if (bizType.equals("CALL_APP", true)) {
            val appScene = targetParts.getOrNull(1).orEmpty()
            return if (appScene.isNotBlank()) {
                MemberTaskTargetBusinessType.CALL_APP
            } else {
                MemberTaskTargetBusinessType.UNSUPPORTED
            }
        }
        if (targetParts.size < 3) {
            return MemberTaskTargetBusinessType.UNSUPPORTED
        }
        val bizSubType = targetParts[1]
        val bizParam = targetParts[2]
        return if (bizType.equals("BROWSE", true) && bizSubType.isNotBlank() && bizParam.isNotBlank()) {
            MemberTaskTargetBusinessType.BROWSE
        } else {
            MemberTaskTargetBusinessType.UNSUPPORTED
        }
    }

    private fun resolveMemberTaskTargetBusinessType(value: String): MemberTaskTargetBusinessType {
        return try {
            MemberTaskTargetBusinessType.valueOf(value.ifBlank { MemberTaskTargetBusinessType.UNSUPPORTED.name })
        } catch (_: IllegalArgumentException) {
            MemberTaskTargetBusinessType.UNSUPPORTED
        }
    }

    private fun isMemberTaskInBlacklist(taskConfigId: String, taskTitle: String): Boolean {
        return TaskBlacklist.isTaskInBlacklist(memberTaskBlacklistModule, taskTitle) ||
            TaskBlacklist.isTaskInBlacklist(memberTaskBlacklistModule, taskConfigId)
    }

    private fun resolveMemberAdTaskBizId(
        taskObject: JSONObject?,
        taskConfigInfo: JSONObject? = null
    ): String {
        if (isUnsupportedMemberAdTaskType(taskObject, taskConfigInfo)) {
            return ""
        }

        val urlCandidates = listOfNotNull(
            taskObject?.optString("actionUrl"),
            taskObject?.optString("targetUrl"),
            taskObject?.optString("jumpUrl"),
            taskObject?.optString("pageUrl"),
            taskObject?.optString("clickThroughUrl"),
            taskObject?.optString("halfClickThroughUrl"),
            taskConfigInfo?.optString("actionUrl"),
            taskConfigInfo?.optString("targetUrl"),
            taskConfigInfo?.optString("jumpUrl"),
            taskConfigInfo?.optString("pageUrl"),
            taskConfigInfo?.optString("clickThroughUrl"),
            taskConfigInfo?.optString("halfClickThroughUrl"),
            taskConfigInfo?.optString("schemaJson")
        ).filter { it.isNotBlank() }
        val hasMemberAdUrlMarker = urlCandidates.any { looksLikeMemberAdTaskUrl(it) }

        if (hasExplicitMemberAdTaskMarker(taskObject, taskConfigInfo, hasMemberAdUrlMarker)) {
            val directBizId = sequenceOf(
                taskObject?.optJSONObject("lightsAdExtMap")?.optString("bizId"),
                taskConfigInfo?.optJSONObject("lightsAdExtMap")?.optString("bizId"),
                taskObject?.optString("adBizId"),
                taskObject?.optJSONObject("logExtMap")?.optString("bizId"),
                taskObject?.optJSONObject("extInfo")?.optString("adBizId"),
                taskObject?.optJSONObject("extInfo")?.optString("bizId"),
                taskConfigInfo?.optString("adBizId"),
                taskConfigInfo?.optJSONObject("logExtMap")?.optString("bizId"),
                taskConfigInfo?.optJSONObject("extInfo")?.optString("adBizId"),
                taskConfigInfo?.optJSONObject("extInfo")?.optString("bizId")
            ).filterNotNull().firstOrNull { it.isNotBlank() }
            if (!directBizId.isNullOrBlank()) {
                return directBizId
            }
        }

        for (urlCandidate in urlCandidates) {
            if (!hasMemberAdUrlMarker || !looksLikeMemberAdTaskUrl(urlCandidate)) {
                continue
            }
            extractMemberAdBizIdFromText(urlCandidate)?.let { return it }
            val nestedUrl = UrlUtil.getFullNestedUrl(urlCandidate, "url")
            if (!nestedUrl.isNullOrBlank()) {
                extractMemberAdBizIdFromText(nestedUrl)?.let { return it }
            }
        }
        return ""
    }

    private fun resolveUnsupportedMemberAdTaskReason(
        taskObject: JSONObject?,
        taskConfigInfo: JSONObject?
    ): String? {
        val taskTypeCandidates = sequenceOf(
            taskObject?.optString("taskType"),
            taskConfigInfo?.optString("taskType")
        ).filterNotNull()
        if (taskTypeCandidates.any { it.equals("MULTIPLE_TIMER_TASK", true) }) {
            return "MULTIPLE_TIMER_TASK"
        }
        if (taskObject?.has("videoTaskInfo") == true || taskConfigInfo?.has("videoTaskInfo") == true) {
            return "VIDEO_TASK"
        }
        if (taskObject?.optBoolean("adVideoTask") == true || taskConfigInfo?.optBoolean("adVideoTask") == true) {
            return "AD_VIDEO_TASK"
        }
        if (hasMemberAdVideoSchema(taskObject, taskConfigInfo)) {
            return "VIDEO_TASK"
        }
        return null
    }

    private fun isUnsupportedMemberAdTaskType(
        taskObject: JSONObject?,
        taskConfigInfo: JSONObject?
    ): Boolean {
        return resolveUnsupportedMemberAdTaskReason(taskObject, taskConfigInfo) != null
    }

    private fun logSkippedMemberAdTask(
        taskTitle: String,
        skipReason: String,
        logPrefix: String = "会员任务"
    ) {
        val detail = when (skipReason) {
            "MULTIPLE_TIMER_TASK" -> "多阶段倒计时任务"
            "VIDEO_TASK", "AD_VIDEO_TASK" -> "视频广告任务"
            else -> skipReason
        }
        Log.member("$logPrefix[$taskTitle]#识别到$detail，未纳入白名单闭环，跳过")
    }

    private fun hasExplicitMemberAdTaskMarker(
        taskObject: JSONObject?,
        taskConfigInfo: JSONObject?,
        hasMemberAdUrlMarker: Boolean
    ): Boolean {
        if (hasMemberAdUrlMarker) {
            return true
        }
        val configIds = linkedSetOf<String>().apply {
            taskObject?.let(::resolveCurrentMemberTaskConfigId)?.takeIf { it.isNotBlank() }?.let(::add)
            taskObject?.optString("configId")?.takeIf { it.isNotBlank() }?.let(::add)
            taskConfigInfo?.optString("configId")?.takeIf { it.isNotBlank() }?.let(::add)
            taskConfigInfo?.optLong("id", 0L)?.takeIf { it > 0 }?.toString()?.let(::add)
        }
        if (configIds.any { it.length == 8 && it.startsWith("3200") }) {
            return true
        }
        return taskObject?.optJSONObject("lightsAdExtMap") != null ||
            taskConfigInfo?.optJSONObject("lightsAdExtMap") != null ||
            taskObject?.optBoolean("adTaskFlag") == true ||
            taskConfigInfo?.optBoolean("adTaskFlag") == true ||
            taskObject?.optBoolean("adTask") == true ||
            taskConfigInfo?.optBoolean("adTask") == true
    }

    private fun hasMemberAdVideoSchema(
        taskObject: JSONObject?,
        taskConfigInfo: JSONObject?
    ): Boolean {
        return sequenceOf(
            taskObject?.optString("schemaJson"),
            taskConfigInfo?.optString("schemaJson")
        ).filterNotNull()
            .any { schemaJson ->
                if (schemaJson.isBlank()) {
                    false
                } else {
                    runCatching {
                        JSONObject(schemaJson).optString("videoUrl").isNotBlank()
                    }.getOrDefault(false)
                }
            }
    }

    private fun extractMemberAdBizIdFromText(text: String): String? {
        if (text.isBlank()) {
            return null
        }
        UrlUtil.getParamValue(text, "bizId")?.takeIf { it.isNotBlank() }?.let { return it }
        UrlUtil.getParamValue(text, "opParam")
            ?.takeIf { it.isNotBlank() }
            ?.let { opParam ->
                runCatching { JSONObject(opParam).optString("bizId") }
                    .getOrNull()
                    ?.takeIf { it.isNotBlank() }
                    ?.let { return it }
            }
        val jsonMatcher = Pattern.compile("\"bizId\"\\s*:\\s*\"([^\"]+)\"").matcher(text)
        if (jsonMatcher.find()) {
            return jsonMatcher.group(1)
        }
        val queryMatcher = Pattern.compile("bizId=([^&#\"]+)").matcher(text)
        if (queryMatcher.find()) {
            return queryMatcher.group(1)
        }
        return null
    }

    private fun looksLikeMemberAdTaskUrl(text: String): Boolean {
        if (text.isBlank()) {
            return false
        }
        val normalized = text.lowercase()
        return normalized.contains("com.alipay.adtask.biz.mobilegw.service.task.finish") ||
            normalized.contains("spacecode#ant_member_xlight_task") ||
            normalized.contains("spacecode=ant_member_xlight_task") ||
            (normalized.contains("renderconfigkey=") && normalized.contains("ant_member_xlight_task"))
    }

    private fun finishMemberAdTask(
        taskConfigId: String,
        taskTitle: String,
        fallbackAwardPoint: String,
        bizId: String,
        item: TaskFlowItem? = null,
        taskConfig: JSONObject? = null,
    ): TaskFlowActionResult {
        val newAd = taskConfig?.optJSONObject("lightsAdExtMap") != null
        val waitKey = "memberTaskWait:ad:${TimeUtil.getDateStr2()}:$taskConfigId:$bizId:${item?.progress.orEmpty()}"
        val store = if (newAd) {
            UserDataStoreManager.getInstance(AccountSessionCoordinator.currentUserId() ?: UserMap.currentUid)
                ?: return TaskFlowActionResult.failure(
                    TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW, message = "无法读取广告任务报名状态",
                    rpc = "AntMemberRpcCall.taskFinish",
                )
        } else null
        val wait = store?.get(waitKey, String::class.java)?.let { JSONObject(it) }
        if (newAd && wait == null) {
            return TaskFlowActionResult.failure(
                TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW, message = "广告报名状态未确认，保留任务回查",
                rpc = "AntMemberRpcCall.applyAdTask",
            )
        }
        if (wait != null) {
            val now = System.currentTimeMillis()
            if (wait.optBoolean("submitted")) {
                if (checkMemberAdTaskFinished(taskConfigId, bizId) == CurrentMemberTaskVerifyState.CONFIRMED) {
                    store?.remove(waitKey)
                    return TaskFlowActionResult.success(refreshAfterAction = true)
                }
                val attempts = wait.optInt("confirmAttempts")
                if (attempts < MEMBER_CALL_APP_VERIFY_RETRY_LIMIT) {
                    wait.put("confirmAttempts", attempts + 1).put("readyAt", now)
                    store?.put(waitKey, wait.toString())
                    scheduleMemberTaskContinuation(waitKey, now)
                }
                return TaskFlowActionResult.defer(
                    DeferredReason.STATE_CONFIRMATION, message = "广告完成已提交，等待详情确认",
                    rpc = "AntMemberRpcCall.querySingleAdTaskProcessDetail",
                )
            }
            wait.put("submitted", true).put("readyAt", now)
            store?.put(waitKey, wait.toString())
            scheduleMemberTaskContinuation(waitKey, now)
        }
        val response = AntMemberRpcCall.taskFinish(bizId, includeExtendInfo = newAd)
        val responseObject = JSONObject(response)
        val success = responseObject.optBoolean("success") ||
            responseObject.optString("errCode") == "0" ||
            responseObject.optString("resultCode").equals("SUCCESS", true)
        if (!success) {
            wait?.remove("submitted")
            if (wait != null) store?.put(waitKey, wait.toString())
            return memberDomainTaskFailureResult(
                item = item,
                responseObject = responseObject,
                rawResponse = response,
                rpc = "AntMemberRpcCall.taskFinish",
                detail = "taskConfigId=$taskConfigId taskName=$taskTitle bizId=$bizId"
            )
        }
        val verifyState = checkMemberAdTaskFinished(taskConfigId, bizId)
        if (ApplicationHookConstants.isOffline()) {
            return TaskFlowActionResult.failure(
                failureType = TaskRpcFailureType.RETRYABLE_RPC,
                code = "RPC_OFFLINE_RISK",
                message = "广告任务详情回查命中风控或验证，已暂停会员任务",
                rpc = "AntMemberRpcCall.querySingleAdTaskProcessDetail",
                detail = "taskConfigId=$taskConfigId taskName=$taskTitle bizId=$bizId",
                stopCurrentRound = true,
            )
        }
        val rewardPoint = responseObject.optJSONObject("extendInfo")
            ?.optJSONObject("rewardInfo")
            ?.optString("rewardAmount")
            .orEmpty()
            .ifEmpty { fallbackAwardPoint }
        if (verifyState == CurrentMemberTaskVerifyState.CONFIRMED) {
            store?.remove(waitKey)
            if (rewardPoint.isNotBlank()) {
                Log.member("会员任务[$taskTitle]#获得积分$rewardPoint")
            } else {
                Log.member("会员任务[$taskTitle]#广告任务完成")
            }
            return TaskFlowActionResult(success = true, code = "CONFIRMED", refreshAfterAction = true)
        } else {
            if (wait != null) {
                scheduleMemberTaskContinuation(waitKey, wait.getLong("readyAt"))
                return TaskFlowActionResult.defer(
                    DeferredReason.STATE_CONFIRMATION, message = "广告上报成功，等待详情确认",
                    rpc = "AntMemberRpcCall.querySingleAdTaskProcessDetail",
                )
            }
            Log.member("会员任务[$taskTitle]#广告任务上报成功，状态待后续页面确认")
            return TaskFlowActionResult(
                success = true,
                code = "VERIFY_PENDING",
                refreshAfterAction = true,
                progressChanged = false
            )
        }
    }

    private fun checkMemberAdTaskFinished(
        taskConfigId: String,
        bizId: String
    ): CurrentMemberTaskVerifyState {
        if (taskConfigId.isBlank() || bizId.isBlank()) {
            return CurrentMemberTaskVerifyState.UNCONFIRMED
        }
        return try {
            val detailResponse = AntMemberRpcCall.querySingleAdTaskProcessDetail(taskConfigId, bizId)
            val detailObject = JSONObject(detailResponse)
            if (stopMemberCoreTasksForRpcRisk("AntMember.memberTask.adDetail", detailObject)) {
                return CurrentMemberTaskVerifyState.UNCONFIRMED
            }
            if (!ResChecker.checkRes(TAG, detailObject)) {
                return CurrentMemberTaskVerifyState.UNCONFIRMED
            }
            val taskProcessObject = detailObject.optJSONObject("resultData")?.optJSONObject("taskProcessVO")
            if (isMemberTaskProcessFinished(taskProcessObject)) {
                CurrentMemberTaskVerifyState.CONFIRMED
            } else {
                CurrentMemberTaskVerifyState.UNCONFIRMED
            }
        } catch (_: JSONException) {
            CurrentMemberTaskVerifyState.UNCONFIRMED
        }
    }

    /**
     * 黄金票任务入口（首页签到/收取/任务扫描 + 提取）
     * @param doSignIn 是否执行签到
     * @param doConsume 是否执行提取
     */
    internal fun doGoldTicketTask(doSignIn: Boolean, doConsume: Boolean) {
        val needSignIn = doSignIn && !hasFlagToday(StatusFlags.FLAG_ANTMEMBER_GOLD_TICKET_SIGN_DONE)
        val needHomeCheck = doSignIn && !hasFlagToday(StatusFlags.FLAG_ANTMEMBER_GOLD_TICKET_HOME_DONE)
        val needWelfareCheck = doSignIn && !hasFlagToday(StatusFlags.FLAG_ANTMEMBER_GOLD_TICKET_WELFARE_DONE)
        val needConsume = doConsume && (
            !UserDataStoreManager.getInstance(AccountSessionCoordinator.currentUserId() ?: UserMap.currentUid)
                ?.get("goldTicketConsumePending", String::class.java).isNullOrBlank() ||
                !hasFlagToday(StatusFlags.FLAG_ANTMEMBER_GOLD_TICKET_CONSUME_DONE)
            )

        if (!needSignIn && !needHomeCheck && !needWelfareCheck && !needConsume) {
            Log.member("黄金票🎫[今日已处理] 跳过执行")
            return
        }

        try {
            Log.member("开始执行黄金票...")

            var homeUpsertData: JSONObject? = null
            if (needSignIn || needHomeCheck) {
                homeUpsertData = queryGoldTicketHomeUpsert()
            }

            if (needSignIn) {
                if (homeUpsertData == null) {
                    Log.error("黄金票🎫[首页查询失败] 无法判断签到状态")
                } else if (doGoldTicketSignIn(homeUpsertData)) {
                    setFlagToday(StatusFlags.FLAG_ANTMEMBER_GOLD_TICKET_SIGN_DONE)
                    homeUpsertData = queryGoldTicketHomeUpsert() ?: homeUpsertData
                }
            }

            if (needWelfareCheck) {
                val welfareHandleResult = handleGoldTicketWelfareTasks()
                if (!welfareHandleResult.querySuccess) {
                    Log.error("黄金票🎫[福利中心任务查询失败]")
                } else if (welfareHandleResult.canMarkDone) {
                    setFlagToday(StatusFlags.FLAG_ANTMEMBER_GOLD_TICKET_WELFARE_DONE)
                }
                homeUpsertData = queryGoldTicketHomeUpsert()
            }

            if (needHomeCheck || needWelfareCheck) {
                if (homeUpsertData == null) {
                    Log.error("黄金票🎫[首页查询失败] 跳过收取与任务扫描")
                } else {
                    doGoldTicketCollect(homeUpsertData)
                    val homeTaskHandleResult = handleGoldTicketTasks(homeUpsertData)
                    if (!homeTaskHandleResult.querySuccess) {
                        Log.error("黄金票🎫[首页任务查询失败]")
                    } else if (homeTaskHandleResult.canMarkDone) {
                        setFlagToday(StatusFlags.FLAG_ANTMEMBER_GOLD_TICKET_HOME_DONE)
                    }
                }
            }

            if (needConsume) {
                doGoldTicketConsume()
            }
        } catch (e: Exception) {
            Log.printStackTrace(TAG, e)
        }
    }

    /**
     * 黄金票首页数据
     */
    private fun queryGoldTicketHomeUpsert(taskId: String = ""): JSONObject? {
        return try {
            val homeRes = AntMemberRpcCall.queryGoldTicketHome(taskId) ?: return null
            val homeJson = JSONObject(homeRes)
            if (isMemberMarketingRpcRisk("AntMember.goldTicket.home", homeJson)) {
                return null
            }
            if (!ResChecker.checkRes(TAG, homeJson)) {
                return null
            }
            homeJson.optJSONObject("result")?.optJSONObject("upsertData")
        } catch (e: Exception) {
            Log.printStackTrace(TAG, e)
            null
        }
    }

    private fun isGoldTicketCanSign(homeUpsertData: JSONObject?): Boolean {
        return homeUpsertData?.optJSONObject("assetInfo")?.optBoolean("canSign", false) == true
    }

    private fun doGoldTicketIndexCollect(source: String): Int {
        val needleResponse = AntMemberRpcCall.goldTicketIndexCollect()
        if (!needleResponse.isNullOrBlank()) {
            return logGoldTicketCollectResponse(needleResponse, source)
        }
        return logGoldTicketCollectResponse(
            AntMemberRpcCall.goldBillCollect(),
            "$source-旧版兼容"
        )
    }

    private fun refreshGoldTicketWelfareCenter(source: String): Boolean {
        return try {
            val updateResponse = AntMemberRpcCall.welfareCenterUpdate(9)
            if (updateResponse.isNullOrBlank()) {
                Log.error("黄金票🎫[$source] welfareCenter.update 无返回")
                return false
            }
            val updateJson = JSONObject(updateResponse)
            if (isMemberMarketingRpcRisk("AntMember.goldTicket.welfareUpdate", updateJson)) {
                return false
            }
            if (!ResChecker.checkRes(TAG, updateJson)) {
                val message = updateJson.optString("resultDesc", updateJson.optString("memo", updateJson.toString()))
                Log.error("黄金票🎫[$source] welfareCenter.update 失败: $message")
                return false
            }
            val welfareHome = AntMemberRpcCall.queryWelfareHome()
            if (welfareHome.isNullOrBlank()) {
                Log.error("黄金票🎫[$source] welfareCenter.index 回查无返回")
                return false
            }
            val welfareJson = JSONObject(welfareHome)
            if (isMemberMarketingRpcRisk("AntMember.goldTicket.welfareRequery", welfareJson)) {
                return false
            }
            if (!ResChecker.checkRes(TAG, welfareJson)) {
                val message = welfareJson.optString("resultDesc", welfareJson.optString("memo", welfareJson.toString()))
                Log.error("黄金票🎫[$source] welfareCenter.index 回查失败: $message")
                return false
            }
            true
        } catch (e: Exception) {
            Log.printStackTrace(TAG, e)
            false
        }
    }

    /**
     * 黄金票签到逻辑
     *
     * 真实首页日志来自 `com.alipay.wealthgoldtwa.needle.v2.index`，
     * 抓包显示收取接口已切到 `com.alipay.wealthgoldtwa.needle.index.collect`，
     * 因此先用首页 `canSign` 判定，再尝试新版首页收取；
     * 若仍未落库，再回退到已有的 welfareCenter 触发链路。
     */
    private fun doGoldTicketSignIn(homeUpsertData: JSONObject): Boolean {
        return try {
            if (!isGoldTicketCanSign(homeUpsertData)) {
                Log.member("黄金票🎫[今日已签到]")
                return true
            }

            Log.member("黄金票🎫[准备签到]")

            var signSuccess = false
            val collectCount = doGoldTicketIndexCollect("签到尝试")
            var refreshedHome = queryGoldTicketHomeUpsert()
            if (refreshedHome != null && !isGoldTicketCanSign(refreshedHome)) {
                refreshGoldTicketWelfareCenter("首页收取签到")
                refreshedHome = queryGoldTicketHomeUpsert() ?: refreshedHome
                Log.member(
                    if (collectCount > 0) "黄金票🎫[签到成功]#通过首页收取完成签到"
                    else "黄金票🎫[签到成功]"
                )
                signSuccess = true
            }

            if (!signSuccess) {
                val signRes = AntMemberRpcCall.welfareCenterTrigger("SIGN")
                if (signRes.isNotBlank()) {
                    val signJson = JSONObject(signRes)
                    if (isMemberMarketingRpcRisk("AntMember.goldTicket.sign", signJson)) {
                        return false
                    }
                    if (ResChecker.checkRes(TAG, signJson)) {
                        val signResult = signJson.optJSONObject("result")
                        val amount = signResult?.optJSONObject("prize")?.optString("amount").orEmpty()
                        refreshGoldTicketWelfareCenter("签到")
                        refreshedHome = queryGoldTicketHomeUpsert()
                        signSuccess = refreshedHome != null && !isGoldTicketCanSign(refreshedHome)
                        if (signSuccess || amount.isNotBlank()) {
                            Log.member(
                                if (amount.isNotBlank()) "黄金票🎫[签到成功]#获得: $amount"
                                else "黄金票🎫[签到成功]"
                            )
                            signSuccess = true
                        }
                    }
                }
            }

            if (!signSuccess) {
                Log.error("黄金票🎫[签到失败] 未找到可用签到返回")
            }
            signSuccess
        } catch (e: Exception) {
            Log.printStackTrace(TAG, e)
            false
        }
    }

    /**
     * 黄金票首页场景收取
     */
    private fun doGoldTicketCollect(homeUpsertData: JSONObject) {
        try {
            val toBeCollectInfo = homeUpsertData.optJSONObject("assetInfo")?.optJSONObject("toBeCollectInfo")
            val totalProfitValue = toBeCollectInfo?.optInt("totalProfitValue", 0) ?: 0
            if (totalProfitValue <= 0) {
                return
            }

            val collectCount = doGoldTicketIndexCollect("场景收取")
            if (collectCount == 0) {
                Log.member("黄金票🎫[场景收取] 暂无可领取奖励")
            }
        } catch (e: Exception) {
            Log.printStackTrace(TAG, e)
        }
    }

    private fun logGoldTicketCollectResponse(response: String?, source: String): Int {
        if (response.isNullOrBlank()) {
            return 0
        }
        return try {
            val collectJson = JSONObject(response)
            if (isMemberMarketingRpcRisk("AntMember.goldTicket.collect", collectJson)) {
                return 0
            }
            if (!ResChecker.checkRes(TAG, collectJson)) {
                val message = collectJson.optString("resultDesc", collectJson.optString("memo"))
                if (message.isNotBlank()) {
                    Log.member("黄金票🎫[$source] $message")
                }
                return 0
            }

            val result = collectJson.optJSONObject("result") ?: return 0
            val collectedList = result.optJSONArray("collectedList") ?: return 0
            var count = 0
            for (i in 0 until collectedList.length()) {
                val item = collectedList.optString(i)
                if (item.isBlank()) {
                    continue
                }
                count++
                Log.member("黄金票🎫[$source]#$item")
            }

            if (count > 0) {
                val totalAmount = result.optJSONObject("collectedCamp")?.optString("amount").orEmpty()
                if (totalAmount.isNotBlank()) {
                    Log.member("黄金票🎫[$source]#本次共得${totalAmount}份")
                }
            }
            count
        } catch (e: Exception) {
            Log.printStackTrace(TAG, e)
            0
        }
    }

    private fun isGoldTicketEggSignTask(task: JSONObject): Boolean {
        return task.optString("taskId") == "AP11249033"
    }

    private fun isGoldTicketKnownWelfareAutoTask(task: JSONObject): Boolean {
        return when (task.optString("taskId")) {
            "AP10247402", // 逛逛稳健理财领红包
            "AP11249033", // 逛蛋定生财去签到
            "AP13250426", // 逛定期市场领红包
            "AP19360380", // 逛定期市场领红包（2026-08 新任务）
            "AP15280470", // 逛蚂蚁投教基地
            "AP16338809"  // 去芝麻攒粒兑权益
            -> true

            else -> false
        }
    }

    private fun queryGoldTicketWelfareResult(): JSONObject? {
        return try {
            val welfareResponse = AntMemberRpcCall.queryWelfareHome() ?: return null
            val welfareJson = JSONObject(welfareResponse)
            if (isMemberMarketingRpcRisk("AntMember.goldTicket.welfare", welfareJson)) {
                return null
            }
            if (!ResChecker.checkRes(TAG, welfareJson)) {
                return null
            }
            welfareJson.optJSONObject("result")
        } catch (e: Exception) {
            Log.printStackTrace(TAG, e)
            null
        }
    }

    private fun queryGoldTicketWelfareTodoTasks(): JSONArray? {
        val welfareResult = queryGoldTicketWelfareResult() ?: return null
        return welfareResult.optJSONObject("goldbillTasks")
            ?.optJSONArray("todo")
            ?: JSONArray()
    }

    private fun extractGoldTicketHomeTasks(homeUpsertData: JSONObject): JSONArray {
        val taskModule = homeUpsertData.optJSONObject("task")
        val groups = taskModule?.optJSONObject("tasks")
        val tasks = JSONArray()
        for (group in listOf("todo", "done")) {
            val entries = groups?.optJSONArray(group) ?: continue
            for (index in 0 until entries.length()) {
                entries.optJSONObject(index)?.let { tasks.put(it) }
            }
        }
        if (taskModule?.has("canTriggerBigPrize") == true) {
            tasks.put(JSONObject().put("taskId", "goldTicketBigPrize").put("title", "黄金票任务大奖")
                .put("taskProcessStatus", if (taskModule.optBoolean("canTriggerBigPrize")) "TO_RECEIVE" else "RECEIVE_SUCCESS"))
        }
        return tasks
    }

    private fun isGoldTicketTaskRewardReady(task: JSONObject): Boolean {
        return task.optString("taskProcessStatus") in setOf(
            "TO_RECEIVE",
            "WAIT_RECEIVE",
            "FINISHED",
            "COMPLETE"
        )
    }

    private fun isGoldTicketTaskPendingAutoStatus(task: JSONObject): Boolean {
        return task.optString("taskProcessStatus") in setOf(
            "TO_RECEIVE",
            "WAIT_RECEIVE",
            "FINISHED",
            "COMPLETE",
            "NONE_SIGNUP",
            "SIGNUP_EXPIRED",
            "SIGNUP_COMPLETE"
        )
    }

    private fun isGoldTicketTaskBlacklisted(task: JSONObject): Boolean {
        val taskId = task.optString("taskId")
        return TaskBlacklist.isTaskInBlacklist(goldTicketTaskBlacklistModule, taskId)
    }

    private fun isGoldTicketManualHomeTask(task: JSONObject): Boolean {
        val status = task.optString("taskProcessStatus")
        val hasEntrance = task.optString("link").isNotBlank() ||
            task.optBoolean("canAccess", false)
        return when (status) {
            "NONE_SIGNUP",
            "SIGNUP_EXPIRED" -> hasEntrance
            "SIGNUP_COMPLETE" -> hasEntrance && !isGoldTicketEggSignTask(task)
            else -> false
        }
    }

    private fun countGoldTicketPendingWelfareAutoTasks(todoTasks: JSONArray?): Int {
        if (todoTasks == null || todoTasks.length() == 0) {
            return 0
        }
        var pendingCount = 0
        for (i in 0 until todoTasks.length()) {
            val task = todoTasks.optJSONObject(i) ?: continue
            if (isGoldTicketKnownWelfareAutoTask(task) &&
                isGoldTicketTaskPendingAutoStatus(task) &&
                !isGoldTicketTaskBlacklisted(task)
            ) {
                pendingCount++
            }
        }
        return pendingCount
    }

    /**
     * 黄金票首页任务扫描。
     *
     * 首页任务和福利中心任务共用 `taskProcessStatus` 阶段流。首页只自动推进已确认
     * 可闭环的任务和待领奖任务，其余带跳转入口的任务仍保守记录为手动处理。
     */
    private fun handleGoldTicketTasks(homeUpsertData: JSONObject): GoldTicketTaskFlowHandleResult {
        return try {
            val initialTasks = extractGoldTicketHomeTasks(homeUpsertData)
            val adapter = GoldTicketTaskFlowAdapter(
                source = "首页",
                firstTasks = initialTasks,
                queryTasks = { queryGoldTicketHomeUpsert()?.let { extractGoldTicketHomeTasks(it) } },
                autoTaskPredicate = ::isGoldTicketKnownWelfareAutoTask,
                recordUnsupportedTasks = true
            )
            val executionState = TaskFlowExecutionState()
            val runResult = TaskFlowEngine(adapter, roundSleepMs = 425L, executionState = executionState).run()
            if (runResult.actionAttempted &&
                executionState.pendingActionConfirmations.values.any { it.first.id == "goldTicketBigPrize" }) {
                scheduleMemberTaskContinuation("goldTicketBigPrize", System.currentTimeMillis())
            }
            adapter.logSummary()
            GoldTicketTaskFlowHandleResult(
                querySuccess = !adapter.queryFailed,
                canMarkDone = !adapter.queryFailed &&
                    !adapter.hasBlockingFailure &&
                    runResult.completed
            )
        } catch (e: Exception) {
            Log.printStackTrace(TAG, e)
            GoldTicketTaskFlowHandleResult(querySuccess = false, canMarkDone = false)
        }
    }

    /**
     * 福利中心已确认的浏览类任务会走：
     * `goldbill.v4.task.trigger -> needle.taskQueryPush -> welfareCenter.index`
     * 这里仅放开抓包已确认的 taskId，避免把未知福利任务误判成可自动完成。
     */
    private fun handleGoldTicketWelfareTasks(): GoldTicketTaskFlowHandleResult {
        try {
            val todoTasks = queryGoldTicketWelfareTodoTasks()
                ?: return GoldTicketTaskFlowHandleResult(querySuccess = false, canMarkDone = false)

            val trackedAutoTaskCount = countGoldTicketPendingWelfareAutoTasks(todoTasks)
            if (trackedAutoTaskCount == 0) {
                return GoldTicketTaskFlowHandleResult(querySuccess = true, canMarkDone = true)
            }

            val adapter = GoldTicketTaskFlowAdapter(
                source = "福利中心",
                firstTasks = todoTasks,
                queryTasks = ::queryGoldTicketWelfareTodoTasks,
                autoTaskPredicate = ::isGoldTicketKnownWelfareAutoTask,
                recordUnsupportedTasks = false
            )
            TaskFlowEngine(adapter, roundSleepMs = 425L).run()

            val refreshedTodoTasks = queryGoldTicketWelfareTodoTasks()
            if (refreshedTodoTasks == null) {
                Log.member("黄金票🎫[福利中心任务复查失败] 暂不写入今日完成")
                return GoldTicketTaskFlowHandleResult(
                    querySuccess = true,
                    canMarkDone = false
                )
            }

            val pendingRetryCount = countGoldTicketPendingWelfareAutoTasks(refreshedTodoTasks)
            if (pendingRetryCount > 0) {
                Log.member("黄金票🎫[福利中心任务保留下次重试] ${pendingRetryCount}项")
            }
            return GoldTicketTaskFlowHandleResult(
                querySuccess = true,
                canMarkDone = pendingRetryCount == 0 && !adapter.hasBlockingFailure
            )
        } catch (e: Exception) {
            Log.printStackTrace(TAG, e)
            return GoldTicketTaskFlowHandleResult(querySuccess = false, canMarkDone = false)
        }
    }

    private inner class GoldTicketTaskFlowAdapter(
        private val source: String,
        private val firstTasks: JSONArray,
        private val queryTasks: () -> JSONArray?,
        private val autoTaskPredicate: (JSONObject) -> Boolean,
        private val recordUnsupportedTasks: Boolean
    ) : TaskFlowAdapter {
        override val moduleName: String = goldTicketTaskBlacklistModule
        override val flowName: String = "黄金票🎫${source}任务"

        var queryFailed: Boolean = false
            private set
        var hasBlockingFailure: Boolean = false
            private set

        private var firstQueryConsumed = false
        private var autoReceivedCount = 0
        private val unsupportedTaskKeys = LinkedHashSet<String>()
        override fun query(): JSONObject {
            val todoTasks = if (!firstQueryConsumed) {
                firstQueryConsumed = true
                firstTasks
            } else {
                queryTasks()
            }
            if (todoTasks == null) {
                queryFailed = true
                return JSONObject()
                    .put("success", false)
                    .put("resultDesc", "${source}任务查询失败")
            }
            return JSONObject()
                .put("success", true)
                .put("tasks", todoTasks)
        }

        override fun isQuerySuccess(response: JSONObject): Boolean {
            return response.optBoolean("success", false)
        }

        override fun extractItems(response: JSONObject): List<TaskFlowItem> {
            val todoTasks = response.optJSONArray("tasks") ?: return emptyList()
            val items = mutableListOf<TaskFlowItem>()
            for (i in 0 until todoTasks.length()) {
                val task = todoTasks.optJSONObject(i) ?: continue
                val taskId = task.optString("taskId").trim()
                if (taskId.isBlank()) {
                    continue
                }
                val title = task.optString("title", taskId).trim().ifBlank { taskId }
                val status = task.optString("taskProcessStatus").trim()
                val shouldHandle = status == "RECEIVE_SUCCESS" ||
                    isGoldTicketTaskRewardReady(task) || autoTaskPredicate(task)
                if (!shouldHandle) {
                    if (recordUnsupportedTasks && isGoldTicketManualHomeTask(task)) {
                        unsupportedTaskKeys.add("$taskId|$title")
                    }
                    continue
                }

                items.add(
                    TaskFlowItem(
                        id = taskId,
                        title = title,
                        status = status,
                        type = task.optString("taskType"),
                        sceneCode = task.optString("sceneCode"),
                        actionType = task.optString("actionType"),
                        blacklistKeys = listOf(taskId),
                        raw = task,
                        progress = task.optString("subTitle")
                            .ifBlank { task.optString("amount") }
                    )
                )
            }
            return items
        }

        override fun mapPhase(item: TaskFlowItem): TaskFlowPhase {
            return when (item.status) {
                "TO_RECEIVE",
                "WAIT_RECEIVE",
                "FINISHED",
                "COMPLETE" -> TaskFlowPhase.REWARD_READY

                "NONE_SIGNUP",
                "SIGNUP_EXPIRED" -> TaskFlowPhase.SIGNUP_REQUIRED

                "SIGNUP_COMPLETE" -> TaskFlowPhase.SIGNUP_COMPLETE

                "RECEIVE_SUCCESS",
                "HAS_RECEIVED",
                "DONE",
                "COMPLETED" -> TaskFlowPhase.TERMINAL

                else -> TaskFlowPhase.UNKNOWN
            }
        }

        override fun receive(item: TaskFlowItem): TaskFlowActionResult {
            if (source == "首页" && item.id == "goldTicketBigPrize") {
                val response = AntMemberRpcCall.goldTicketTriggerBigPrize()
                if (response.isNullOrBlank()) return TaskFlowActionResult.defer(
                    DeferredReason.STATE_CONFIRMATION, "大奖领取结果未知，回查首页确认",
                    rpc = "AntMemberRpcCall.goldTicketTriggerBigPrize", refreshAfterAction = true,
                )
                val result = runCatching { JSONObject(response) }.getOrNull()
                    ?: return TaskFlowActionResult.defer(
                        DeferredReason.STATE_CONFIRMATION, "大奖领取响应无法解析，回查首页确认",
                        rpc = "AntMemberRpcCall.goldTicketTriggerBigPrize", raw = response, refreshAfterAction = true,
                    )
                if (!ResChecker.checkRes(TAG, result) || isMemberMarketingRpcRisk("AntMember.goldTicket.bigPrize", result)) {
                    return goldTicketActionFailureResult(result, "AntMemberRpcCall.goldTicketTriggerBigPrize", item, "receive", source)
                }
                val amount = result.optJSONObject("result")?.optJSONObject("bigPrizeInfo")?.optString("amount").orEmpty()
                Log.member("黄金票🎫[任务大奖领取已受理]${if (amount.isNotBlank()) "#$amount 元" else ""}，回查首页确认")
                return TaskFlowActionResult.defer(
                    DeferredReason.STATE_CONFIRMATION, "确认任务大奖领取状态",
                    rpc = "AntMemberRpcCall.goldTicketTriggerBigPrize", raw = response, refreshAfterAction = true,
                )
            }
            return pushGoldTicketTask(item, "receive")
        }

        override fun signup(item: TaskFlowItem): TaskFlowActionResult {
            val response = AntMemberRpcCall.goldBillTaskTrigger(item.id)
            if (response.isNullOrBlank()) {
                return emptyGoldTicketActionResponse(item, "AntMemberRpcCall.goldBillTaskTrigger", "signup")
            }
            val result = JSONObject(response)
            if (isMemberMarketingRpcRisk("AntMember.goldTicket.goldBillTaskTrigger", result)) {
                return goldTicketActionFailureResult(
                    response = result,
                    rpc = "AntMemberRpcCall.goldBillTaskTrigger",
                    item = item,
                    action = "signup",
                    source = source
                )
            }
            if (ResChecker.checkRes(TAG, result)) {
                Log.member("黄金票🎫[${source}任务报名成功]#${item.title}")
                return TaskFlowActionResult.success(
                    refreshAfterAction = true,
                    progressChanged = false,
                )
            }
            return goldTicketActionFailureResult(
                response = result,
                rpc = "AntMemberRpcCall.goldBillTaskTrigger",
                item = item,
                action = "signup",
                source = source
            )
        }

        override fun send(item: TaskFlowItem): TaskFlowActionResult {
            return pushGoldTicketTask(item, "send")
        }

        override fun actionKey(item: TaskFlowItem, action: TaskFlowAction): String {
            return "${action.logName}:$source:${item.id}:${item.status}"
        }

        override fun afterSuccess(item: TaskFlowItem, action: TaskFlowAction, result: TaskFlowActionResult) {
            if (action == TaskFlowAction.RECEIVE || action == TaskFlowAction.SEND) {
                autoReceivedCount++
            }
        }

        override fun afterFailure(
            item: TaskFlowItem,
            action: TaskFlowAction,
            result: TaskFlowActionResult,
            decision: TaskFlowDecision
        ) {
            if (decision == TaskFlowDecision.RETRY_LATER ||
                decision == TaskFlowDecision.STOP_TODAY_OR_CURRENT_CHAIN ||
                result.failureType == TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW
            ) {
                hasBlockingFailure = true
            }
        }

        override fun onQueryFailed(response: JSONObject) {
            queryFailed = true
            Log.error(TAG, "$flowName[任务查询失败] source=$source raw=$response")
        }

        override fun logInfo(message: String) {
            Log.member(message)
        }

        override fun logError(message: String) {
            Log.error(TAG, message)
        }

        fun logSummary() {
            if (autoReceivedCount > 0) {
                Log.member("黄金票🎫[${source}任务自动领取] ${autoReceivedCount}项")
            }
            if (unsupportedTaskKeys.isNotEmpty()) {
                Log.member("黄金票🎫[${source}任务待手动处理] ${unsupportedTaskKeys.size}项")
            }
        }

        private fun pushGoldTicketTask(item: TaskFlowItem, action: String): TaskFlowActionResult {
            if (ApplicationHookConstants.isOffline()) {
                Log.member("黄金票🎫[${source}任务]#离线模式跳过taskQueryPush:${item.title}")
                return TaskFlowActionResult.failure(
                    failureType = TaskRpcFailureType.RETRYABLE_RPC,
                    code = "OFFLINE_MODE",
                    message = "当前处于离线模式，跳过taskQueryPush",
                    rpc = "AntMemberRpcCall.taskQueryPush",
                    detail = goldTicketActionDetail(item, action, source),
                    stopCurrentRound = true
                )
            }
            val response = AntMemberRpcCall.taskQueryPush(item.id)
            if (response.isNullOrBlank()) {
                return emptyGoldTicketActionResponse(item, "AntMemberRpcCall.taskQueryPush", action)
            }
            val result = JSONObject(response)
            if (isMemberMarketingRpcRisk("AntMember.goldTicket.taskQueryPush", result)) {
                return goldTicketActionFailureResult(
                    response = result,
                    rpc = "AntMemberRpcCall.taskQueryPush",
                    item = item,
                    action = action,
                    source = source
                )
            }
            if (!ResChecker.checkRes(TAG, result)) {
                return goldTicketActionFailureResult(
                    response = result,
                    rpc = "AntMemberRpcCall.taskQueryPush",
                    item = item,
                    action = action,
                    source = source
                )
            }
            val pushDone = result.optJSONObject("result")
                ?.optJSONObject("pushResult")
                ?.optBoolean("done", true)
            if (pushDone == false) {
                return TaskFlowActionResult.failure(
                    failureType = TaskRpcFailureType.RETRYABLE_RPC,
                    message = "pushResult.done=false",
                    rpc = "AntMemberRpcCall.taskQueryPush",
                    detail = goldTicketActionDetail(item, action, source),
                    stopCurrentRound = true
                )
            }

            val amount = item.raw?.optString("amount").orEmpty()
            if (amount.isNotBlank()) {
                Log.member("黄金票🎫[${source}任务领取成功]#${item.title}#+${amount}份")
            } else {
                Log.member("黄金票🎫[${source}任务领取成功]#${item.title}")
            }
            return TaskFlowActionResult.success(
                refreshAfterAction = true,
                progressChanged = false,
            )
        }

        private fun emptyGoldTicketActionResponse(
            item: TaskFlowItem,
            rpc: String,
            action: String
        ): TaskFlowActionResult {
            return TaskFlowActionResult.failure(
                failureType = TaskRpcFailureType.RETRYABLE_RPC,
                message = "${action}返回空",
                rpc = rpc,
                detail = goldTicketActionDetail(item, action, source),
                stopCurrentRound = true
            )
        }
    }

    private fun goldTicketActionFailureResult(
        response: JSONObject,
        rpc: String,
        item: TaskFlowItem,
        action: String,
        source: String
    ): TaskFlowActionResult {
        val code = extractGoldTicketRpcCode(response)
        val message = extractGoldTicketRpcMessage(response)
        isMemberMarketingRpcRisk("AntMember.goldTicket.$source", code, message)
        return TaskFlowActionResult.failure(
            failureType = classifyGoldTicketRpcFailure(response),
            code = code,
            message = message,
            rpc = rpc,
            raw = response.toString(),
            detail = goldTicketActionDetail(item, action, source)
        )
    }

    private fun goldTicketActionDetail(item: TaskFlowItem, action: String, source: String): String {
        return "source=$source taskId=${item.id} taskName=${item.title} " +
            "status=${item.status} action=$action actionType=${item.actionType}"
    }

    private fun classifyGoldTicketRpcFailure(response: JSONObject): TaskRpcFailureType {
        val code = extractGoldTicketRpcCode(response)
        val message = extractGoldTicketRpcMessage(response)
        return when {
            RpcOfflineRisk.isOfflineRisk(code, message) ->
                TaskRpcFailureType.RETRYABLE_RPC

            containsAny(message, "已领取", "已经领取", "重复领取", "重复领奖", "重复完成", "已完成", "任务已完结", "任务已结束") ->
                TaskRpcFailureType.TERMINAL_DONE

            code in setOf("104", "PROMISE_HAS_PROCESSING_TEMPLATE", "CAMP_TRIGGER_ERROR") ||
                code.contains("LIMIT", ignoreCase = true) ||
                containsAny(message, "上限", "限制", "受限", "不可领取", "资格不足", "兑完", "风控", "风险", "模板处理中") ->
                TaskRpcFailureType.BUSINESS_LIMIT

            code == "400000040" ||
                containsAny(message, "不支持rpc调用", "不支持RPC完成") ->
                TaskRpcFailureType.UNSUPPORTED_NO_CLOSURE

            code in setOf("20020012", "TASK_ID_INVALID", "ILLEGAL_ARGUMENT", "PROMISE_TEMPLATE_NOT_EXIST") ||
                containsAny(message, "参数错误", "任务ID非法", "模板不存在", "生活记录模板不存在") ->
                TaskRpcFailureType.NON_RETRYABLE_INVALID

            code in setOf("3000", "REMOTE_INVOKE_EXCEPTION", "OP_REPEAT_CHECK", "SYSTEM_BUSY", "NETWORK_ERROR") ||
                containsAny(message, "系统出错", "系统繁忙", "稍后", "繁忙", "频繁", "重试") ||
                isGoldTicketMarkedRetryable(response) ->
                TaskRpcFailureType.RETRYABLE_RPC

            else -> TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW
        }
    }

    private fun extractGoldTicketRpcCode(response: JSONObject): String {
        return response.optString("resultCode")
            .ifBlank { response.optString("errorCode") }
            .ifBlank { response.optString("code") }
            .ifBlank { response.optString("errCode") }
    }

    private fun extractGoldTicketRpcMessage(response: JSONObject): String {
        return response.optString("resultDesc")
            .ifBlank { response.optString("memo") }
            .ifBlank { response.optString("desc") }
            .ifBlank { response.optString("errorMsg") }
            .ifBlank { response.optString("errorMessage") }
            .ifBlank { response.optString("resultView") }
            .ifBlank { response.toString() }
    }

    private fun isGoldTicketMarkedRetryable(response: JSONObject): Boolean {
        return listOf("retryable", "retriable", "canRetry").any { key ->
            response.has(key) && response.optBoolean(key, false)
        }
    }

    /**
     * 黄金票提取逻辑（`queryConsumeHome` + `submitConsume`）
     */
    private fun doGoldTicketConsume(allowReplenish: Boolean = true) {
        var consumeDone = false
        var confirmRetryAt: Long? = null
        val owner = AccountSessionCoordinator.currentUserId() ?: UserMap.currentUid
        try {
            val store = UserDataStoreManager.getInstance(owner)
            if (store == null) {
                TaskExecutionReport.current()?.recordException()
                Log.error("黄金票🎫[提取未执行] 无法保存待确认单号")
                return
            }
            val pendingKey = "goldTicketConsumePending"
            val pending = store.get(pendingKey, String::class.java)?.let { JSONObject(it) }
            if (pending != null) {
                val state = TaskFlowExecutionState()
                TaskExecutionReport.current()?.recordFlow(
                    state, "AntMember", "黄金票提取确认",
                    TaskFlowRunResult(completed = false, progressed = false, stopped = true, rounds = 0,
                        deferredCount = 1, deferredReasonCounts = mapOf(DeferredReason.STATE_CONFIRMATION to 1)),
                )
                val writeOffNo = pending.optString("writeOffNo")
                if (writeOffNo.isBlank()) {
                    TaskExecutionReport.current()?.recordException()
                    Log.error("黄金票🎫[待确认记录异常] 缺少单号，保留记录并停止再次提取")
                    return
                }
                val now = System.currentTimeMillis()
                if (pending.optLong("readyAt") > now) {
                    scheduleMemberTaskContinuation(pendingKey, pending.getLong("readyAt"))
                    return
                }
                val pollingInterval = pending.optLong("pollingTimeStamp").takeIf { it > 0L }
                confirmRetryAt = pollingInterval?.let { now + it }
                pending.put("readyAt", confirmRetryAt ?: 0L)
                TaskExecutionReport.current()?.ensureCurrent(owner)
                store.put(pendingKey, pending.toString())
                val response = AntMemberRpcCall.queryConsumeResult(writeOffNo)
                if (response.isNullOrBlank()) {
                    TaskExecutionReport.current()?.recordException()
                    Log.error("黄金票🎫[提取回查失败] 接口无返回，保留待确认单号")
                    return
                }
                val resultJson = JSONObject(response)
                if (isMemberMarketingRpcRisk("AntMember.goldTicket.consumeResult", resultJson)) {
                    confirmRetryAt = null
                    pending.put("readyAt", 0L)
                    TaskExecutionReport.current()?.ensureCurrent(owner)
                    store.put(pendingKey, pending.toString())
                    return
                }
                if (!ResChecker.checkRes(TAG, resultJson)) {
                    TaskExecutionReport.current()?.recordException()
                    return
                }
                val result = resultJson.optJSONObject("result")
                val recordState = result?.optJSONObject("recordInfo")?.optString("recordState").orEmpty()
                if (recordState == "ACCEPTING") {
                    Log.member("黄金票🎫[提取中] 已受理，等待到账确认，不重复提交")
                } else {
                    TaskExecutionReport.current()?.recordException()
                    Log.error("黄金票🎫[提取结果待核实] recordState=$recordState，保留单号，不据受理成功标记到账 raw=$resultJson")
                }
                if (result?.optBoolean("shouldRetry", recordState == "ACCEPTING") == true) {
                    val interval = result.optJSONObject("fengdie")?.optLong("pollingTimeStamp")
                        ?.takeIf { it > 0L } ?: pollingInterval
                    confirmRetryAt = interval?.let { System.currentTimeMillis() + it }
                    pending.put("pollingTimeStamp", interval ?: 0L).put("readyAt", confirmRetryAt ?: 0L)
                } else {
                    confirmRetryAt = null
                    pending.put("readyAt", 0L)
                }
                TaskExecutionReport.current()?.ensureCurrent(owner)
                store.put(pendingKey, pending.toString())
                return
            }
            Log.member("黄金票🎫[准备检查余额及提取]")

            // 1. 调用新接口 queryConsumeHome 获取最新的资产信息
            val queryRes = AntMemberRpcCall.queryConsumeHome() ?: return
            val queryJson = JSONObject(queryRes)
            if (isMemberMarketingRpcRisk("AntMember.goldTicket.consumeQuery", queryJson)) return
            if (!ResChecker.checkRes(TAG, queryJson)) return

            val result = queryJson.optJSONObject("result") ?: return

            // 2. 获取余额
            val assetInfo = result.optJSONObject("assetInfo") ?: return

            val availableAmount = assetInfo.optInt("availableAmount", 0)
            val minExchangeAmount = assetInfo.optInt("minExchangeAmount", 100)
            val exchangeAmountUnit = assetInfo.optInt("exchangeAmountUnit", minExchangeAmount).coerceAtLeast(1)

            // 3. 按接口返回的门槛与步长计算提取数量
            val extractAmount = (availableAmount / exchangeAmountUnit) * exchangeAmountUnit

            if (extractAmount < minExchangeAmount) {
                Log.member("黄金票🎫[余额不足] 当前: $availableAmount，最低需$minExchangeAmount")
                if (allowReplenish) {
                    val replenishResult = ExchangeReplenisher.replenish(
                        need = ExchangeEffectNeed.MEMBER_GOLD_TICKET,
                        reason = "黄金票余额不足",
                        maxCount = 1
                    ) {
                        queryGoldTicketHomeUpsert()
                    }
                    if (replenishResult == ExchangeReplenishResult.EXCHANGED) {
                        Log.member("黄金票🎫[安心豆补兑成功] 重新检查可提取余额")
                        doGoldTicketConsume(allowReplenish = false)
                        return
                    }
                    if (replenishResult == ExchangeReplenishResult.RETRY_LATER) {
                        Log.member("黄金票🎫[安心豆补兑暂不可用] 保留后续调度重试")
                        return
                    }
                }
                consumeDone = true
                return
            }

            // 4. 获取必要参数 productId 和 bonusAmount
            var productId = ""
            val product = result.optJSONObject("product")
            if (product != null) {
                productId = product.optString("productId")
            } else if (result.has("productList") && result.optJSONArray("productList") != null && (result.optJSONArray("productList")?.length()
                    ?: 0) > 0
            ) {
                productId = result.optJSONArray("productList")?.optJSONObject(0)?.optString("productId") ?: ""
            } else if (assetInfo.optJSONArray("mainExchangePrizeList")?.length() ?: 0 > 0) {
                productId = assetInfo.optJSONArray("mainExchangePrizeList")?.optJSONObject(0)?.optString("bizNo") ?: ""
            } else if (assetInfo.optJSONArray("footerExchangePrizeList")?.length() ?: 0 > 0) {
                productId = assetInfo.optJSONArray("footerExchangePrizeList")?.optJSONObject(0)?.optString("bizNo") ?: ""
            } else {
                val backupPrize = assetInfo.optJSONObject("backupPrize")
                if (backupPrize != null && "GOLD".equals(backupPrize.optString("prizeType"), true)) {
                    productId = backupPrize.optString("bizNo")
                }
            }

            if (productId.isEmpty()) {
                Log.error("黄金票🎫[提取异常] 未找到有效的基金ID")
                return
            }

            var bonusAmount = 0
            val bonusInfo = result.optJSONObject("bonusInfo")
            if (bonusInfo != null) {
                bonusAmount = bonusInfo.optInt("bonusAmount", 0)
            }

            // 5. 提交提取
            val exchangeMoney = result.optJSONObject("calcInfo")?.optString("exchangeMoney")
                ?.takeIf { it.isNotBlank() } ?: String.format(Locale.US, "%.2f", extractAmount / 1000.0)
            Log.member("黄金票🎫[开始提取] 计划: $extractAmount 份 => $exchangeMoney 元 (持有: $availableAmount)")
            TaskExecutionReport.current()?.ensureCurrent(owner)
            store.put(pendingKey, JSONObject().put("writeOffNo", "").toString())
            val submitRes = AntMemberRpcCall.submitConsume(extractAmount, productId, bonusAmount)

            if (submitRes.isNullOrBlank()) {
                TaskExecutionReport.current()?.recordException()
                Log.error("黄金票🎫[提取结果未知] 接口无返回，保留待确认记录")
                return
            }

            val submitJson = JSONObject(submitRes)
            if (isMemberMarketingRpcRisk("AntMember.goldTicket.consumeSubmit", submitJson)) return
            if (!ResChecker.checkRes(TAG, submitJson)) {
                val submitDesc = submitJson.optString("resultDesc", submitJson.optString("memo"))
                if (submitDesc.isNotBlank()) {
                    Log.error("黄金票🎫[提取失败] $submitDesc")
                }
                if (submitJson.has("success") && !submitJson.optBoolean("success")) {
                    TaskExecutionReport.current()?.ensureCurrent(owner)
                    store.remove(pendingKey)
                }
                return
            }

            val submitResult = submitJson.optJSONObject("result")
            val writeOffNo = submitResult?.optString("writeOffNo").orEmpty()
            if (writeOffNo.isNotBlank()) {
                TaskExecutionReport.current()?.ensureCurrent(owner)
                store.put(pendingKey, JSONObject().put("writeOffNo", writeOffNo).toString())
                Log.member("黄金票🎫[提取已受理]#$exchangeMoney 元#$extractAmount 份，等待结果确认")
                doGoldTicketConsume(allowReplenish = false)
            } else {
                TaskExecutionReport.current()?.recordException()
                Log.error("黄金票🎫[提取结果未知] 未返回核销码，保留待确认记录")
            }
        } catch (e: Exception) {
            Log.printStackTrace(TAG, e)
        } finally {
            if (AccountSessionCoordinator.currentUserId() == owner) {
                confirmRetryAt?.let { scheduleMemberTaskContinuation("goldTicketConsumePending", it) }
            }
            if (consumeDone) {
                setFlagToday(StatusFlags.FLAG_ANTMEMBER_GOLD_TICKET_CONSUME_DONE)
            }
        }
    }

    private fun runExternalGameCenter() {
        val scene = "xlyy_WJCNJT"
        val source = "zfbhy_mc_wkenoz66"
        val uid = UserMap.currentUid
        if (ApplicationHookConstants.isOffline()) return
        receiveExternalGamePrizes(scene, source)
        try {
            while (uid == UserMap.currentUid && !ApplicationHookConstants.isOffline() && !Thread.currentThread().isInterrupted) {
                TaskFlowEngine(ExternalGameFeedTaskFlowAdapter(scene, source)).run()
                if (!receiveExternalGamePrizes(scene, source)) break
                // 宝箱领取可能开放下一批任务，重新使用原入口取列表。
            }
        } catch (t: Throwable) {
            if (t is CancellationException || t is InterruptedException) throw t
            Log.printStackTrace(TAG, "会员外部游戏任务失败", t)
        } finally {
            if (uid == UserMap.currentUid && !ApplicationHookConstants.isOffline() && !Thread.currentThread().isInterrupted) {
                receiveExternalGamePrizes(scene, source)
            }
        }
    }

    private fun receiveExternalGamePrizes(scene: String, source: String): Boolean {
        return try {
            TaskFlowEngine(object : TaskFlowAdapter {
                override val moduleName = "AntMember"
                override val flowName = "会员外部游戏宝箱"
                override fun query(): JSONObject = GameCenterPlayRpcCall.queryExternalGameCenter(scene, "", "", source, "").response
                    ?: JSONObject().put("success", false)
                override fun isQuerySuccess(response: JSONObject): Boolean =
                    GameCenterPlayRpcCall.isAccepted(response) && response.optJSONObject("data") != null
                override fun extractItems(response: JSONObject): List<TaskFlowItem> {
                    val data = response.optJSONObject("data") ?: return emptyList()
                    val task = data.optJSONObject("taskModule") ?: return emptyList()
                    val count = task.optInt("needReceiveTaskCertCnt", 0)
                    if (!task.optBoolean("needReceive") && count <= 0 && data.optJSONObject("taskPrizePopup") == null) return emptyList()
                    return listOf(TaskFlowItem(
                        id = scene, title = "游戏宝箱", status = "READY", raw = task,
                        progress = "$count:${task.optBoolean("needReceive")}:${task.optString("taskProgressDesc")}",
                    ))
                }
                override fun mapPhase(item: TaskFlowItem) = TaskFlowPhase.REWARD_READY
                override fun isPendingActionResolved(
                    item: TaskFlowItem, action: TaskFlowAction, response: JSONObject, items: List<TaskFlowItem>,
                ): Boolean {
                    val data = response.optJSONObject("data") ?: return false
                    val task = data.optJSONObject("taskModule") ?: return false
                    return action == TaskFlowAction.RECEIVE && task.has("needReceive") &&
                        !task.optBoolean("needReceive") && task.optInt("needReceiveTaskCertCnt") == 0 &&
                        data.optJSONObject("taskPrizePopup") == null
                }
                override fun receive(item: TaskFlowItem): TaskFlowActionResult {
                    val ack = GameCenterPlayRpcCall.batchReceiveExternalTaskPrize(scene, source)
                    if (!ack.accepted) return TaskFlowActionResult.failure(ack.failureType, message = "游戏宝箱领取失败", raw = ack.raw)
                    Log.member("会员游戏宝箱🎁领取已受理，回查剩余宝箱")
                    return TaskFlowActionResult.defer(DeferredReason.STATE_CONFIRMATION, "回查外部游戏宝箱",
                        rpc = "external.gamecenter.batchReceiveTaskPrize", raw = ack.raw, refreshAfterAction = true)
                        .copy(submissionStarted = true)
                }
                override fun logInfo(message: String) = Log.member(message)
                override fun logError(message: String) = Log.error(TAG, message)
            }).run().progressed
        } catch (t: Throwable) {
            if (t is CancellationException || t is InterruptedException) throw t
            Log.printStackTrace(TAG, "外部游戏宝箱处理失败", t)
            false
        }
    }

    private inner class ExternalGameFeedTaskFlowAdapter(private val scene: String, private val source: String) : TaskFlowAdapter {
        override val moduleName = "AntMember"
        override val flowName = "会员外部游戏任务"
        override val nonRetryableActionFlagPrefix: String = StatusFlags.FLAG_ANTMEMBER_GAME_ACTION_STOP_PREFIX
        override val continueCurrentRoundOnRetryableFailure = true

        override fun query(): JSONObject {
            val home = GameCenterPlayRpcCall.queryExternalGameCenter(scene, "", "", source, "")
            val root = home.response ?: return JSONObject().put("success", false)
            if (!home.accepted) return root
            val data = root.optJSONObject("data") ?: return root
            val feeds = JSONArray()
            if (data.optJSONObject("taskModule")?.optBoolean("reachTaskCertLimit") == true) {
                data.put("feedsList", feeds)
                return root
            }
            var page = 0
            val seenPages = mutableSetOf<String>()
            while (!ApplicationHookConstants.isOffline() && !Thread.currentThread().isInterrupted) {
                val result = GameCenterPlayRpcCall.queryExternalGameFeeds(scene, source, page)
                if (!result.accepted) return result.response ?: JSONObject().put("success", false)
                val pageData = result.response?.optJSONObject("data")
                val list = pageData?.optJSONArray("feedsList")
                    ?: return JSONObject().put("success", false).put("errorMsg", "外部游戏分页缺少列表")
                if (!seenPages.add(list.toString()) || (list.length() == 0 && pageData.optBoolean("haveNextPage"))) {
                    return JSONObject().put("success", false).put("errorMsg", "外部游戏分页没有进展")
                }
                for (i in 0 until list.length()) {
                    val feed = list.optJSONObject(i) ?: continue
                    val descriptor = GameCenterPlayRpcCall.describeTask(feed)
                    val game = descriptor.mappedTask
                    if (game != null && GameCenterPlayRpcCall.resolveTaskAction(feed).action ==
                        GameCenterPlayRpcCall.TaskAction.LEGACY_EXTERNAL_REPORT) {
                        val channel = descriptor.urlParameters["channel"].orEmpty().ifBlank { game.channel }
                        val component = GameCenterPlayRpcCall.queryNonDurationTasks(descriptor, channel)
                        if (!component.accepted) return JSONObject().put("success", false)
                            .put("errorMsg", "外部游戏组件查询失败").put("response", component.response ?: component.raw)
                        val componentData = component.response?.optJSONObject("data")
                        for (key in listOf("externalGameCenterTaskComponentVO", "ladderTaskComponentVO")) {
                            componentData?.optJSONObject(key)?.let { feed.put(key, it) }
                        }
                    }
                    feeds.put(feed)
                }
                if (!pageData.optBoolean("haveNextPage")) {
                    data.put("feedsList", feeds)
                    return root
                }
                page++
            }
            return JSONObject().put("success", false).put("errorMsg", "外部游戏查询已中断")
        }

        override fun isQuerySuccess(response: JSONObject): Boolean =
            GameCenterPlayRpcCall.isAccepted(response) && response.optJSONObject("data")?.optJSONArray("feedsList") != null

        override fun extractItems(response: JSONObject): List<TaskFlowItem> {
            val data = response.optJSONObject("data") ?: return emptyList()
            val feeds = data.optJSONArray("feedsList") ?: return emptyList()
            return (0 until feeds.length()).mapNotNull { index ->
                val feed = feeds.optJSONObject(index) ?: return@mapNotNull null
                val descriptor = GameCenterPlayRpcCall.describeTask(feed)
                val taskId = feed.optString("taskId")
                if (taskId.isBlank() && !descriptor.isGameTask) {
                    return@mapNotNull null
                }
                // 保留已有游戏协议及其异常诊断；appId仅用于本地动作去重。
                val id = taskId.ifBlank { descriptor.gameAppId }
                val component = (feed.optJSONObject("externalGameCenterTaskComponentVO")
                    ?: feed.optJSONObject("ladderTaskComponentVO"))?.optJSONArray("mainTaskList")
                val contract = descriptor.mappedTask?.takeIf { component != null }?.let { NonDurationGameTask.resolve(it, feed) }
                val selectedIds = contract?.componentTasks?.values?.flatten()?.toSet().orEmpty()
                val tasks = (0 until (component?.length() ?: 0)).mapNotNull { component?.optJSONObject(it) }
                    .filter { it.optString("appId") == descriptor.gameAppId && it.optString("taskId") in selectedIds }
                val progress = tasks.sortedBy { it.optString("taskId") }.joinToString("|") {
                    val taskProgress = it.optJSONObject("taskProgressVO")
                    listOf(scene, it.optString("taskId"),
                        GameCenterPlayRpcCall.nonDurationAction(it, descriptor.gameAppId)?.first.orEmpty(),
                        taskProgress?.optInt("currentProgress"), taskProgress?.optInt("totalProgress"),
                        it.optString("taskStatus")).joinToString(":")
                }
                val componentDone = tasks.isNotEmpty() && contract?.actions?.values?.all { it == 0 } == true
                TaskFlowItem(
                    id, feed.optString("mainTitle").ifBlank { feed.optString("subTitle") }.ifBlank { id },
                    if (componentDone) "COMPLETED" else feed.optString("taskStatus"), raw = feed, progress = progress,
                )
            }
        }

        override fun hasProgress(previous: TaskFlowItem, current: TaskFlowItem): Boolean {
            val before = (previous.raw?.optJSONObject("externalGameCenterTaskComponentVO")
                ?: previous.raw?.optJSONObject("ladderTaskComponentVO"))?.optJSONArray("mainTaskList") ?: return false
            val after = (current.raw?.optJSONObject("externalGameCenterTaskComponentVO")
                ?: current.raw?.optJSONObject("ladderTaskComponentVO"))?.optJSONArray("mainTaskList") ?: return false
            val descriptor = GameCenterPlayRpcCall.describeTask(current.raw)
            val game = descriptor.mappedTask ?: return false
            val contract = NonDurationGameTask.resolve(game, current.raw)
            val selectedIds = contract.componentTasks.values.flatten().toSet()
            for (index in 0 until before.length()) {
                val task = before.optJSONObject(index) ?: continue
                val id = task.optString("taskId")
                if (task.optString("appId") != game.appId || id !in selectedIds) continue
                val refreshed = (0 until after.length()).mapNotNull { after.optJSONObject(it) }
                    .firstOrNull { it.optString("appId") == game.appId && it.optString("taskId") == id } ?: continue
                val oldAction = GameCenterPlayRpcCall.nonDurationAction(task, game.appId) ?: continue
                val newAction = GameCenterPlayRpcCall.nonDurationAction(refreshed, game.appId) ?: continue
                if (oldAction.first == newAction.first && newAction.second < oldAction.second) return true
            }
            return false
        }

        override fun isBlacklisted(item: TaskFlowItem): Boolean = isMemberTaskInBlacklist(item.id, item.title)
        override fun mapPhase(item: TaskFlowItem): TaskFlowPhase {
            if (item.status in setOf("FINISHED", "RECEIVED", "DONE", "COMPLETED")) return TaskFlowPhase.TERMINAL
            if (item.id.isBlank()) return TaskFlowPhase.UNKNOWN
            val descriptor = GameCenterPlayRpcCall.describeTask(item.raw)
            return if (descriptor.contract != null || descriptor.mappedTask != null) TaskFlowPhase.READY_TO_COMPLETE else TaskFlowPhase.UNKNOWN
        }

        override fun complete(item: TaskFlowItem): TaskFlowActionResult {
            val action = GameCenterPlayRpcCall.resolveTaskAction(item.raw)
            val contract = action.contract
            val mapped = action.mappedTask
            if (contract != null && action.action == GameCenterPlayRpcCall.TaskAction.DURATION_ONLY) {
                val duration = GameCenterPlayRpcCall.advanceDuration(
                    stateKey = "memberExternalGame:$scene:${item.id}:${item.progress}", contract = contract,
                )
                if (!duration.success) return duration
            } else if (mapped != null && action.action == GameCenterPlayRpcCall.TaskAction.LEGACY_EXTERNAL_REPORT) {
                return runBlocking {
                    NonDurationGameTask.advance(mapped, item.raw, detail = "taskId=${item.id} scene=$scene", logger = Log::member)
                }
            } else {
                return TaskFlowActionResult.defer(DeferredReason.PREREQUISITE_PENDING, action.reason)
            }
            Log.member("会员外部游戏[${item.title}]动作已上报，回查任务和宝箱")
            return TaskFlowActionResult.defer(DeferredReason.STATE_CONFIRMATION, "回查外部游戏进度", refreshAfterAction = true)
        }

        override fun afterDeferred(item: TaskFlowItem, action: TaskFlowAction, result: TaskFlowActionResult) {
            result.deferredUntil?.let { scheduleMemberTaskContinuation("memberExternalGameCenter", it) }
        }

        override fun logInfo(message: String) = Log.member(message)
        override fun logError(message: String) = Log.error(TAG, message)
    }

    private suspend fun enableGameCenter() {
        try {
            if (hasFlagToday(StatusFlags.FLAG_ANTMEMBER_GAME_CENTER_DONE)) {
                Log.member("游戏中心🎮[今日已处理，跳过]")
                return
            }

            var signInResult = DailyTaskProcessResult.UNKNOWN_FAILURE
            var platformTaskResult = DailyTaskProcessResult.UNKNOWN_FAILURE
            var pointBallResult = DailyTaskProcessResult.UNKNOWN_FAILURE
            var p2eTaskResult = DailyTaskProcessResult.UNKNOWN_FAILURE
            var p2eSignInResult = DailyTaskProcessResult.UNKNOWN_FAILURE
            var p2eDrawGoldResult = DailyTaskProcessResult.UNKNOWN_FAILURE
            var p2eCashExchangeResult = DailyTaskProcessResult.UNKNOWN_FAILURE

            // 1. 查询签到状态并尝试签到
            try {
                val resp = AntMemberRpcCall.querySignInBall()
                val root = JSONObject(resp)
                if (!ResChecker.checkRes(TAG, root)) {
                    val msg = root.optString("errorMsg", root.optString("resultView", resp))
                    Log.error("$TAG.enableGameCenter.signIn", "游戏中心🎮[签到查询失败]#$msg")
                } else {
                    val data = root.optJSONObject("data")

                    if (data == null || data.length() == 0) {
                        Log.member("游戏中心🎮[签到状态为空，跳过签到]")
                        signInResult = DailyTaskProcessResult.HANDLED
                    } else {
                        val signModule = data.optJSONObject("signInBallModule")
                        if (signModule == null) {
                            Log.member("游戏中心🎮[暂无签到模块]")
                            signInResult = DailyTaskProcessResult.HANDLED
                        } else if (signModule.optBoolean("signInStatus", false)) {
                            Log.member("游戏中心🎮[今日已签到]")
                            signInResult = DailyTaskProcessResult.HANDLED
                        } else {
                            val signResp = AntMemberRpcCall.continueSignIn()
                            val signJo = JSONObject(signResp)
                            if (!ResChecker.checkRes(TAG, signJo)) {
                                val msg = signJo.optString(
                                    "errorMsg", signJo.optString("resultView", signResp)
                                )
                                Log.error("$TAG.enableGameCenter.signIn", "游戏中心🎮[签到失败]#$msg")
                            } else {
                                val signData = signJo.optJSONObject("data")
                                var title = ""
                                var desc = ""
                                var type = ""
                                if (signData != null) {
                                    val toast = signData.optJSONObject("autoSignInToastModule")
                                    if (toast != null) {
                                        title = toast.optString("title", "")
                                        desc = toast.optString("desc", "")
                                        type = toast.optString("type", "")
                                    }
                                }
                                val toastSuccess = "SUCCESS".equals(type, ignoreCase = true) && !title.contains("失败") && !desc.contains("失败")
                                if (toastSuccess) {
                                    val sb = StringBuilder()
                                    sb.append("游戏中心🎮[每日签到成功]")
                                    if (!title.isEmpty()) {
                                        sb.append("#").append(title)
                                    }
                                    if (!desc.isEmpty()) {
                                        sb.append("#").append(desc)
                                    }
                                    Log.member(sb.toString())
                                    signInResult = DailyTaskProcessResult.HANDLED
                                } else {
                                    val sb = StringBuilder()
                                    if (!title.isEmpty()) {
                                        sb.append(title)
                                    }
                                    if (!desc.isEmpty()) {
                                        if (sb.isNotEmpty()) sb.append(" ")
                                        sb.append(desc)
                                    }
                                    Log.error(
                                        "$TAG.enableGameCenter.signIn", "游戏中心🎮[签到失败]#" + (if (sb.isNotEmpty()) sb.toString() else signResp)
                                    )
                                }
                            }
                        }
                    }
                }
            } catch (th: Throwable) {
                Log.printStackTrace(TAG, "enableGameCenter.signIn err:", th)
            }

            // 2. 查询任务列表,完成平台任务
            try {
                platformTaskResult = runGameCenterPlatformTaskFlow()
            } catch (th: Throwable) {
                Log.printStackTrace(TAG, "enableGameCenter.tasks err:", th)
            }

            // 3. 查询待收乐豆并使用一键收取接口
            try {
                val resp = AntMemberRpcCall.queryPointBallList()
                val root = JSONObject(resp)
                if (!ResChecker.checkRes(TAG, root)) {
                    val msg = root.optString("errorMsg", root.optString("resultView", resp))
                    Log.error("$TAG.enableGameCenter.point", "游戏中心🎮[查询待收乐豆失败]#$msg")
                } else {
                    val data = root.optJSONObject("data")
                    val pointBallList = data?.optJSONArray("pointBallList")
                    if (pointBallList == null || pointBallList.length() == 0) {
                        Log.member("游戏中心🎮[暂无可领取乐豆]")
                        pointBallResult = DailyTaskProcessResult.HANDLED
                    } else {
                        val batchResp = AntMemberRpcCall.batchReceivePointBall()
                        val batchJo = JSONObject(batchResp)
                        if (ResChecker.checkRes(TAG, batchJo)) {
                            val batchData = batchJo.optJSONObject("data")
                            val receiveAmount = batchData?.optInt("receiveAmount", 0) ?: 0
                            val totalAmount = batchData?.optInt("totalAmount", receiveAmount) ?: receiveAmount
                            if (receiveAmount > 0) {
                                Log.member("游戏中心🎮[一键领取乐豆成功]#本次领取" + receiveAmount + " | 当前累计" + totalAmount + "玩乐豆")
                            } else {
                                Log.member("游戏中心🎮[暂无可领取乐豆]")
                            }
                            pointBallResult = DailyTaskProcessResult.HANDLED
                        } else {
                            val msg = batchJo.optString(
                                "errorMsg", batchJo.optString("resultView", batchResp)
                            )
                            Log.error(
                                "$TAG.enableGameCenter.point", "游戏中心🎮[一键领取乐豆失败]#$msg"
                            )
                        }
                    }
                }
            } catch (th: Throwable) {
                Log.printStackTrace(TAG, "enableGameCenter.point err:", th)
            }

            // 4. 游戏中心赚现金任务
            try {
                p2eTaskResult = runGameCenterP2eTaskFlow()
            } catch (th: Throwable) {
                Log.printStackTrace(TAG, "enableGameCenter.p2eTasks err:", th)
            }

            // 5. 游戏中心赚现金签到
            try {
                p2eSignInResult = doGameCenterP2eSignIn()
            } catch (th: Throwable) {
                Log.printStackTrace(TAG, "enableGameCenter.p2eSignIn err:", th)
            }

            // 6. 游戏中心赚现金抽金币
            try {
                p2eDrawGoldResult = doGameCenterP2eDrawGold()
            } catch (th: Throwable) {
                Log.printStackTrace(TAG, "enableGameCenter.p2eDrawGold err:", th)
            }

            // 7. 仅在服务端返回当前选中的固定10元档时自动提现。
            try {
                p2eCashExchangeResult = doGameCenterP2eCashExchange()
            } catch (th: Throwable) {
                Log.printStackTrace(TAG, "enableGameCenter.p2eCashExchange err:", th)
            }

            if (listOf(
                    signInResult,
                    platformTaskResult,
                    pointBallResult,
                    p2eTaskResult,
                    p2eSignInResult,
                    p2eDrawGoldResult,
                    p2eCashExchangeResult
                ).all { it == DailyTaskProcessResult.HANDLED }
            ) {
                setFlagToday(StatusFlags.FLAG_ANTMEMBER_GAME_CENTER_DONE)
            }
        } catch (t: Throwable) {
            Log.printStackTrace(TAG, t)
        }
    }

    private fun runGameCenterP2eTaskFlow(): DailyTaskProcessResult {
        val adapter = GameCenterP2eTaskFlowAdapter()
        val runResult = TaskFlowEngine(adapter, roundSleepMs = 425L).run()
        if (adapter.taskCount == 0) {
            Log.member("游戏中心🎮[赚现金暂无任务模块]")
        } else if (adapter.availableTaskCount == 0) {
            Log.member("游戏中心🎮[赚现金当前无可立即提交任务，游戏业务条件仍以列表状态为准]")
        }
        return when {
            adapter.queryFailed || adapter.hasPartialQueryFailure || adapter.hasBlockingFailure ->
                DailyTaskProcessResult.UNKNOWN_FAILURE
            adapter.hasRetryableFailure || runResult.stopped -> DailyTaskProcessResult.RETRYABLE_FAILURE
            else -> DailyTaskProcessResult.HANDLED
        }
    }

    private fun runGameCenterPlatformTaskFlow(): DailyTaskProcessResult {
        val adapter = GameCenterPlatformTaskFlowAdapter()
        val runResult = TaskFlowEngine(adapter, roundSleepMs = 425L).run()
        if (adapter.taskCount == 0) {
            Log.member("游戏中心🎮[暂无平台任务模块]")
        } else if (adapter.availableTaskCount == 0) {
            Log.member("游戏中心🎮[平台列表当前无可立即提交任务]")
        }
        return when {
            adapter.queryFailed || adapter.hasBlockingFailure -> DailyTaskProcessResult.UNKNOWN_FAILURE
            adapter.hasRetryableFailure || runResult.stopped -> DailyTaskProcessResult.RETRYABLE_FAILURE
            else -> DailyTaskProcessResult.HANDLED
        }
    }

    private fun gameCenterPlayContract(task: JSONObject): GameCenterPlayRpcCall.Contract? =
        GameCenterPlayRpcCall.resolveContract(task)

    private inner class GameCenterPlatformTaskFlowAdapter : TaskFlowAdapter {
        override val moduleName: String = memberTaskBlacklistModule
        override val flowName: String = "游戏中心🎮平台任务"
        override val nonRetryableActionFlagPrefix: String = StatusFlags.FLAG_ANTMEMBER_GAME_ACTION_STOP_PREFIX

        var queryFailed: Boolean = false
            private set
        var hasBlockingFailure: Boolean = false
            private set
        var hasRetryableFailure: Boolean = false
            private set
        var taskCount: Int = 0
            private set
        var availableTaskCount: Int = 0
            private set

        private val loggedSkipKeys = LinkedHashSet<String>()

        override fun query(): JSONObject {
            return try {
                val raw = AntMemberRpcCall.queryGameCenterTaskList()
                val response = JSONObject(raw)
                response
                    .put("_taskFlowQuerySuccess", ResChecker.checkRes(TAG, response))
                    .put("_rawResponse", raw)
            } catch (t: Throwable) {
                JSONObject()
                    .put("_taskFlowQuerySuccess", false)
                    .put("resultView", "查询异常:${t.message}")
            }
        }

        override fun isQuerySuccess(response: JSONObject): Boolean {
            return response.optBoolean("_taskFlowQuerySuccess", false)
        }

        override fun extractItems(response: JSONObject): List<TaskFlowItem> {
            val data = response.optJSONObject("data") ?: return emptyList()
            val platformTasks = collectGameCenterPlatformTasks(data)
            taskCount = max(taskCount, platformTasks.size)
            availableTaskCount = 0
            val items = mutableListOf<TaskFlowItem>()
            for (task in platformTasks) {
                val taskId = task.optString("taskId")
                val title = task.optString("title").ifBlank {
                    task.optString("subTitle").ifBlank { taskId }
                }
                val status = task.optString("taskStatus")
                if (status == "NOT_DONE" || status == "SIGNUP_COMPLETE") {
                    availableTaskCount++
                }
                items.add(
                    TaskFlowItem(
                        id = taskId,
                        title = title,
                        status = status,
                        type = if (task.optBoolean("needSignUp", false)) "SIGNUP_TASK" else "PLATFORM_TASK",
                        actionType = "doTaskSend",
                        blacklistKeys = buildGameCenterPlatformBlacklistKeys(taskId, task),
                        raw = task,
                        progress = "pointAmount=${task.optInt("pointAmount", 0)}"
                    )
                )
            }
            return items
        }

        private fun collectGameCenterPlatformTasks(data: JSONObject): List<JSONObject> {
            val tasksById = LinkedHashMap<String, JSONObject>()
            val modules = listOfNotNull(
                data.optJSONObject("gameTaskModule"),
                data.optJSONObject("platformTaskModule"),
                data.optJSONObject("platformGameTaskModule"),
            )
            modules.forEach { taskModule ->
                listOfNotNull(
                    taskModule.optJSONArray("gameTaskList"),
                    taskModule.optJSONArray("platformTaskList"),
                    taskModule.optJSONArray("taskList"),
                ).forEach { taskList ->
                    for (i in 0 until taskList.length()) {
                        val task = taskList.optJSONObject(i) ?: continue
                        val taskId = task.optString("taskId").trim()
                        if (taskId.isBlank()) continue
                        if (task.optString("taskType").uppercase(Locale.ROOT) in setOf("GAME_TRAN_TASK", "PLATFORM_TRAN_TASK")) continue
                        val current = tasksById[taskId]
                        if (current == null || shouldReplaceGameCenterPlatformTask(current, task)) {
                            tasksById[taskId] = task
                        }
                    }
                }
            }
            return tasksById.values.toList()
        }

        private fun shouldReplaceGameCenterPlatformTask(
            currentTask: JSONObject,
            candidateTask: JSONObject,
        ): Boolean {
            val candidateScore = scoreGameCenterPlatformTask(candidateTask)
            val currentScore = scoreGameCenterPlatformTask(currentTask)
            return candidateScore > currentScore ||
                (candidateScore == currentScore &&
                    candidateTask.optString("taskStatus").isNotBlank() &&
                    currentTask.optString("taskStatus").isBlank())
        }

        private fun scoreGameCenterPlatformTask(task: JSONObject): Int {
            var score = 0
            if (task.optString("taskStatus").isNotBlank()) score += 4
            if (task.optString("title").isNotBlank()) score += 2
            if (task.optString("subTitle").isNotBlank()) score++
            if (task.optString("taskType").isNotBlank()) score++
            if (task.optString("gameAppId").isNotBlank() || task.optString("appId").isNotBlank()) score += 2
            if (task.optString("source").isNotBlank() || task.optString("chInfo").isNotBlank()) score++
            if (gameCenterPlayContract(task) != null) score += 5
            return score
        }

        override fun mapPhase(item: TaskFlowItem): TaskFlowPhase {
            if (item.id.isBlank()) {
                return TaskFlowPhase.UNKNOWN
            }
            val raw = item.raw ?: JSONObject()
            val status = item.status.uppercase(Locale.ROOT)
            if (status in setOf("RECEIVED", "DONE", "FINISHED", "COMPLETE", "COMPLETED", "SUCCESS")) {
                return TaskFlowPhase.TERMINAL
            }
            if (raw.optString("taskType").equals("GAME_TRAN_TASK", ignoreCase = true) &&
                GameCenterPlayRpcCall.resolveTaskAction(raw).action !in setOf(
                    GameCenterPlayRpcCall.TaskAction.DURATION_ONLY,
                    GameCenterPlayRpcCall.TaskAction.LEGACY_EXTERNAL_REPORT,
                )
            ) {
                return TaskFlowPhase.UNSUPPORTED
            }
            return when (status) {
                "NOT_DONE" -> if (item.raw?.optBoolean("needSignUp", false) == true) {
                    TaskFlowPhase.SIGNUP_REQUIRED
                } else {
                    TaskFlowPhase.READY_TO_COMPLETE
                }
                "SIGNUP_COMPLETE" -> TaskFlowPhase.SIGNUP_COMPLETE
                else -> TaskFlowPhase.UNKNOWN
            }
        }

        override fun shouldSkip(item: TaskFlowItem): Boolean {
            if (mapPhase(item) == TaskFlowPhase.UNSUPPORTED) {
                handleUnsupportedGameCenterTask(item)
                return true
            }
            return false
        }

        override fun isUnresolvedWhenSkipped(item: TaskFlowItem): Boolean =
            !isBlacklisted(item) && mapPhase(item) == TaskFlowPhase.UNSUPPORTED

        override fun isBlacklisted(item: TaskFlowItem): Boolean {
            val blacklisted = super<TaskFlowAdapter>.isBlacklisted(item)
            if (blacklisted) {
                logSkipOnce(item, "任务在自动跳过列表(黑名单)中，跳过")
            }
            return blacklisted
        }

        override fun blacklist(item: TaskFlowItem, result: TaskFlowActionResult) {
            val task = item.raw ?: JSONObject()
            val persistKeys = buildGameCenterPlatformPersistKeys(item.id, task)
            if (persistKeys.isEmpty()) {
                super<TaskFlowAdapter>.blacklist(item, result)
                return
            }
            val primaryKey = persistKeys.first()
            if (result.code.isNotBlank()) {
                TaskBlacklist.autoAddToBlacklist(moduleName, primaryKey, errorCode = result.code)
            }
            TaskBlacklist.addToBlacklist(moduleName, primaryKey)
            persistKeys.drop(1).forEach { TaskBlacklist.addToBlacklist(moduleName, it) }
        }

        override fun signup(item: TaskFlowItem): TaskFlowActionResult {
            val response = AntMemberRpcCall.doTaskSignup(item.id)
            val responseObject = JSONObject(response)
            if (!ResChecker.checkRes(TAG, responseObject)) {
                return gameCenterTaskFailureResult(
                    item = item,
                    responseObject = responseObject,
                    rawResponse = response,
                    rpc = "AntMemberRpcCall.doTaskSignup"
                )
            }
            Log.member("游戏中心🎮任务[${item.title}]#报名完成")
            return TaskFlowActionResult.success(
                refreshAfterAction = true,
                progressChanged = false,
            )
        }

        override fun complete(item: TaskFlowItem): TaskFlowActionResult {
            return sendGameCenterTask(item)
        }

        override fun send(item: TaskFlowItem): TaskFlowActionResult {
            return sendGameCenterTask(item)
        }

        override fun actionKey(item: TaskFlowItem, action: TaskFlowAction): String {
            return "${action.logName}:${item.id}:${item.status}"
        }

        override fun afterFailure(
            item: TaskFlowItem,
            action: TaskFlowAction,
            result: TaskFlowActionResult,
            decision: TaskFlowDecision
        ) {
            when (decision) {
                TaskFlowDecision.RETRY_LATER -> hasRetryableFailure = true
                TaskFlowDecision.LOG_ONLY -> hasBlockingFailure = true
                TaskFlowDecision.MARK_HANDLED,
                TaskFlowDecision.STOP_TODAY_OR_CURRENT_CHAIN,
                TaskFlowDecision.BLACKLIST -> Unit
            }
        }

        override fun onAllTasksDone(snapshot: TaskFlowSnapshot) {
            logInfo("游戏中心🎮[平台任务已处理完成：${snapshot.completedTasks}/${snapshot.totalTasks}]")
        }

        override fun onQueryFailed(response: JSONObject) {
            queryFailed = true
            val msg = response.optString("errorMsg")
                .ifBlank { response.optString("resultView") }
                .ifBlank { response.optString("resultDesc") }
                .ifBlank { response.optString("_rawResponse", response.toString()) }
            Log.error("$TAG.enableGameCenter.tasks", "$flowName[任务查询失败] reason=$msg")
        }

        override fun onUnknownPhase(item: TaskFlowItem, phase: TaskFlowPhase) {
            hasBlockingFailure = true
            Log.error(
                "$TAG.enableGameCenter.tasks",
                "游戏中心🎮任务[${item.title}]未知状态 taskId=${item.id} status=${item.status} raw=${item.raw}"
            )
        }

        override fun logInfo(message: String) {
            Log.member(message)
        }

        override fun logError(message: String) {
            Log.error(TAG, message)
        }

        private fun handleUnsupportedGameCenterTask(item: TaskFlowItem) {
            val raw = item.raw ?: JSONObject()
            val taskType = raw.optString("taskType").ifBlank { "UNKNOWN" }
            logSkipOnce(
                item,
                if (taskType.equals("GAME_TRAN_TASK", ignoreCase = true)) {
                    "等待游戏业务状态推进：${GameCenterPlayRpcCall.resolveTaskAction(raw).reason}"
                } else {
                    "当前暂无稳定自动闭环:taskType=$taskType"
                },
            )
            hasBlockingFailure = true
        }

        private fun buildGameCenterPlatformBlacklistKeys(taskId: String, task: JSONObject): List<String> {
            return buildGameCenterPlatformPersistKeys(taskId, task)
        }

        private fun buildGameCenterPlatformPersistKeys(taskId: String, task: JSONObject): List<String> {
            return listOf(taskId).filter { it.isNotBlank() }
        }

        private fun toGameCenterPlatformTaskSnapshot(taskId: String, task: JSONObject): GameCenterPlatformTaskSnapshot {
            val title = task.optString("title").ifBlank {
                task.optString("subTitle").ifBlank { taskId }
            }
            return GameCenterPlatformTaskSnapshot(
                taskId = taskId,
                title = title,
                subTitle = task.optString("subTitle"),
                status = task.optString("taskStatus"),
                buttonText = task.optString("buttonText"),
                needSignUp = task.optBoolean("needSignUp", false),
                gameId = task.optString("gameId"),
                appId = task.optString("appId"),
                pointAmount = task.optInt("pointAmount", 0)
            )
        }

        private fun findGameCenterPlatformTaskById(response: JSONObject, taskId: String): GameCenterPlatformTaskSnapshot? {
            val data = response.optJSONObject("data") ?: return null
            for (task in collectGameCenterPlatformTasks(data)) {
                if (taskId == task.optString("taskId")) {
                    return toGameCenterPlatformTaskSnapshot(taskId, task)
                }
            }
            return null
        }

        private fun isGameCenterPlatformTaskTerminal(snapshot: GameCenterPlatformTaskSnapshot): Boolean {
            return snapshot.status.uppercase(Locale.ROOT) in setOf(
                "DONE",
                "FINISHED",
                "COMPLETED",
                "COMPLETE",
                "SUCCESS",
                "RECEIVED"
            )
        }

        private fun buildGameCenterPlatformRecheckDetail(
            item: TaskFlowItem,
            snapshot: GameCenterPlatformTaskSnapshot?
        ): String {
            val baseDetail = gameCenterTaskActionDetail(item, "send+recheck")
            if (snapshot == null) {
                return "$baseDetail recheckTask=MISSING"
            }
            return "$baseDetail recheckStatus=${snapshot.status.ifBlank { "UNKNOWN" }}" +
                " recheckButton=${snapshot.buttonText.ifBlank { "UNKNOWN" }}" +
                " recheckTitle=${snapshot.title.ifBlank { "UNKNOWN" }}" +
                " recheckSubTitle=${snapshot.subTitle.ifBlank { "UNKNOWN" }}"
        }

        private fun buildGameCenterPlatformFakeSuccessMessage(
            item: TaskFlowItem,
            snapshot: GameCenterPlatformTaskSnapshot
        ): String {
            return "doTaskSend仅ACK，复查仍未完成" +
                "(before=${item.status.ifBlank { "UNKNOWN" }}" +
                ",after=${snapshot.status.ifBlank { "UNKNOWN" }}" +
                ",button=${snapshot.buttonText.ifBlank { "UNKNOWN" }})"
        }

        private fun buildGameCenterPlatformCombinedRaw(sendResponse: String, recheckRaw: String): String {
            return "send=$sendResponse recheck=$recheckRaw"
        }

        private fun sendGameCenterTask(item: TaskFlowItem): TaskFlowActionResult {
            val decision = GameCenterPlayRpcCall.resolveTaskAction(item.raw)
            if (decision.action == GameCenterPlayRpcCall.TaskAction.LEGACY_EXTERNAL_REPORT) {
                return runBlocking {
                    NonDurationGameTask.advance(
                        requireNotNull(decision.mappedTask), item.raw,
                        detail = gameCenterTaskActionDetail(item, "gameReport"), logger = Log::member,
                    )
                }
            }
            decision.contract?.let { contract ->
                val ack = GameCenterPlayRpcCall.submitForAck(contract)
                val response = ack.response
                    ?: return TaskFlowActionResult.failure(
                        failureType = ack.failureType,
                        message = "时长动作响应无法解析",
                        rpc = "GameCenterPlayRpcCall.submit",
                        raw = ack.raw,
                        detail = gameCenterTaskActionDetail(item, "playDuration"),
                    )
                if (!ack.accepted) {
                    return TaskFlowActionResult.failure(
                        failureType = ack.failureType,
                        code = response.optString("resultCode"),
                        message = response.optString("resultDesc", response.optString("desc", ack.raw)),
                        rpc = "GameCenterPlayRpcCall.submit",
                        raw = ack.raw,
                        detail = gameCenterTaskActionDetail(item, "playDuration"),
                    )
                }
                return TaskFlowActionResult.defer(
                    deferredReason = DeferredReason.STATE_CONFIRMATION,
                    message = "时长上报已接受，等待游戏平台任务列表确认",
                    rpc = "GameCenterPlayRpcCall.submit",
                    raw = ack.raw,
                    detail = gameCenterTaskActionDetail(item, "playDuration"),
                    refreshAfterAction = true,
                )
            }

            val sendResponse = AntMemberRpcCall.doTaskSend(item.id)
            val sendResponseObject = JSONObject(sendResponse)
            if (!ResChecker.checkRes(TAG, sendResponseObject)) {
                val failure = gameCenterTaskFailureResult(
                    item = item,
                    responseObject = sendResponseObject,
                    rawResponse = sendResponse,
                    rpc = "AntMemberRpcCall.doTaskSend"
                )
                val sceneCode = item.raw?.optString("sceneCode").orEmpty()
                if (failure.code == "400000040" && sceneCode.isNotBlank()) {
                    val bizKey = item.raw?.optString("bizKey").orEmpty().ifBlank { item.id }
                    return AntFarmRpcCall.doSceneTask(bizKey, sceneCode, failure, sceneCode = sceneCode, source = "H5") { fallback ->
                        gameCenterTaskFailureResult(item, fallback, fallback.toString(), "AntFarmRpcCall.doFarmTask")
                    }
                }
                return failure
            }

            // doTaskSend 在最新抓包里经常只返回 transport ACK，必须立刻复查任务列表确认真实进度。
            val recheckResponse = query()
            val recheckRaw = recheckResponse.optString("_rawResponse", recheckResponse.toString())
            if (!isQuerySuccess(recheckResponse)) {
                val recheckFailure = gameCenterTaskFailureResult(
                    item = item,
                    responseObject = recheckResponse,
                    rawResponse = recheckRaw,
                    rpc = "AntMemberRpcCall.queryGameCenterTaskList"
                )
                return recheckFailure.copy(
                    rpc = "AntMemberRpcCall.doTaskSend+AntMemberRpcCall.queryGameCenterTaskList",
                    raw = buildGameCenterPlatformCombinedRaw(sendResponse, recheckRaw),
                    detail = buildGameCenterPlatformRecheckDetail(item, null),
                    stopCurrentRound = true
                )
            }

            val snapshot = findGameCenterPlatformTaskById(recheckResponse, item.id)
            if (snapshot == null) {
                return TaskFlowActionResult.failure(
                    failureType = TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW,
                    code = "POST_SEND_QUERY_MISS",
                    message = "doTaskSend后复查未找到目标任务",
                    rpc = "AntMemberRpcCall.doTaskSend+AntMemberRpcCall.queryGameCenterTaskList",
                    raw = buildGameCenterPlatformCombinedRaw(sendResponse, recheckRaw),
                    detail = buildGameCenterPlatformRecheckDetail(item, null),
                    stopCurrentRound = true
                )
            }

            if (!isGameCenterPlatformTaskTerminal(snapshot)) {
                return TaskFlowActionResult.defer(
                    deferredReason = DeferredReason.STATE_CONFIRMATION,
                    message = buildGameCenterPlatformFakeSuccessMessage(item, snapshot),
                    rpc = "AntMemberRpcCall.doTaskSend+AntMemberRpcCall.queryGameCenterTaskList",
                    raw = buildGameCenterPlatformCombinedRaw(sendResponse, recheckRaw),
                    detail = buildGameCenterPlatformRecheckDetail(item, snapshot),
                    refreshAfterAction = true,
                )
            }

            val title = snapshot.subTitle.ifBlank { snapshot.title }
            Log.member(
                "游戏中心🎮任务[$title]#完成,奖励${snapshot.pointAmount}玩乐豆" +
                    if (snapshot.needSignUp) "(签到任务)" else ""
            )
            return TaskFlowActionResult.success()
        }

        private fun logSkipOnce(item: TaskFlowItem, reason: String) {
            val key = "$reason|${item.id}"
            if (loggedSkipKeys.add(key)) {
                Log.member("游戏中心🎮任务[${item.title}]#$reason")
            }
        }
    }

    private inner class GameCenterP2eTaskFlowAdapter : TaskFlowAdapter {
        override val moduleName: String = memberTaskBlacklistModule
        override val flowName: String = "游戏中心🎮赚现金任务"
        override val nonRetryableActionFlagPrefix: String = StatusFlags.FLAG_ANTMEMBER_GAME_ACTION_STOP_PREFIX

        var queryFailed: Boolean = false
            private set
        var hasPartialQueryFailure: Boolean = false
            private set
        var hasBlockingFailure: Boolean = false
            private set
        var hasRetryableFailure: Boolean = false
            private set
        var taskCount: Int = 0
            private set
        var availableTaskCount: Int = 0
            private set

        private val loggedSkipKeys = LinkedHashSet<String>()
        private val sessionId = System.currentTimeMillis().toString()
        private var partialQueryFailureLogged = false

        override fun query(): JSONObject {
            val homeSnapshot = queryGameCenterP2eSnapshot(
                AntMemberRpcCall.GAME_CENTER_SOURCE,
                queryHomePage = true,
            )
            val taskSnapshot = queryGameCenterP2eSnapshot(AntMemberRpcCall.GAME_CENTER_P2E_SOURCE)
            val anySuccess = homeSnapshot.success || taskSnapshot.success
            val partialFailure = anySuccess && (!homeSnapshot.success || !taskSnapshot.success)
            val mergedTaskMap = LinkedHashMap<String, JSONObject>()
            val exposedTaskMap = LinkedHashMap<String, JSONObject>()

            if (homeSnapshot.success) {
                mergeGameCenterP2eTasksFromSnapshot(homeSnapshot, mergedTaskMap, exposedTaskMap)
            }
            if (taskSnapshot.success) {
                mergeGameCenterP2eTasksFromSnapshot(taskSnapshot, mergedTaskMap, exposedTaskMap)
            }

            val mergedTaskList = JSONArray().apply {
                mergedTaskMap.values.forEach(::put)
            }
            val exposedTaskList = JSONArray().apply {
                exposedTaskMap.values.forEach(::put)
            }
            return JSONObject().apply {
                put("_taskFlowQuerySuccess", anySuccess)
                put("_gcPartialQueryFailure", partialFailure)
                put("_gcMergedTaskList", mergedTaskList)
                put("_gcExposedTaskList", exposedTaskList)
                put("_rawResponse", buildGameCenterP2eCombinedRaw(homeSnapshot, taskSnapshot))
                if (!anySuccess) {
                    put("resultView", buildGameCenterP2eQueryFailureMessage(homeSnapshot, taskSnapshot))
                } else if (partialFailure) {
                    put("_gcPartialQueryFailureMessage", buildGameCenterP2ePartialFailureMessage(homeSnapshot, taskSnapshot))
                }
            }
        }

        override fun isQuerySuccess(response: JSONObject): Boolean {
            val success = response.optBoolean("_taskFlowQuerySuccess", false)
            val partialFailure = response.optBoolean("_gcPartialQueryFailure", false)
            queryFailed = queryFailed || !success
            hasPartialQueryFailure = hasPartialQueryFailure || partialFailure
            if (partialFailure && !partialQueryFailureLogged) {
                partialQueryFailureLogged = true
                val msg = response.optString("_gcPartialQueryFailureMessage")
                    .ifBlank { response.optString("_rawResponse") }
                Log.error("$TAG.enableGameCenter.p2eTasks", "游戏中心🎮[赚现金任务列表部分查询失败]#$msg")
            }
            return success
        }

        override fun extractItems(response: JSONObject): List<TaskFlowItem> {
            val exposedTaskList = response.optJSONArray("_gcExposedTaskList")
                ?: JSONArray()
            reportGameCenterP2eExposedTasks(exposedTaskList)

            val items = mutableListOf<TaskFlowItem>()
            val mergedTaskList = response.optJSONArray("_gcMergedTaskList") ?: JSONArray()
            appendGameCenterP2eTasks(items, mergedTaskList)
            taskCount = max(taskCount, items.size)
            availableTaskCount = items.count { item ->
                when (mapPhase(item)) {
                    TaskFlowPhase.REWARD_READY,
                    TaskFlowPhase.READY_TO_COMPLETE,
                    TaskFlowPhase.SIGNUP_REQUIRED,
                    TaskFlowPhase.SIGNUP_COMPLETE -> true
                    else -> false
                }
            }
            return items
        }

        override fun mapPhase(item: TaskFlowItem): TaskFlowPhase {
            val status = item.status.uppercase(Locale.ROOT)
            if (status in setOf("COMPLETED", "COMPLETE", "FINISHED")) {
                return TaskFlowPhase.REWARD_READY
            }
            if (!item.raw?.optString("taskMileStoneId").isNullOrBlank()) {
                return if (status == "RECEIVED") TaskFlowPhase.TERMINAL else TaskFlowPhase.BUSINESS_ACTION
            }
            if (!isGameCenterP2eCompletableTask(item)) {
                return TaskFlowPhase.UNSUPPORTED
            }
            return when (status) {
                "UN_SIGNUP",
                "NONE_SIGNUP" -> if (isGameCenterP2eAutoTask(item) &&
                    item.raw?.optBoolean("needSignUp", false) == true
                ) {
                    TaskFlowPhase.SIGNUP_REQUIRED
                } else {
                    TaskFlowPhase.READY_TO_COMPLETE
                }
                "SIGNUP_COMPLETED",
                "SIGNUP_COMPLETE" -> TaskFlowPhase.SIGNUP_COMPLETE
                "NOT_DONE",
                "IN_COMPLETE",
                "PROCESSING" -> TaskFlowPhase.READY_TO_COMPLETE
                "RECEIVED",
                "DONE",
                "SUCCESS" -> TaskFlowPhase.TERMINAL
                else -> TaskFlowPhase.UNKNOWN
            }
        }

        override fun shouldSkip(item: TaskFlowItem): Boolean {
            val phase = mapPhase(item)
            if (phase == TaskFlowPhase.UNSUPPORTED) {
                handleUnsupportedP2eTask(item)
                return true
            }
            val raw = item.raw ?: JSONObject()
            if (raw.optString("taskMileStoneId").isNotBlank()) {
                return phase != TaskFlowPhase.REWARD_READY && phase != TaskFlowPhase.TERMINAL
            }
            if ((phase == TaskFlowPhase.REWARD_READY ||
                    phase == TaskFlowPhase.READY_TO_COMPLETE ||
                    phase == TaskFlowPhase.SIGNUP_REQUIRED ||
                    phase == TaskFlowPhase.SIGNUP_COMPLETE) &&
                raw.optString("taskToken").isBlank()
            ) {
                logSkipOnce(item, "缺少taskToken，跳过")
                return true
            }
            return false
        }

        override fun isUnresolvedWhenSkipped(item: TaskFlowItem): Boolean =
            !isBlacklisted(item) &&
                (mapPhase(item) == TaskFlowPhase.UNSUPPORTED ||
                    item.raw?.optString("taskToken").isNullOrBlank())

        override fun isBlacklisted(item: TaskFlowItem): Boolean {
            val blacklisted = super<TaskFlowAdapter>.isBlacklisted(item)
            if (blacklisted) {
                logSkipOnce(item, "任务在自动跳过列表(黑名单)中，跳过")
            }
            return blacklisted
        }

        override fun signup(item: TaskFlowItem): TaskFlowActionResult {
            val raw = item.raw ?: JSONObject()
            val response = AntMemberRpcCall.gameCenterP2ePlatformTaskSignUp(
                item.id,
                raw.optString("taskToken"),
                extractGameCenterP2eActionChannel(raw),
                extractGameCenterP2eSource(raw)
            )
            val responseObject = JSONObject(response)
            if (!ResChecker.checkRes(TAG, responseObject)) {
                return gameCenterTaskFailureResult(
                    item = item,
                    responseObject = responseObject,
                    rawResponse = response,
                    rpc = "AntMemberRpcCall.gameCenterP2ePlatformTaskSignUp"
                )
            }
            Log.member("游戏中心🎮赚现金任务[${item.title}]#报名完成")
            return TaskFlowActionResult.success(
                refreshAfterAction = true,
                progressChanged = false,
            )
        }

        override fun complete(item: TaskFlowItem): TaskFlowActionResult =
            completeGameCenterP2eTaskWithDuration(item)

        override fun send(item: TaskFlowItem): TaskFlowActionResult =
            completeGameCenterP2eTaskWithDuration(item)

        override fun receive(item: TaskFlowItem): TaskFlowActionResult {
            val raw = item.raw ?: JSONObject()
            if (raw.optString("taskMileStoneId").isNotBlank()) {
                val response = JSONObject(AntMemberRpcCall.receiveGameCenterMilestone(
                    raw, extractGameCenterP2eSource(raw), extractGameCenterP2eOriChInfo(raw),
                ))
                ResChecker.checkRes(TAG, response)
                return TaskFlowActionResult.defer(
                    deferredReason = DeferredReason.STATE_CONFIRMATION,
                    message = "累计奖励领取已请求，回查同一里程碑状态",
                    rpc = "com.alipay.gamecenteruprod.biz.rpc.p2e.receiveTaskMileStoneReward",
                    refreshAfterAction = true,
                )
            }
            val response = AntMemberRpcCall.gameCenterP2eTaskReceive(
                raw,
                extractGameCenterP2eActionChannel(raw),
                extractGameCenterP2eSource(raw),
                extractGameCenterP2eOriChInfo(raw)
            )
            val responseObject = JSONObject(response)
            if (!ResChecker.checkRes(TAG, responseObject)) {
                return gameCenterTaskFailureResult(
                    item = item,
                    responseObject = responseObject,
                    rawResponse = response,
                    rpc = "AntMemberRpcCall.gameCenterP2eTaskReceive"
                )
            }
            val amount = raw.opt("goldCoinAmount")?.toString().orEmpty()
            Log.member("游戏中心🎮赚现金任务[${item.title}]#领取成功" + if (amount.isNotBlank()) "#金币+$amount" else "")
            return TaskFlowActionResult.success(
                refreshAfterAction = true,
                progressChanged = false,
            )
        }

        override fun actionKey(item: TaskFlowItem, action: TaskFlowAction): String {
            return "${action.logName}:${item.id}:${item.status}:${item.type}"
        }

        override fun afterFailure(
            item: TaskFlowItem,
            action: TaskFlowAction,
            result: TaskFlowActionResult,
            decision: TaskFlowDecision
        ) {
            when (decision) {
                TaskFlowDecision.RETRY_LATER -> hasRetryableFailure = true
                TaskFlowDecision.LOG_ONLY -> hasBlockingFailure = true
                TaskFlowDecision.MARK_HANDLED,
                TaskFlowDecision.STOP_TODAY_OR_CURRENT_CHAIN,
                TaskFlowDecision.BLACKLIST -> Unit
            }
        }

        override fun onAllTasksDone(snapshot: TaskFlowSnapshot) {
            logInfo("游戏中心🎮[赚现金任务已处理完成：${snapshot.completedTasks}/${snapshot.totalTasks}]")
        }

        override fun onQueryFailed(response: JSONObject) {
            val msg = response.optString("errorMsg")
                .ifBlank { response.optString("resultView") }
                .ifBlank { response.optString("resultDesc") }
                .ifBlank { response.optString("_rawResponse", response.toString()) }
            Log.error("$TAG.enableGameCenter.p2eTasks", "$flowName[任务查询失败] reason=$msg")
        }

        override fun onUnknownPhase(item: TaskFlowItem, phase: TaskFlowPhase) {
            hasBlockingFailure = true
            Log.error(
                "$TAG.enableGameCenter.p2eTasks",
                "游戏中心🎮赚现金任务[${item.title}]未知状态 taskId=${item.id} status=${item.status} raw=${item.raw}"
            )
        }

        override fun logInfo(message: String) {
            Log.member(message)
        }

        override fun logError(message: String) {
            Log.error(TAG, message)
        }

        private fun completeGameCenterP2eTaskWithDuration(item: TaskFlowItem): TaskFlowActionResult {
            if (isGameCenterP2eAutoTask(item)) return completeGameCenterP2eTask(item)
            val raw = item.raw ?: JSONObject()
            if (raw.optString("taskType") == "LIGHT_TRAN_TASK" && raw.optString("actionType") == "GAME_BROWSE") {
                return completeGameCenterFloatingBallTask(item, raw)
            }
            val decision = GameCenterPlayRpcCall.resolveTaskAction(raw)
            if (decision.action == GameCenterPlayRpcCall.TaskAction.LEGACY_EXTERNAL_REPORT) {
                return runBlocking {
                    NonDurationGameTask.advance(
                        requireNotNull(decision.mappedTask), item.raw,
                        detail = gameCenterTaskActionDetail(item, "gameReport"), logger = Log::member,
                    )
                }
            }
            val contract = decision.contract
                ?: return TaskFlowActionResult.defer(
                    deferredReason = DeferredReason.PREREQUISITE_PENDING,
                    message = decision.reason,
                    rpc = "AntMember.completeGameCenterP2eTaskWithDuration",
                    detail = gameCenterTaskActionDetail(item, "gameEvent"),
                )
            contract.let {
                val ack = GameCenterPlayRpcCall.submitForAck(it)
                val response = ack.response
                    ?: return TaskFlowActionResult.failure(
                        failureType = ack.failureType,
                        message = "时长动作响应无法解析",
                        rpc = "GameCenterPlayRpcCall.submit",
                        raw = ack.raw,
                        detail = gameCenterTaskActionDetail(item, "playDuration"),
                    )
                if (!ack.accepted) {
                    return TaskFlowActionResult.failure(
                        failureType = ack.failureType,
                        code = response.optString("resultCode"),
                        message = response.optString("resultDesc", response.optString("desc", ack.raw)),
                        rpc = "GameCenterPlayRpcCall.submit",
                        raw = ack.raw,
                        detail = gameCenterTaskActionDetail(item, "playDuration"),
                    )
                }
                Log.member("游戏中心🎮赚现金任务[${item.title}]时长上报已接受，等待游戏任务列表确认")
            }
            return TaskFlowActionResult.defer(
                deferredReason = DeferredReason.STATE_CONFIRMATION,
                message = "游戏时长已提交，等待任务进度和金币状态确认",
                rpc = "GameCenterPlayRpcCall.submit",
                detail = gameCenterTaskActionDetail(item, "playDuration"),
                refreshAfterAction = true,
            )
        }

        private fun completeGameCenterFloatingBallTask(item: TaskFlowItem, raw: JSONObject): TaskFlowActionResult {
            val pageSource = extractGameCenterP2eSource(raw)
            val descriptor = GameCenterPlayRpcCall.describeTask(raw)
            var contract = GameCenterPlayRpcCall.P2eFloatingBallContract(
                sceneId = "", taskId = item.id, moduleId = "", guideType = "",
                gameAppId = raw.optString("appId"), gameId = raw.optString("gameId"), source = pageSource,
                gameModuleId = raw.optString("gameModuleId"), trafficDriverId = raw.optString("trafficDriverId"),
                oriChInfo = extractGameCenterP2eOriChInfo(raw), floatingBallTypeList = emptyList(),
                componentChannel = "", componentScene = "", gameVersion = "",
            )
            val consult = GameCenterPlayRpcCall.consultP2eFloatingBall(contract)
            if (!consult.accepted) return TaskFlowActionResult.failure(
                failureType = consult.failureType, message = "游戏浮球查询失败", raw = consult.raw,
                rpc = "GameCenterPlayRpcCall.consultP2eFloatingBall",
            )
            val typeList = consult.response?.optJSONObject("data")?.optJSONArray("floatingBallTypeList")
            val types = typeList?.let { list ->
                (0 until list.length()).mapNotNull { list.optString(it).takeIf { type -> type.isNotBlank() } }
            }.orEmpty()
            val duration = consult.timeSeconds ?: 0
            if (types.isEmpty() || duration <= 0) {
                return TaskFlowActionResult.defer(
                    deferredReason = DeferredReason.STATE_CONFIRMATION, message = "当前浮球没有待完成时长，回查游戏任务",
                    refreshAfterAction = true,
                )
            }
            contract = contract.copy(durationSeconds = duration, floatingBallTypeList = types)
            val durationAck = GameCenterPlayRpcCall.submitP2eDurationForAck(contract, descriptor.source.ifBlank { pageSource })
            if (!durationAck.accepted) return TaskFlowActionResult.failure(
                failureType = durationAck.failureType, message = "P2E游戏时长上报失败", raw = durationAck.raw,
                rpc = "GameCenterPlayRpcCall.submitP2eDurationForAck",
            )
            val completion = GameCenterPlayRpcCall.completeP2eFloatingBall(contract)
            if (!completion.accepted) return TaskFlowActionResult.failure(
                failureType = completion.failureType, message = "P2E浮球完成失败", raw = completion.raw,
                rpc = "GameCenterPlayRpcCall.completeP2eFloatingBall",
            )
            return TaskFlowActionResult.defer(
                deferredReason = DeferredReason.STATE_CONFIRMATION, message = "浮球完成已提交，回查游戏任务后领取金币",
                refreshAfterAction = true,
            )
        }

        private fun completeGameCenterP2eTask(item: TaskFlowItem): TaskFlowActionResult {
            val raw = item.raw ?: JSONObject()
            val response = AntMemberRpcCall.gameCenterP2ePlatformTaskComplete(
                item.id,
                raw.optString("taskToken"),
                extractGameCenterP2eActionChannel(raw),
                extractGameCenterP2eSource(raw)
            )
            val responseObject = JSONObject(response)
            if (!ResChecker.checkRes(TAG, responseObject)) {
                return gameCenterTaskFailureResult(
                    item = item,
                    responseObject = responseObject,
                    rawResponse = response,
                    rpc = "AntMemberRpcCall.gameCenterP2ePlatformTaskComplete"
                )
            }
            Log.member("游戏中心🎮赚现金任务[${item.title}]#完成请求已受理，等待列表确认")
            return TaskFlowActionResult.success(
                refreshAfterAction = true,
                progressChanged = false,
            )
        }

        private fun appendGameCenterP2eTasks(items: MutableList<TaskFlowItem>, taskList: JSONArray) {
            for (i in 0 until taskList.length()) {
                val task = taskList.optJSONObject(i) ?: continue
                val taskId = task.optString("taskId")
                if (taskId.isBlank()) {
                    continue
                }
                val title = task.optString("title")
                    .ifBlank { task.optString("subTitle") }
                    .ifBlank { taskId }
                val taskType = task.optString("taskType")
                val actionType = task.optString("actionType")
                items.add(
                    TaskFlowItem(
                        id = taskId,
                        title = title,
                        status = task.optString("taskStatus"),
                        type = taskType,
                        actionType = actionType,
                        blacklistKeys = listOf(taskId, taskType).filter { it.isNotBlank() },
                        raw = task,
                        progress = "goldCoinAmount=${task.optInt("goldCoinAmount", 0)}"
                    )
                )
            }
        }

        private fun queryGameCenterP2eSnapshot(
            source: String,
            queryHomePage: Boolean = false,
        ): GameCenterP2eQuerySnapshot {
            return try {
                val raw = if (queryHomePage) {
                    AntMemberRpcCall.queryGameCenterP2eHomePage(source)
                } else {
                    AntMemberRpcCall.queryGameCenterP2eTaskList(source, sessionId)
                }
                val response = JSONObject(raw)
                GameCenterP2eQuerySnapshot(
                    source = source,
                    success = ResChecker.checkRes(TAG, response),
                    rawResponse = raw,
                    responseObject = response
                )
            } catch (t: Throwable) {
                GameCenterP2eQuerySnapshot(
                    source = source,
                    success = false,
                    rawResponse = "查询异常:${t.message}",
                    responseObject = JSONObject().put("resultView", "查询异常:${t.message}")
                )
            }
        }

        private fun mergeGameCenterP2eTasksFromSnapshot(
            snapshot: GameCenterP2eQuerySnapshot,
            mergedTaskMap: LinkedHashMap<String, JSONObject>,
            exposedTaskMap: LinkedHashMap<String, JSONObject>
        ) {
            val data = snapshot.responseObject.optJSONObject("data") ?: return
            val exposedTaskList = data.optJSONObject("exposedTaskModuleVO")
                ?.optJSONArray("exposedTaskList")
            mergeGameCenterP2eTaskList(
                mergedTaskMap,
                exposedTaskMap,
                exposedTaskList,
                container = "exposedTaskModule",
                source = snapshot.source
            )
            val milestones = data.optJSONObject("taskMileStoneRewardVO")?.optJSONArray("taskMileStoneList") ?: JSONArray()
            for (index in 0 until milestones.length()) {
                val milestone = milestones.optJSONObject(index) ?: continue
                val id = milestone.optString("taskMileStoneId")
                if (id.isBlank()) continue
                val normalized = JSONObject(milestone.toString()).put("taskId", id)
                    .put("taskStatus", milestone.optString("status"))
                    .put("title", "累计任务奖励 ${milestone.optInt("mileStoneNum")}")
                    .put("_gcSource", snapshot.source).put("_gcOriChInfo", snapshot.source)
                mergedTaskMap[id] = normalized
            }
            val platformTaskModule = data.optJSONObject("platformGameTaskModule") ?: return
            for (container in listOf("platformTaskList", "taskList", "gameTaskList")) {
                val tasks = platformTaskModule.optJSONArray(container) ?: continue
                for (index in 0 until tasks.length()) {
                    tasks.optJSONObject(index)?.put("gameModuleId", platformTaskModule.optString("gameModuleId"))
                }
            }
            mergeGameCenterP2eTaskList(
                mergedTaskMap,
                exposedTaskMap,
                platformTaskModule.optJSONArray("platformTaskList"),
                container = "platformTaskList",
                source = snapshot.source
            )
            mergeGameCenterP2eTaskList(
                mergedTaskMap,
                exposedTaskMap,
                platformTaskModule.optJSONArray("taskList"),
                container = "taskList",
                source = snapshot.source
            )
            mergeGameCenterP2eTaskList(
                mergedTaskMap,
                exposedTaskMap,
                platformTaskModule.optJSONArray("gameTaskList"),
                container = "gameTaskList",
                source = snapshot.source
            )
        }

        private fun mergeGameCenterP2eTaskList(
            mergedTaskMap: LinkedHashMap<String, JSONObject>,
            exposedTaskMap: LinkedHashMap<String, JSONObject>,
            taskList: JSONArray?,
            container: String,
            source: String
        ) {
            if (taskList == null) {
                return
            }
            for (i in 0 until taskList.length()) {
                val task = taskList.optJSONObject(i) ?: continue
                val taskId = task.optString("taskId")
                if (taskId.isBlank()) {
                    continue
                }
                val normalizedTask = JSONObject(task.toString()).apply {
                    put("_gcContainer", container)
                    put("_gcActionChannel", if (container == "exposedTaskModule") "exposedTaskModule" else "taskList")
                    put("_gcSource", source)
                    put("_gcOriChInfo", source)
                }
                if (container == "exposedTaskModule") {
                    val currentExposed = exposedTaskMap[taskId]
                    if (currentExposed == null || shouldReplaceGameCenterP2eTask(currentExposed, normalizedTask)) {
                        exposedTaskMap[taskId] = normalizedTask
                    }
                }
                val currentTask = mergedTaskMap[taskId]
                if (currentTask == null || shouldReplaceGameCenterP2eTask(currentTask, normalizedTask)) {
                    mergedTaskMap[taskId] = normalizedTask
                }
            }
        }

        private fun shouldReplaceGameCenterP2eTask(currentTask: JSONObject, candidateTask: JSONObject): Boolean {
            val candidateCompleteness = scoreGameCenterP2eTaskCompleteness(candidateTask)
            val currentCompleteness = scoreGameCenterP2eTaskCompleteness(currentTask)
            if (candidateCompleteness != currentCompleteness) {
                return candidateCompleteness > currentCompleteness
            }
            val candidateScore = scoreGameCenterP2eTask(candidateTask)
            val currentScore = scoreGameCenterP2eTask(currentTask)
            if (candidateScore != currentScore) {
                return candidateScore > currentScore
            }
            return scoreGameCenterP2eTaskSource(candidateTask) > scoreGameCenterP2eTaskSource(currentTask)
        }

        private fun scoreGameCenterP2eTaskCompleteness(task: JSONObject): Int {
            var score = 0
            if (task.optString("taskToken").isNotBlank()) score += 8
            if (task.optString("actionType").isNotBlank()) score += 4
            if (task.optString("taskType").isNotBlank()) score += 3
            if (task.optString("taskStatus").isNotBlank()) score += 3
            if (task.optString("title").isNotBlank() || task.optString("subTitle").isNotBlank()) score += 2
            if (gameCenterPlayContract(task) != null) score += 8
            return score
        }

        private fun scoreGameCenterP2eTask(task: JSONObject): Int {
            val container = task.optString("_gcContainer")
            val rewardReady = isGameCenterP2eRewardTask(task)
            return when {
                rewardReady && container in setOf("taskList", "platformTaskList") -> 500
                rewardReady && container == "exposedTaskModule" -> 400
                rewardReady -> 350
                container == "exposedTaskModule" -> 300
                container in setOf("taskList", "platformTaskList") -> 200
                else -> 100
            }
        }

        private fun scoreGameCenterP2eTaskSource(task: JSONObject): Int {
            return when (task.optString("_gcSource")) {
                AntMemberRpcCall.GAME_CENTER_P2E_SOURCE -> 2
                AntMemberRpcCall.GAME_CENTER_SOURCE -> 1
                else -> 0
            }
        }

        private fun isGameCenterP2eRewardTask(task: JSONObject): Boolean {
            val status = task.optString("taskStatus").uppercase(Locale.ROOT)
            return status in setOf("COMPLETED", "COMPLETE", "FINISHED")
        }

        private fun reportGameCenterP2eExposedTasks(taskList: JSONArray) {
            if (taskList.length() == 0) {
                return
            }
            runCatching {
                val response = AntMemberRpcCall.reportGameCenterP2eExposedTasks(taskList)
                val responseObject = JSONObject(response)
                if (!ResChecker.checkRes(TAG, responseObject)) {
                    Log.member("游戏中心🎮赚现金任务曝光上报失败:${buildGameCenterRpcMessage(responseObject, response)}")
                }
            }.onFailure {
                Log.printStackTrace(TAG, "reportGameCenterP2eExposedTasks err:", it)
            }
        }

        private fun isGameCenterP2eAutoTask(item: TaskFlowItem): Boolean {
            val raw = item.raw ?: return false
            return raw.optString("taskType").equals("PLATFORM_TRAN_TASK", ignoreCase = true) &&
                raw.optString("actionType").uppercase(Locale.ROOT) in setOf(
                    "VIEW_TASK", "SUBSCRIBE_TASK", "ADD_DESKTOP_TASK", "SWITCH_APP_TASK", "SET_HEAD_TASK",
                )
        }

        private fun isGameCenterP2eCompletableTask(item: TaskFlowItem): Boolean {
            if (isGameCenterP2eAutoTask(item)) return true
            val raw = item.raw ?: return false
            if (raw.optString("taskType") == "LIGHT_TRAN_TASK" && raw.optString("actionType") == "GAME_BROWSE") return true
            if (!raw.optString("taskType").equals("GAME_TRAN_TASK", ignoreCase = true)) {
                return false
            }
            return GameCenterPlayRpcCall.resolveTaskAction(raw).action in setOf(
                GameCenterPlayRpcCall.TaskAction.DURATION_ONLY,
                GameCenterPlayRpcCall.TaskAction.LEGACY_EXTERNAL_REPORT,
            )
        }

        private fun handleUnsupportedP2eTask(item: TaskFlowItem) {
            hasBlockingFailure = true
            val raw = item.raw ?: JSONObject()
            val reason = when {
                raw.optString("taskType").equals("GAME_TRAN_TASK", ignoreCase = true) -> {
                    "等待游戏业务状态推进：${GameCenterPlayRpcCall.resolveTaskAction(raw).reason}"
                }
                raw.optString("actionType").equals("LIGHT_AD_TASK", ignoreCase = true) -> {
                    "P2E广告完成分支尚未接入，保留任务并处理已生成奖励"
                }
                else -> {
                    val taskType = raw.optString("taskType").ifBlank { "UNKNOWN" }
                    val actionType = raw.optString("actionType").ifBlank { "UNKNOWN" }
                    "任务类型尚未接入当前适配器，保留待办:taskType=$taskType actionType=$actionType"
                }
            }
            logSkipOnce(item, reason)
        }

        private fun logSkipOnce(item: TaskFlowItem, reason: String) {
            val key = "$reason|${item.id}"
            if (loggedSkipKeys.add(key)) {
                Log.member("游戏中心🎮赚现金任务[${item.title}]#$reason")
            }
        }

        private fun buildGameCenterP2eCombinedRaw(
            homeSnapshot: GameCenterP2eQuerySnapshot,
            taskSnapshot: GameCenterP2eQuerySnapshot
        ): String {
            return "homeSource=${homeSnapshot.source}:${homeSnapshot.rawResponse} " +
                "taskSource=${taskSnapshot.source}:${taskSnapshot.rawResponse}"
        }

        private fun buildGameCenterP2eQueryFailureMessage(
            homeSnapshot: GameCenterP2eQuerySnapshot,
            taskSnapshot: GameCenterP2eQuerySnapshot
        ): String {
            return buildString {
                append("首页源失败:")
                append(extractGameCenterP2eQueryMessage(homeSnapshot))
                append(" | 任务页源失败:")
                append(extractGameCenterP2eQueryMessage(taskSnapshot))
            }
        }

        private fun buildGameCenterP2ePartialFailureMessage(
            homeSnapshot: GameCenterP2eQuerySnapshot,
            taskSnapshot: GameCenterP2eQuerySnapshot
        ): String {
            return when {
                homeSnapshot.success && !taskSnapshot.success ->
                    "首页源成功，任务页源失败:${extractGameCenterP2eQueryMessage(taskSnapshot)}"
                !homeSnapshot.success && taskSnapshot.success ->
                    "首页源失败:${extractGameCenterP2eQueryMessage(homeSnapshot)}，任务页源成功"
                else -> buildGameCenterP2eQueryFailureMessage(homeSnapshot, taskSnapshot)
            }
        }

        private fun extractGameCenterP2eQueryMessage(snapshot: GameCenterP2eQuerySnapshot): String {
            val response = snapshot.responseObject
            return sequenceOf(
                response.optString("errorMsg"),
                response.optString("errorMessage"),
                response.optString("resultView"),
                response.optString("resultDesc"),
                response.optString("memo"),
                response.optString("desc")
            ).firstOrNull { it.isNotBlank() } ?: snapshot.rawResponse
        }
    }

    private fun extractGameCenterP2eActionChannel(task: JSONObject): String {
        return task.optString("_gcActionChannel").ifBlank { "taskList" }
    }

    private fun extractGameCenterP2eSource(task: JSONObject): String {
        return task.optString("_gcSource").ifBlank { AntMemberRpcCall.GAME_CENTER_P2E_SOURCE }
    }

    private fun extractGameCenterP2eOriChInfo(task: JSONObject): String {
        return task.optString("_gcOriChInfo").ifBlank { extractGameCenterP2eSource(task) }
    }

    private fun gameCenterTaskFailureResult(
        item: TaskFlowItem,
        responseObject: JSONObject,
        rawResponse: String,
        rpc: String
    ): TaskFlowActionResult {
        return memberDomainTaskFailureResult(
            item = item,
            responseObject = responseObject,
            rawResponse = rawResponse,
            rpc = rpc,
            detail = gameCenterTaskActionDetail(item, rpc.substringAfterLast('.'))
        )
    }

    private fun gameCenterTaskActionDetail(item: TaskFlowItem, action: String): String {
        val task = item.raw ?: JSONObject()
        return "taskId=${item.id.ifBlank { "UNKNOWN" }} taskName=${item.title.ifBlank { "UNKNOWN" }} " +
            "subTitle=${task.optString("subTitle").ifBlank { "UNKNOWN" }} " +
            "status=${item.status.ifBlank { "UNKNOWN" }} action=$action " +
            "gameId=${task.optString("gameId").ifBlank { "UNKNOWN" }} " +
            "appId=${task.optString("appId").ifBlank { "UNKNOWN" }} " +
            "buttonText=${task.optString("buttonText").ifBlank { "UNKNOWN" }} " +
            "needSignUp=${task.optBoolean("needSignUp", false)} pointAmount=${task.optInt("pointAmount", 0)} " +
            "gcContainer=${task.optString("_gcContainer").ifBlank { "UNKNOWN" }} " +
            "gcActionChannel=${extractGameCenterP2eActionChannel(task)} " +
            "gcSource=${extractGameCenterP2eSource(task)} " +
            "gcOriChInfo=${extractGameCenterP2eOriChInfo(task)}"
    }

    private suspend fun doGameCenterP2eSignIn(): DailyTaskProcessResult {
        val resp = AntMemberRpcCall.queryGameCenterP2eHomePage(AntMemberRpcCall.GAME_CENTER_SOURCE)
        val root = JSONObject(resp)
        if (!ResChecker.checkRes(TAG, root)) {
            return logGameCenterP2eFailure("赚现金签到查询", root, resp)
        }

        val data = root.optJSONObject("data")
        val signUpModule = data?.optJSONObject("signUpModuleVO")
        if (signUpModule == null) {
            val riskMsg = data?.optString("hitRiskControlMsg").orEmpty()
            if (data?.optBoolean("hitRiskControl", false) == true || riskMsg.isNotBlank()) {
                Log.member("游戏中心🎮[赚现金签到业务受限，跳过]#$riskMsg")
            } else {
                Log.member("游戏中心🎮[赚现金暂无签到模块]")
            }
            return DailyTaskProcessResult.HANDLED
        }

        val todayRecord = findGameCenterP2eTodaySignRecord(signUpModule)
        val todayStatus = todayRecord?.optString("signUpStatus").orEmpty()
        if ("SIGNED".equals(todayStatus, ignoreCase = true)) {
            val amount = todayRecord?.optString("todayGoldCoinAmount").orEmpty()
            Log.member("游戏中心🎮[赚现金今日已签到]" + if (amount.isNotBlank()) "#金币+$amount" else "")
            return DailyTaskProcessResult.HANDLED
        }

        val date = signUpModule.optString("date")
        val index = signUpModule.optInt("index", 0)
        val signSequenceId = signUpModule.optString("signSequenceId")
        if (date.isBlank() || signSequenceId.isBlank()) {
            Log.error(
                "$TAG.enableGameCenter.p2eSignIn",
                "游戏中心🎮[赚现金签到配置缺失]#date=$date index=$index signSequenceId=$signSequenceId"
            )
            return DailyTaskProcessResult.UNKNOWN_FAILURE
        }

        val signResp = AntMemberRpcCall.gameCenterP2eSignIn(
            date,
            index,
            signSequenceId,
            AntMemberRpcCall.GAME_CENTER_SOURCE
        )
        val signObject = JSONObject(signResp)
        if (!ResChecker.checkRes(TAG, signObject)) {
            return logGameCenterP2eFailure("赚现金签到", signObject, signResp)
        }

        val signedRecord = findGameCenterP2eTodaySignRecord(
            signObject.optJSONObject("data")?.optJSONObject("signUpPopupModuleVO")
        )
        val signedStatus = signedRecord?.optString("signUpStatus").orEmpty()
        val amount = signedRecord?.optString("todayGoldCoinAmount").orEmpty()
        if ("SIGNED".equals(signedStatus, ignoreCase = true) || signObject.optBoolean("success", false)) {
            Log.member("游戏中心🎮[赚现金签到成功]" + if (amount.isNotBlank()) "#金币+$amount" else "")
            return DailyTaskProcessResult.HANDLED
        } else {
            Log.error(
                "$TAG.enableGameCenter.p2eSignIn",
                "游戏中心🎮[赚现金签到状态未确认]#" + buildGameCenterRpcMessage(signObject, signResp)
            )
            return DailyTaskProcessResult.UNKNOWN_FAILURE
        }
    }

    private fun doGameCenterP2eDrawGold(): DailyTaskProcessResult {
        val homeResponse = AntMemberRpcCall.queryGameCenterP2eHomePage(AntMemberRpcCall.GAME_CENTER_SOURCE)
        val home = JSONObject(homeResponse)
        if (!ResChecker.checkRes(TAG, home)) {
            return logGameCenterP2eFailure("赚现金抽金币查询", home, homeResponse)
        }

        val data = home.optJSONObject("data")
        if (data == null) {
            Log.member("游戏中心🎮[赚现金暂无抽金币模块]")
            return DailyTaskProcessResult.HANDLED
        }
        if (data.optBoolean("hitRiskControl", false) || data.optBoolean("hitFourControlLimit", false)) {
            Log.member("游戏中心🎮[赚现金抽金币业务受限，跳过]")
            return DailyTaskProcessResult.HANDLED
        }

        val drawModule = data.optJSONObject("drawGoldCoinModuleVO")
        if (drawModule == null) {
            Log.member("游戏中心🎮[赚现金暂无抽金币模块]")
            return DailyTaskProcessResult.HANDLED
        }
        when (drawModule.optString("status")) {
            "DRAWN" -> {
                Log.member("游戏中心🎮[赚现金抽金币已完成]#奖励次日解锁领取")
                return DailyTaskProcessResult.HANDLED
            }
            "NOT_DRAWN", "FULFILL_FAILED" -> Unit
            else -> {
                Log.error(
                    "$TAG.enableGameCenter.p2eDrawGold",
                    "游戏中心🎮[赚现金抽金币状态未识别]#status=${drawModule.optString("status")}"
                )
                return DailyTaskProcessResult.UNKNOWN_FAILURE
            }
        }

        val drawResponse = AntMemberRpcCall.drawGameCenterP2eGold()
        val drawResult = JSONObject(drawResponse)
        if (!ResChecker.checkRes(TAG, drawResult)) {
            return logGameCenterP2eFailure("赚现金抽金币", drawResult, drawResponse)
        }

        val refreshedResponse = AntMemberRpcCall.queryGameCenterP2eHomePage(AntMemberRpcCall.GAME_CENTER_SOURCE)
        val refreshedHome = JSONObject(refreshedResponse)
        if (!ResChecker.checkRes(TAG, refreshedHome)) {
            return logGameCenterP2eFailure("赚现金抽金币回查", refreshedHome, refreshedResponse)
        }
        val refreshedStatus = refreshedHome.optJSONObject("data")
            ?.optJSONObject("drawGoldCoinModuleVO")
            ?.optString("status")
            .orEmpty()
        if (refreshedStatus == "DRAWN") {
            val popupTitle = drawResult.optJSONObject("data")
                ?.optJSONObject("popupInfoVO")
                ?.optString("mainTitle")
                .orEmpty()
            Log.member("游戏中心🎮[赚现金抽金币成功]${if (popupTitle.isBlank()) "#奖励次日解锁领取" else "#$popupTitle"}")
            return DailyTaskProcessResult.HANDLED
        }

        Log.error(
            "$TAG.enableGameCenter.p2eDrawGold",
            "游戏中心🎮[赚现金抽金币回查未确认]#status=$refreshedStatus"
        )
        return DailyTaskProcessResult.UNKNOWN_FAILURE
    }

    private fun doGameCenterP2eCashExchange(): DailyTaskProcessResult {
        val homeResponse = AntMemberRpcCall.queryGameCenterP2eHomePage(AntMemberRpcCall.GAME_CENTER_SOURCE)
        val home = JSONObject(homeResponse)
        if (!ResChecker.checkRes(TAG, home)) {
            return logGameCenterP2eFailure("赚现金提现前状态查询", home, homeResponse)
        }
        val homeData = home.optJSONObject("data") ?: return DailyTaskProcessResult.HANDLED
        if (homeData.optBoolean("hitRiskControl", false) || homeData.optBoolean("hitFourControlLimit", false)) {
            Log.member("游戏中心🎮[赚现金提现]#服务端业务受限，本轮不提交")
            return DailyTaskProcessResult.HANDLED
        }

        val prizePageResponse = AntMemberRpcCall.queryGameCenterP2eGoldExchangePrizePage()
        val prizePage = JSONObject(prizePageResponse)
        if (!ResChecker.checkRes(TAG, prizePage)) {
            return logGameCenterP2eFailure("赚现金提现档位查询", prizePage, prizePageResponse)
        }
        val prizePageData = prizePage.optJSONObject("data") ?: run {
            Log.member("游戏中心🎮[赚现金提现]#服务端未返回现金档位")
            return DailyTaskProcessResult.HANDLED
        }
        val cashModule = prizePageData.optJSONObject("cashExchangeModule") ?: run {
            Log.member("游戏中心🎮[赚现金提现]#当前无现金兑换模块")
            return DailyTaskProcessResult.HANDLED
        }
        val targetPrize = findSelectedFixedTenYuanPrize(cashModule.optJSONArray("prizes")) ?: run {
            Log.member("游戏中心🎮[赚现金提现]#当前无服务端选中的固定10元档")
            return DailyTaskProcessResult.HANDLED
        }
        if (targetPrize.optString("prizeStatus") != "CAN_EXG") {
            Log.member("游戏中心🎮[赚现金提现]#固定10元档当前状态=${targetPrize.optString("prizeStatus").ifBlank { "UNKNOWN" }}")
            return DailyTaskProcessResult.HANDLED
        }

        val goldBalance = prizePageData.optJSONObject("assetModuleVO")?.optString("goldAmount")?.toLongOrNull()
        val consumeGold = targetPrize.optJSONObject("confirmPopup")?.optString("consumeGold")?.toLongOrNull()
        if (goldBalance == null || consumeGold == null) {
            Log.error("$TAG.enableGameCenter.p2eCashExchange", "游戏中心🎮[赚现金提现]#服务端余额或门槛字段缺失")
            return DailyTaskProcessResult.UNKNOWN_FAILURE
        }
        if (goldBalance < consumeGold) {
            Log.member("游戏中心🎮[赚现金提现]#金币未达门槛[当前=$goldBalance,需要=$consumeGold]")
            return DailyTaskProcessResult.HANDLED
        }
        if (!hasGoldExchangeSubmitContract(targetPrize)) {
            Log.error("$TAG.enableGameCenter.p2eCashExchange", "游戏中心🎮[赚现金提现]#服务端缺少动态提交参数")
            return DailyTaskProcessResult.UNKNOWN_FAILURE
        }

        val exchangeResponse = AntMemberRpcCall.doGameCenterP2eGoldExchangePrize(targetPrize)
        val exchangeResult = JSONObject(exchangeResponse)
        val exchangeData = exchangeResult.optJSONObject("data")
        if (!ResChecker.checkRes(TAG, exchangeResult) || exchangeData?.optString("exgStatus") != "SUCCESS") {
            if (exchangeResult.optBoolean("retryable", false)) {
                Log.error("$TAG.enableGameCenter.p2eCashExchange", "游戏中心🎮[赚现金提现]#可重试失败:${buildGameCenterRpcMessage(exchangeResult, exchangeResponse)}")
                return DailyTaskProcessResult.RETRYABLE_FAILURE
            }
            Log.error("$TAG.enableGameCenter.p2eCashExchange", "游戏中心🎮[赚现金提现]#提交未确认:${buildGameCenterRpcMessage(exchangeResult, exchangeResponse)}")
            return DailyTaskProcessResult.UNKNOWN_FAILURE
        }

        val amount = exchangeData.optString("amount").ifBlank { targetPrize.optString("prizeAmount") }
        val arrivalTips = exchangeData.optString("arrivalTips")
        Log.member("游戏中心🎮[赚现金提现提交成功]#${amount}元${if (arrivalTips.isBlank()) "" else "#$arrivalTips"}")

        val refreshedResponse = AntMemberRpcCall.queryGameCenterP2eGoldExchangePrizePage()
        val refreshedPage = JSONObject(refreshedResponse)
        if (!ResChecker.checkRes(TAG, refreshedPage)) {
            Log.error("$TAG.enableGameCenter.p2eCashExchange", "游戏中心🎮[赚现金提现]#提交成功但回查失败")
            return DailyTaskProcessResult.UNKNOWN_FAILURE
        }
        if (isGoldExchangeConfirmed(prizePageData, refreshedPage.optJSONObject("data"), targetPrize)) {
            Log.member("游戏中心🎮[赚现金提现已确认]#${amount}元")
            return DailyTaskProcessResult.HANDLED
        }

        Log.error("$TAG.enableGameCenter.p2eCashExchange", "游戏中心🎮[赚现金提现]#提交成功但回查未确认，本轮不重复提交")
        return DailyTaskProcessResult.UNKNOWN_FAILURE
    }

    private fun findSelectedFixedTenYuanPrize(prizes: JSONArray?): JSONObject? {
        if (prizes == null) return null
        for (i in 0 until prizes.length()) {
            val prize = prizes.optJSONObject(i) ?: continue
            if (prize.optBoolean("selected", false) &&
                prize.optString("withdrawalTierType") == "FIXED_TIER" &&
                prize.optString("prizeUnit") == "元" &&
                prize.optString("prizeAmount").toDoubleOrNull() == 10.0
            ) {
                return prize
            }
        }
        return null
    }

    private fun hasGoldExchangeSubmitContract(prize: JSONObject): Boolean =
        listOf("outBizNo", "prizeConfigId", "sendSign", "sendSignNew", "withdrawalTierType")
            .all { prize.optString(it).isNotBlank() }

    private fun isGoldExchangeConfirmed(
        previousPageData: JSONObject,
        refreshedPageData: JSONObject?,
        targetPrize: JSONObject,
    ): Boolean {
        if (refreshedPageData == null) return false
        val targetPrizeConfigId = targetPrize.optString("prizeConfigId")
        val refreshedPrizes = refreshedPageData.optJSONObject("cashExchangeModule")?.optJSONArray("prizes")
        val refreshedPrize =
            (0 until (refreshedPrizes?.length() ?: 0))
                .mapNotNull { refreshedPrizes?.optJSONObject(it) }
                .firstOrNull { it.optString("prizeConfigId") == targetPrizeConfigId }
        if (refreshedPrize == null || refreshedPrize.optString("prizeStatus") != "CAN_EXG") {
            return true
        }
        val previousBalance = previousPageData.optJSONObject("assetModuleVO")?.optString("goldAmount")?.toLongOrNull()
        val refreshedBalance = refreshedPageData.optJSONObject("assetModuleVO")?.optString("goldAmount")?.toLongOrNull()
        return previousBalance != null && refreshedBalance != null && refreshedBalance < previousBalance
    }

    private fun findGameCenterP2eTodaySignRecord(signUpModule: JSONObject?): JSONObject? {
        if (signUpModule == null) {
            return null
        }
        val signDate = signUpModule.optString("date")
        val records = signUpModule.optJSONArray("signRecordVOList") ?: return null
        var dateMatchedRecord: JSONObject? = null
        for (i in 0 until records.length()) {
            val record = records.optJSONObject(i) ?: continue
            if (record.optBoolean("isToday", false)) {
                return record
            }
            if (signDate.isNotBlank() && signDate == record.optString("signDate")) {
                dateMatchedRecord = record
            }
        }
        return dateMatchedRecord
    }

    private fun logGameCenterP2eFailure(
        scene: String,
        response: JSONObject,
        rawResponse: String
    ): DailyTaskProcessResult {
        val message = buildGameCenterRpcMessage(response, rawResponse)
        return when {
            isGameCenterBusinessLimited(response, message) -> {
                Log.member("游戏中心🎮[$scene]#业务受限，本轮跳过:$message")
                DailyTaskProcessResult.HANDLED
            }

            isGameCenterDuplicateOrAlreadyDone(message) -> {
                Log.member("游戏中心🎮[$scene]#已处理过，跳过重复处理:$message")
                DailyTaskProcessResult.HANDLED
            }

            !response.optBoolean("retryable", true) -> {
                Log.error("$TAG.enableGameCenter.p2e", "游戏中心🎮[$scene]#非重试失败:$message")
                DailyTaskProcessResult.UNKNOWN_FAILURE
            }

            else -> {
                Log.error("$TAG.enableGameCenter.p2e", "游戏中心🎮[$scene]#失败:$message")
                DailyTaskProcessResult.RETRYABLE_FAILURE
            }
        }
    }

    private fun buildGameCenterRpcMessage(response: JSONObject, rawResponse: String): String {
        return sequenceOf(
            response.optString("errorMsg"),
            response.optString("errorMessage"),
            response.optString("resultView"),
            response.optString("resultDesc"),
            response.optString("memo"),
            response.optString("desc")
        ).firstOrNull { it.isNotBlank() } ?: rawResponse
    }

    private fun isGameCenterBusinessLimited(response: JSONObject, message: String): Boolean {
        val errorCode = response.optString("errorCode", response.optString("resultCode"))
        return errorCode.equals("PROMO_RISK_ERROR", ignoreCase = true) ||
            message.contains("不在活动邀请范围") ||
            message.contains("风险") ||
            message.contains("风控") ||
            message.contains("受限")
    }

    private fun isGameCenterDuplicateOrAlreadyDone(message: String): Boolean {
        return message.contains("已签到") ||
            message.contains("已领取") ||
            message.contains("重复") ||
            message.contains("already", ignoreCase = true)
    }

    internal fun beanSignIn() {
        try {
            if (hasFlagToday(StatusFlags.FLAG_ANTMEMBER_BEAN_SIGN_DONE)) {
                Log.member("安心豆🫘[今日已处理，跳过]")
                return
            }

            try {
                val signInProcessStr = AntMemberRpcCall.querySignInProcess("AP16242232", "INS_BLUE_BEAN_SIGN")

                var jo = JSONObject(signInProcessStr)
                if (!ResChecker.checkRes(TAG, jo)) {
                    Log.member(jo.toString())
                    return
                }

                val signInResult = jo.optJSONObject("result")
                if (signInResult == null) {
                    Log.error(TAG, "安心豆🫘[签到查询缺少result]#$signInProcessStr")
                    return
                }
                var signInHandled = !signInResult.optBoolean("canPush", false)
                if (signInResult.optBoolean("canPush") == true) {
                    val signInTriggerStr = AntMemberRpcCall.signInTrigger("AP16242232", "INS_BLUE_BEAN_SIGN")

                    jo = JSONObject(signInTriggerStr)
                    if (ResChecker.checkRes(TAG, jo)) {
                        val prizeName = extractBeanSignInPrizeName(jo)
                        if (prizeName.isBlank()) {
                            Log.member("安心豆🫘[签到成功]")
                        } else {
                            Log.member("安心豆🫘[$prizeName]")
                        }
                        signInHandled = true
                    } else {
                        Log.member(jo.toString())
                    }
                }
                val guardianAwardResult = collectGuardianBeanAward()
                val taskCenterResult = processBeanTaskCenter()
                if (signInHandled &&
                    guardianAwardResult == DailyTaskProcessResult.HANDLED &&
                    taskCenterResult == DailyTaskProcessResult.HANDLED
                ) {
                    setFlagToday(StatusFlags.FLAG_ANTMEMBER_BEAN_SIGN_DONE)
                }
            } catch (e: NullPointerException) {
                Log.printStackTrace(TAG, "安心豆🫘[RPC桥接失败]#可能是RpcBridge未初始化", e)
            }
        } catch (t: Throwable) {
            Log.printStackTrace(TAG, "beanSignIn err:", t)
        }
    }

    internal fun beanDrawPrize() {
        try {
            if (hasFlagToday(StatusFlags.FLAG_ANTMEMBER_BEAN_DRAW_PRIZE_DONE)) {
                Log.member("安心豆🎰[今日已处理，跳过]")
                return
            }

            try {
                val consultStr = AntMemberRpcCall.beanCampConsult(BEAN_DRAW_PLAN_ID)
                var jo = JSONObject(consultStr)
                if (!ResChecker.checkRes(TAG, jo)) {
                    Log.member(jo.toString())
                    return
                }

                val consultResult = jo.optJSONObject("result")
                if (consultResult == null) {
                    Log.error(TAG, "安心豆🎰[抽奖咨询缺少result]#$consultStr")
                    return
                }

                val campId = consultResult.optString("campId")
                if (!consultResult.optBoolean("consultResult", false) || campId.isBlank()) {
                    Log.member("安心豆🎰[暂无可参与抽奖]")
                    setFlagToday(StatusFlags.FLAG_ANTMEMBER_BEAN_DRAW_PRIZE_DONE)
                    return
                }

                val drawStr = AntMemberRpcCall.beanTriggerDrawPrize(campId, BEAN_DRAW_PLAN_ID, System.currentTimeMillis())
                jo = JSONObject(drawStr)
                if (ResChecker.checkRes(TAG, jo)) {
                    val drawResult = jo.optJSONObject("result")
                    val prizeAmount = drawResult?.optString("prizeAmount") ?: ""
                    if (drawResult?.optBoolean("triggerResult", false) == true && prizeAmount.isNotBlank()) {
                        Log.member("安心豆🎰[抽奖获得${prizeAmount}元]")
                    } else {
                        Log.member("安心豆🎰[抽奖未中奖]")
                    }
                    setFlagToday(StatusFlags.FLAG_ANTMEMBER_BEAN_DRAW_PRIZE_DONE)
                } else {
                    Log.member(jo.toString())
                }
            } catch (e: NullPointerException) {
                Log.printStackTrace(TAG, "安心豆🎰[RPC桥接失败]#可能是RpcBridge未初始化", e)
            }
        } catch (t: Throwable) {
            Log.printStackTrace(TAG, "beanDrawPrize err:", t)
        }
    }

    private fun extractBeanSignInPrizeName(responseObject: JSONObject): String {
        val prizeList = responseObject.optJSONObject("result")?.optJSONArray("prizeSendOrderDTOList") ?: return ""
        for (i in 0 until prizeList.length()) {
            val prizeName = prizeList.optJSONObject(i)?.optString("prizeName").orEmpty()
            if (prizeName.isNotBlank()) {
                return prizeName
            }
        }
        return ""
    }

    private fun collectGuardianBeanAward(): DailyTaskProcessResult {
        try {
            val awardsResponse = AntMemberRpcCall.queryGuardianGradeAwards()
            val awardsObject = JSONObject(awardsResponse)
            if (!ResChecker.checkRes(TAG, awardsObject)) {
                Log.member("安心豆🫘[守护者奖励查询失败]#$awardsResponse")
                return DailyTaskProcessResult.UNKNOWN_FAILURE
            }
            if (awardsObject.optJSONObject("result") == null) {
                Log.error("$TAG.collectGuardianBeanAward", "安心豆🫘[守护者奖励查询缺少result]#$awardsResponse")
                return DailyTaskProcessResult.UNKNOWN_FAILURE
            }
            val award = findAvailableGuardianBeanAward(awardsObject)
            if (award == null) {
                logUnavailableGuardianBeanAward(awardsObject)
                return DailyTaskProcessResult.HANDLED
            }
            val skuId = award.optString("skuId")
            val beanQuantity = award.optInt("beanQuantity", 0)
            if (skuId.isBlank() || beanQuantity <= 0) {
                Log.error("$TAG.collectGuardianBeanAward", "安心豆🫘[守护者奖励配置异常]#$award")
                return DailyTaskProcessResult.UNKNOWN_FAILURE
            }
            val sendResponse = AntMemberRpcCall.guardianAwardSend(skuId)
            val sendObject = JSONObject(sendResponse)
            if (ResChecker.checkRes(TAG, sendObject)) {
                Log.member("安心豆🫘[守护者等级奖励]#${beanQuantity}豆")
                return DailyTaskProcessResult.HANDLED
            } else {
                return logGuardianBeanAwardSendFailure(sendObject, sendResponse)
            }
        } catch (t: Throwable) {
            Log.printStackTrace(TAG, "collectGuardianBeanAward err:", t)
            return DailyTaskProcessResult.UNKNOWN_FAILURE
        }
    }

    private fun findAvailableGuardianBeanAward(responseObject: JSONObject): JSONObject? {
        val gradeAwardsList = responseObject.optJSONObject("result")?.optJSONArray("gradeSkuAwardsList") ?: return null
        for (i in 0 until gradeAwardsList.length()) {
            val skuAwardList = gradeAwardsList.optJSONObject(i)?.optJSONArray("skuAwardList") ?: continue
            for (j in 0 until skuAwardList.length()) {
                val award = skuAwardList.optJSONObject(j) ?: continue
                if (award.optString("status") == "AVAILABLE" &&
                    award.optString("spuType") == "MARKETING_PRIZE" &&
                    award.optInt("beanQuantity", 0) > 0
                ) {
                    return award
                }
            }
        }
        return null
    }

    private fun logUnavailableGuardianBeanAward(responseObject: JSONObject) {
        val gradeAwardsList = responseObject.optJSONObject("result")?.optJSONArray("gradeSkuAwardsList") ?: return
        for (i in 0 until gradeAwardsList.length()) {
            val skuAwardList = gradeAwardsList.optJSONObject(i)?.optJSONArray("skuAwardList") ?: continue
            for (j in 0 until skuAwardList.length()) {
                val award = skuAwardList.optJSONObject(j) ?: continue
                val beanQuantity = award.optInt("beanQuantity", 0)
                val status = award.optString("status")
                if (award.optString("spuType") == "MARKETING_PRIZE" &&
                    beanQuantity > 0 &&
                    status == "MONTH_COUNT_LIMIT"
                ) {
                    Log.member("安心豆🫘[守护者等级奖励]#${beanQuantity}豆，业务受限($status)，跳过")
                    return
                }
            }
        }
    }

    private fun logGuardianBeanAwardSendFailure(
        responseObject: JSONObject,
        rawResponse: String
    ): DailyTaskProcessResult {
        val code = sequenceOf(
            responseObject.optString("resultCode"),
            responseObject.optString("code"),
            responseObject.optString("errorCode")
        ).firstOrNull { it.isNotBlank() }.orEmpty()
        val message = sequenceOf(
            responseObject.optString("resultDesc"),
            responseObject.optString("resultMsg"),
            responseObject.optString("memo"),
            responseObject.optString("errorMessage"),
            responseObject.optString("errorMsg"),
            responseObject.optString("desc")
        ).firstOrNull { it.isNotBlank() }.orEmpty()
        val detail = when {
            code.isNotBlank() && message.isNotBlank() -> "$code/$message"
            code.isNotBlank() -> code
            message.isNotBlank() -> message
            else -> rawResponse
        }
        return when (classifyGuardianBeanAwardFailure(code, message)) {
            GuardianBeanAwardRpcFailureType.DUPLICATE_REWARD -> {
                Log.member("安心豆🫘[守护者等级奖励]#已领取或重复领取，跳过:$detail")
                DailyTaskProcessResult.HANDLED
            }

            GuardianBeanAwardRpcFailureType.BUSINESS_LIMIT -> {
                Log.member("安心豆🫘[守护者等级奖励]#业务受限，本轮跳过:$detail")
                DailyTaskProcessResult.HANDLED
            }

            GuardianBeanAwardRpcFailureType.RETRYABLE -> {
                Log.member("安心豆🫘[守护者等级奖励]#暂时不可领取，保留后续重试:$detail")
                DailyTaskProcessResult.RETRYABLE_FAILURE
            }

            GuardianBeanAwardRpcFailureType.NON_RETRYABLE -> {
                Log.error("$TAG.collectGuardianBeanAward", "安心豆🫘[守护者奖励领取失败]#$detail")
                DailyTaskProcessResult.UNKNOWN_FAILURE
            }
        }
    }

    private fun hasBeanTaskCenterSendOrder(task: JSONObject): Boolean {
        val sendOrderList = task.optJSONArray("sendPrizeSendOrderList") ?: return false
        for (i in 0 until sendOrderList.length()) {
            val sendOrder = sendOrderList.optJSONObject(i) ?: continue
            val sendStatus = sendOrder.optString("sendStatus")
            if (sendStatus.isBlank() || sendStatus.equals("SUCCESS", true)) {
                return true
            }
        }
        return false
    }

    private fun classifyGuardianBeanAwardFailure(code: String, message: String): GuardianBeanAwardRpcFailureType {
        return when {
            message.contains("已领取") ||
                message.contains("重复") ||
                message.contains("已经领取") -> GuardianBeanAwardRpcFailureType.DUPLICATE_REWARD

            message.contains("稍后") ||
                message.contains("频繁") ||
                message.contains("繁忙") -> GuardianBeanAwardRpcFailureType.RETRYABLE

            code.contains("LIMIT", ignoreCase = true) ||
                message.contains("上限") ||
                message.contains("限制") ||
                message.contains("受限") ||
                message.contains("不可领取") -> GuardianBeanAwardRpcFailureType.BUSINESS_LIMIT

            else -> GuardianBeanAwardRpcFailureType.NON_RETRYABLE
        }
    }

    private fun processBeanTaskCenter(): DailyTaskProcessResult {
        val taskCenterScan = queryBeanTaskCenterStatus()
        var result = taskCenterScan.result
        if (taskCenterScan.hasGuardianQuizCandidate) {
            result = mergeDailyTaskProcessResult(result, consultGuardianAnswerTask())
        }
        return result
    }

    private fun consultGuardianAnswerTask(): DailyTaskProcessResult {
        return try {
            val response = AntMemberRpcCall.guardianAnswerConsult()
            val responseObject = JSONObject(response)
            if (!ResChecker.checkRes(TAG, responseObject)) {
                val detail = buildBeanTaskCenterFailureDetail(responseObject, response)
                val failureType = classifyBeanTaskCenterFailure(detail.first, detail.second)
                return when (failureType) {
                    GuardianBeanAwardRpcFailureType.BUSINESS_LIMIT -> {
                        Log.member("安心豆🫘[保险知识闯关]#业务受限，本轮跳过:${detailToString(detail, response)}")
                        DailyTaskProcessResult.HANDLED
                    }

                    GuardianBeanAwardRpcFailureType.DUPLICATE_REWARD -> {
                        Log.member("安心豆🫘[保险知识闯关]#已处理过，跳过:${detailToString(detail, response)}")
                        DailyTaskProcessResult.HANDLED
                    }

                    GuardianBeanAwardRpcFailureType.RETRYABLE -> {
                        Log.member("安心豆🫘[保险知识闯关]#暂时不可查询，保留后续重试:${detailToString(detail, response)}")
                        DailyTaskProcessResult.RETRYABLE_FAILURE
                    }

                    GuardianBeanAwardRpcFailureType.NON_RETRYABLE -> {
                        Log.error("$TAG.consultGuardianAnswerTask", "安心豆🫘[保险知识闯关]#查询失败:${detailToString(detail, response)}")
                        DailyTaskProcessResult.UNKNOWN_FAILURE
                    }
                }
            }

            val answerStatus = resolveGuardianAnswerStatus(responseObject)
            return when {
                isGuardianAnswerHandledStatus(answerStatus) -> {
                    Log.member("安心豆🫘[保险知识闯关]#状态已完成:$answerStatus")
                    DailyTaskProcessResult.HANDLED
                }

                answerStatus == "ANSWER_PENDING" -> {
                    completeGuardianAnswerPendingTask()
                }

                answerStatus.isBlank() -> {
                    Log.member("安心豆🫘[保险知识闯关]#未返回答题状态，保留后续日志复核")
                    DailyTaskProcessResult.PENDING
                }

                else -> {
                    Log.member("安心豆🫘[保险知识闯关]#当前状态:$answerStatus")
                    DailyTaskProcessResult.PENDING
                }
            }
        } catch (t: Throwable) {
            Log.printStackTrace(TAG, "consultGuardianAnswerTask err:", t)
            DailyTaskProcessResult.UNKNOWN_FAILURE
        }
    }

    private fun resolveGuardianAnswerStatus(responseObject: JSONObject): String {
        return responseObject.optJSONObject("result")?.optString("answerStatus")
            ?.takeIf { it.isNotBlank() }
            ?: responseObject.optString("answerStatus")
    }

    private fun isGuardianAnswerHandledStatus(answerStatus: String): Boolean {
        return when (answerStatus) {
            "ANSWERED",
            "ANSWER_SUCCESS",
            "RECEIVE_SUCCESS",
            "ANSWER_COMPLETED" -> true

            else -> false
        }
    }

    private fun resolveBeanGuardianUserId(): String? {
        return AccountSessionCoordinator.currentUserId()?.takeIf { it.isNotBlank() }
            ?: UserMap.currentUid?.takeIf { it.isNotBlank() }
    }

    private fun resolveBeanGuardianQuizFailure(
        actionLabel: String,
        errorSource: String,
        responseObject: JSONObject,
        rawResponse: String
    ): DailyTaskProcessResult {
        val detail = buildBeanTaskCenterFailureDetail(responseObject, rawResponse)
        return when (classifyBeanTaskCenterFailure(detail.first, detail.second)) {
            GuardianBeanAwardRpcFailureType.BUSINESS_LIMIT -> {
                Log.member("安心豆🫘[保险知识闯关]#${actionLabel}业务受限，本轮跳过:${detailToString(detail, rawResponse)}")
                DailyTaskProcessResult.HANDLED
            }

            GuardianBeanAwardRpcFailureType.DUPLICATE_REWARD -> {
                Log.member("安心豆🫘[保险知识闯关]#${actionLabel}已处理过，跳过:${detailToString(detail, rawResponse)}")
                DailyTaskProcessResult.HANDLED
            }

            GuardianBeanAwardRpcFailureType.RETRYABLE -> {
                Log.member("安心豆🫘[保险知识闯关]#${actionLabel}暂时不可用，保留后续重试:${detailToString(detail, rawResponse)}")
                DailyTaskProcessResult.RETRYABLE_FAILURE
            }

            GuardianBeanAwardRpcFailureType.NON_RETRYABLE -> {
                Log.error(errorSource, "安心豆🫘[保险知识闯关]#${actionLabel}失败:${detailToString(detail, rawResponse)}")
                DailyTaskProcessResult.UNKNOWN_FAILURE
            }
        }
    }

    private fun resolveBeanGuardianQuestionDrama(responseObject: JSONObject): BeanGuardianQuestionDrama? {
        val data = responseObject.optJSONObject("data") ?: return null
        val questionAnswers = data.optJSONArray("userQuestionDramaAnswers") ?: return null
        val questions = (0 until questionAnswers.length())
            .mapNotNull { questionAnswers.optJSONObject(it) }
            .map { question ->
                BeanGuardianQuestion(
                    scriptId = question.optString("scriptId"),
                    userDramaId = question.optString("userDramaId"),
                    rightAnswer = question.optString("rightAnswer"),
                    sort = question.optInt("sort", Int.MAX_VALUE),
                    answerResult = question.optString("answerResult"),
                    awardStatus = question.optString("awardStatus"),
                    questionText = question.optString("question")
                )
            }
            .sortedBy { it.sort }
        return BeanGuardianQuestionDrama(
            dramaId = data.optString("dramaId"),
            nextScriptId = data.optString("nextScriptId"),
            questions = questions
        )
    }

    private fun isBeanGuardianQuestionCompleted(question: BeanGuardianQuestion): Boolean {
        if (question.awardStatus.equals("SENT", ignoreCase = true)) {
            return true
        }
        return when (question.answerResult.uppercase(Locale.ROOT)) {
            "ANSWERED",
            "ANSWER_SUCCESS",
            "SUCCESS",
            "ANSWER_COMPLETED",
            "COMPLETED" -> true

            else -> false
        }
    }

    private fun resolveBeanGuardianNextQuestion(
        questionDrama: BeanGuardianQuestionDrama,
        nextScriptId: String,
        submittedScriptIds: Set<String>
    ): BeanGuardianQuestion? {
        if (nextScriptId.isNotBlank()) {
            questionDrama.questions.firstOrNull {
                it.scriptId == nextScriptId && it.scriptId !in submittedScriptIds
            }?.let { return it }
        }
        return questionDrama.questions.firstOrNull {
            it.scriptId !in submittedScriptIds && !isBeanGuardianQuestionCompleted(it)
        } ?: questionDrama.questions.firstOrNull { it.scriptId !in submittedScriptIds }
    }

    private fun resolveBeanGuardianQuestionLabel(question: BeanGuardianQuestion): String {
        return question.questionText.ifBlank { question.scriptId.ifBlank { "未知题目" } }
    }

    private fun resolveBeanGuardianQuestionMissingField(
        questionDrama: BeanGuardianQuestionDrama,
        question: BeanGuardianQuestion
    ): String? {
        return when {
            questionDrama.dramaId.isBlank() -> "缺少dramaId"
            question.scriptId.isBlank() -> "缺少scriptId"
            question.userDramaId.isBlank() -> "缺少userDramaId"
            question.rightAnswer.isBlank() -> "缺少rightAnswer"
            else -> null
        }
    }

    private fun completeGuardianAnswerPendingTask(): DailyTaskProcessResult {
        val userId = resolveBeanGuardianUserId()
        if (userId.isNullOrBlank()) {
            Log.error("$TAG.completeGuardianAnswerPendingTask", "安心豆🫘[保险知识闯关]#缺少当前userId，无法进入答题闭环")
            return DailyTaskProcessResult.UNKNOWN_FAILURE
        }

        val questionResponse = AntMemberRpcCall.queryUserQuestionDrama(userId = userId)
        val questionObject = JSONObject(questionResponse)
        if (!ResChecker.checkRes(TAG, questionObject)) {
            return resolveBeanGuardianQuizFailure(
                "题目查询",
                "$TAG.completeGuardianAnswerPendingTask.queryUserQuestionDrama",
                questionObject,
                questionResponse
            )
        }

        val questionDrama = resolveBeanGuardianQuestionDrama(questionObject) ?: run {
            Log.error(
                "$TAG.completeGuardianAnswerPendingTask.queryUserQuestionDrama",
                "安心豆🫘[保险知识闯关]#题目结构异常，缺少userQuestionDramaAnswers:$questionResponse"
            )
            return DailyTaskProcessResult.UNKNOWN_FAILURE
        }
        if (questionDrama.questions.isEmpty()) {
            Log.member("安心豆🫘[保险知识闯关]#待答题但未返回可用题目，保留后续复查")
            return DailyTaskProcessResult.PENDING
        }
        if (questionDrama.dramaId.isBlank()) {
            Log.member("安心豆🫘[保险知识闯关]#题目链路缺少dramaId，保留后续复查")
            return DailyTaskProcessResult.PENDING
        }

        var nextScriptId = questionDrama.nextScriptId
        var progressMade = false
        val submittedScriptIds = LinkedHashSet<String>()
        while (submittedScriptIds.size < questionDrama.questions.size) {
            val question = resolveBeanGuardianNextQuestion(questionDrama, nextScriptId, submittedScriptIds) ?: break
            val missingField = resolveBeanGuardianQuestionMissingField(questionDrama, question)
            if (missingField != null) {
                Log.member("安心豆🫘[保险知识闯关]#${resolveBeanGuardianQuestionLabel(question)}$missingField，保留后续复查")
                return DailyTaskProcessResult.PENDING
            }

            val questionLabel = resolveBeanGuardianQuestionLabel(question)
            val recordResponse = AntMemberRpcCall.addAskAnswerRecord(question.scriptId, userId)
            val recordObject = JSONObject(recordResponse)
            if (!ResChecker.checkRes(TAG, recordObject)) {
                return resolveBeanGuardianQuizFailure(
                    "记录题目[$questionLabel]",
                    "$TAG.completeGuardianAnswerPendingTask.addAskAnswerRecord",
                    recordObject,
                    recordResponse
                )
            }

            val answerResponse = AntMemberRpcCall.answerQuestionDrama(
                dramaId = questionDrama.dramaId,
                scriptId = question.scriptId,
                userDramaId = question.userDramaId,
                userId = userId
            )
            val answerObject = JSONObject(answerResponse)
            if (!ResChecker.checkRes(TAG, answerObject)) {
                return resolveBeanGuardianQuizFailure(
                    "提交答案[$questionLabel]",
                    "$TAG.completeGuardianAnswerPendingTask.answerQuestionDrama",
                    answerObject,
                    answerResponse
                )
            }

            progressMade = true
            submittedScriptIds.add(question.scriptId)
            Log.member("安心豆🫘[保险知识闯关]#已提交[$questionLabel]")

            val answerData = answerObject.optJSONObject("data")
            val allCorrect = answerData?.optString("allCorrect").orEmpty().equals("true", ignoreCase = true) ||
                answerData?.optBoolean("allCorrect") == true
            if (allCorrect) {
                break
            }
            nextScriptId = answerData?.optString("nextScriptId").orEmpty()
        }

        val finalResponse = AntMemberRpcCall.guardianAnswerConsult()
        val finalObject = JSONObject(finalResponse)
        if (!ResChecker.checkRes(TAG, finalObject)) {
            return resolveBeanGuardianQuizFailure(
                "答题复核",
                "$TAG.completeGuardianAnswerPendingTask.guardianAnswerConsult",
                finalObject,
                finalResponse
            )
        }

        val finalStatus = resolveGuardianAnswerStatus(finalObject)
        return when {
            isGuardianAnswerHandledStatus(finalStatus) -> {
                Log.member("安心豆🫘[保险知识闯关]#答题闭环完成:$finalStatus")
                DailyTaskProcessResult.HANDLED
            }

            progressMade -> {
                Log.member("安心豆🫘[保险知识闯关]#本轮已推进答题，但复核仍未完成:${finalStatus.ifBlank { "UNKNOWN" }}")
                DailyTaskProcessResult.PENDING
            }

            else -> {
                Log.member("安心豆🫘[保险知识闯关]#未完成答题闭环，当前状态:${finalStatus.ifBlank { "UNKNOWN" }}")
                DailyTaskProcessResult.PENDING
            }
        }
    }

    private fun queryBeanTaskCenterStatus(): BeanTaskCenterScanResult {
        return try {
            val response = AntMemberRpcCall.beanTaskCenterConsult(
                taskCenterId = "AP15241780",
                sceneCode = "AXD_TAK_LIST"
            )
            val responseObject = JSONObject(response)
            if (!ResChecker.checkRes(TAG, responseObject)) {
                val detail = buildBeanTaskCenterFailureDetail(responseObject, response)
                return when (classifyBeanTaskCenterFailure(detail.first, detail.second)) {
                    GuardianBeanAwardRpcFailureType.BUSINESS_LIMIT -> {
                        Log.member("安心豆🫘[任务中心]#业务受限，本轮跳过:${detailToString(detail, response)}")
                        BeanTaskCenterScanResult(0, DailyTaskProcessResult.HANDLED, false)
                    }

                    GuardianBeanAwardRpcFailureType.DUPLICATE_REWARD -> {
                        Log.member("安心豆🫘[任务中心]#已领取或重复领取，跳过:${detailToString(detail, response)}")
                        BeanTaskCenterScanResult(0, DailyTaskProcessResult.HANDLED, false)
                    }

                    GuardianBeanAwardRpcFailureType.RETRYABLE -> {
                        Log.member("安心豆🫘[任务中心]#暂时不可查询，保留后续重试:${detailToString(detail, response)}")
                        BeanTaskCenterScanResult(0, DailyTaskProcessResult.RETRYABLE_FAILURE, false)
                    }

                    GuardianBeanAwardRpcFailureType.NON_RETRYABLE -> {
                        Log.error("$TAG.queryBeanTaskCenterStatus", "安心豆🫘[任务中心]#查询失败:${detailToString(detail, response)}")
                        BeanTaskCenterScanResult(0, DailyTaskProcessResult.UNKNOWN_FAILURE, false)
                    }
                }
            }

            val resultObject = responseObject.optJSONObject("result") ?: responseObject.optJSONObject("data")
            if (resultObject == null) {
                Log.error("$TAG.queryBeanTaskCenterStatus", "安心豆🫘[任务中心]#响应缺少result/data:$response")
                return BeanTaskCenterScanResult(0, DailyTaskProcessResult.UNKNOWN_FAILURE, false)
            }
            val pendingTaskScan = logBeanTaskCenterTaskList(
                resultObject.optJSONArray("taskDetailList"),
                treatTaskListAsHandled = false
            )
            val doneTaskScan = logBeanTaskCenterTaskList(
                resultObject.optJSONArray("doneTaskDetailList"),
                treatTaskListAsHandled = true
            )
            if (pendingTaskScan.taskCount == 0 && doneTaskScan.taskCount == 0) {
                Log.member("安心豆🫘[任务中心]#无可识别任务")
            }
            BeanTaskCenterScanResult(
                taskCount = pendingTaskScan.taskCount + doneTaskScan.taskCount,
                result = mergeDailyTaskProcessResult(doneTaskScan.result, pendingTaskScan.result),
                hasGuardianQuizCandidate = pendingTaskScan.hasGuardianQuizCandidate
            )
        } catch (t: Throwable) {
            Log.printStackTrace(TAG, "queryBeanTaskCenterStatus err:", t)
            BeanTaskCenterScanResult(0, DailyTaskProcessResult.UNKNOWN_FAILURE, false)
        }
    }

    private fun logBeanTaskCenterTaskList(
        taskList: JSONArray?,
        treatTaskListAsHandled: Boolean
    ): BeanTaskCenterTaskListScanResult {
        if (taskList == null) {
            return BeanTaskCenterTaskListScanResult(0, DailyTaskProcessResult.HANDLED, false)
        }
        var count = 0
        var result = DailyTaskProcessResult.HANDLED
        var hasGuardianQuizCandidate = false
        for (i in 0 until taskList.length()) {
            val task = taskList.optJSONObject(i) ?: continue
            count++
            val taskId = resolveBeanTaskCenterTaskId(task)
            val title = resolveBeanTaskCenterTaskTitle(task, taskId)
            val status = task.optString("taskProcessStatus").trim()
            val normalizedStatus = status.uppercase(Locale.ROOT)
            val errorCode = task.optString("queryErrorCode").trim()
            val errorMsg = task.optString("queryErrorMsg").trim()
            val taskMainType = task.optString("taskMainType")
            val displayInfo = task.optJSONObject("taskDisplayInfo")
            val customInfo = displayInfo?.optJSONObject("customInfo") ?: JSONObject()
            val taskType = customInfo.optString("taskType").ifBlank { taskMainType }
            val operationType = customInfo.optString("taskOperationType")
            val taskCategory = task.optString("taskCategory").ifBlank {
                customInfo.optString("taskCategorize")
            }
            val detail = when {
                errorCode.isNotBlank() && errorMsg.isNotBlank() -> "$errorCode/$errorMsg"
                errorCode.isNotBlank() -> errorCode
                else -> errorMsg
            }
            val hasSendOrder = hasBeanTaskCenterSendOrder(task)
            when {
                hasSendOrder || normalizedStatus in setOf(
                    "RECEIVE_SUCCESS",
                    "HAS_RECEIVED",
                    "RECEIVED",
                    "DONE",
                    "COMPLETED",
                    "SUCCESS"
                ) -> {
                    Log.member("安心豆🫘[任务中心]#$title($taskId) 已完成/已领取")
                }

                treatTaskListAsHandled -> {
                    Log.member("安心豆🫘[任务中心]#$title($taskId) 已在完成列表中，保持收口")
                }

                errorCode in beanTaskCenterHandledLimitCodes -> {
                    Log.member("安心豆🫘[任务中心]#$title($taskId) 业务受限，跳过:${detail.ifBlank { errorCode }}")
                }

                taskType == "BROWSE_PAGE" && operationType == "BROWSE_TASK" -> {
                    result = mergeDailyTaskProcessResult(result, processBeanBrowseTask(task))
                }

                normalizedStatus == "WAIT_RECEIVE" ||
                    normalizedStatus == "TO_RECEIVE" ||
                    normalizedStatus == "FINISHED" -> {
                    if (!treatTaskListAsHandled &&
                        isBeanGuardianQuizCandidate(taskMainType, taskType, operationType, taskCategory)
                    ) {
                        hasGuardianQuizCandidate = true
                    }
                    Log.member("安心豆🫘[任务中心]#$title($taskId) 待领取，但当前未抓到明确领奖RPC，保留后续复核")
                    result = mergeDailyTaskProcessResult(result, DailyTaskProcessResult.PENDING)
                }

                status.isNotBlank() -> {
                    if (!treatTaskListAsHandled &&
                        isBeanGuardianQuizCandidate(taskMainType, taskType, operationType, taskCategory)
                    ) {
                        hasGuardianQuizCandidate = true
                    }
                    Log.member("安心豆🫘[任务中心]#$title($taskId) 当前状态:$status")
                    result = mergeDailyTaskProcessResult(result, DailyTaskProcessResult.PENDING)
                }

                detail.isNotBlank() -> {
                    if (!treatTaskListAsHandled &&
                        isBeanGuardianQuizCandidate(taskMainType, taskType, operationType, taskCategory)
                    ) {
                        hasGuardianQuizCandidate = true
                    }
                    Log.member("安心豆🫘[任务中心]#$title($taskId) 当前未收口:$detail")
                    result = mergeDailyTaskProcessResult(result, DailyTaskProcessResult.PENDING)
                }

                else -> {
                    if (!treatTaskListAsHandled &&
                        isBeanGuardianQuizCandidate(taskMainType, taskType, operationType, taskCategory)
                    ) {
                        hasGuardianQuizCandidate = true
                    }
                    Log.member("安心豆🫘[任务中心]#$title($taskId) 当前未收口，保留后续复核")
                    result = mergeDailyTaskProcessResult(result, DailyTaskProcessResult.PENDING)
                }
            }
        }
        return BeanTaskCenterTaskListScanResult(count, result, hasGuardianQuizCandidate)
    }

    private fun processBeanBrowseTask(task: JSONObject): DailyTaskProcessResult {
        val appletId = task.optJSONObject("taskConfig")?.optString("appletId").orEmpty()
            .ifBlank { task.optString("taskId") }
        val center = task.optString("taskCenterId")
        if (appletId.isBlank() || center.isBlank()) {
            Log.error(TAG, "安心豆浏览任务合同不完整:$task")
            return DailyTaskProcessResult.PENDING
        }
        val store = io.github.aoguai.sesameag.util.UserDataStoreManager.getCurrentInstance()
            ?: return DailyTaskProcessResult.PENDING
        val orderKey = "${java.time.LocalDate.now()}:$center:$appletId"
        val orders = store.getOrCreate<MutableMap<String, String>>("beanBrowseOrders")
        var orderId = task.optString("taskOrderId").ifBlank { orders[orderKey].orEmpty() }
        try {
            if (task.optString("taskProcessStatus") == "NONE_SIGNUP" && orderId.isBlank()) {
                val signup = JSONObject(AntMemberRpcCall.beanTaskTrigger(appletId, "AXD_TAK_LIST", center, "signup"))
                if (!ResChecker.checkRes(TAG, signup)) return DailyTaskProcessResult.UNKNOWN_FAILURE
                orderId = signup.optJSONObject("result")?.optString("taskOrderId").orEmpty()
                if (orderId.isBlank()) {
                    Log.error(TAG, "安心豆浏览报名未返回订单:$signup")
                    return DailyTaskProcessResult.PENDING
                }
                orders[orderKey] = orderId
                store.put("beanBrowseOrders", orders)
            }
            val sent = JSONObject(AntMemberRpcCall.beanTaskTrigger(appletId, "AXD_TAK_LIST", center, "send"))
            val accepted = ResChecker.checkRes(TAG, sent)
            val returnedOrder = sent.optJSONObject("result")?.optString("taskOrderId").orEmpty()
            if (orderId.isNotBlank() && returnedOrder.isNotBlank() && returnedOrder != orderId) {
                Log.error(TAG, "安心豆浏览发奖订单不一致 expected=$orderId raw=$sent")
                return DailyTaskProcessResult.UNKNOWN_FAILURE
            }
            if (orderId.isBlank()) orderId = returnedOrder
            val refreshed = JSONObject(AntMemberRpcCall.beanTaskCenterConsult(center, "AXD_TAK_LIST"))
            if (!ResChecker.checkRes(TAG, refreshed)) return DailyTaskProcessResult.UNKNOWN_FAILURE
            val data = refreshed.optJSONObject("result") ?: refreshed.optJSONObject("data")
            val confirmed = sequenceOf(data?.optJSONArray("doneTaskDetailList"), data?.optJSONArray("taskDetailList"))
                .filterNotNull().flatMap { list -> (0 until list.length()).asSequence().mapNotNull { list.optJSONObject(it) } }
                .filter { it.optString("taskId") == appletId }
                .any { current ->
                    val awards = current.optJSONArray("sendPrizeSendOrderList") ?: JSONArray()
                    (0 until awards.length()).any { index ->
                        val award = awards.optJSONObject(index)
                        orderId.isNotBlank() && award?.optString("sendStatus") == "SUCCESS" &&
                            award.optJSONObject("extInfo")?.optString("TASK_ORDER_ID") == orderId
                    }
                }
            if (confirmed) {
                orders.remove(orderKey)
                store.put("beanBrowseOrders", orders)
                Log.member("安心豆🫘[浏览任务发奖已确认] appletId=$appletId taskOrderId=$orderId")
                return DailyTaskProcessResult.HANDLED
            }
            return if (accepted) DailyTaskProcessResult.PENDING else DailyTaskProcessResult.UNKNOWN_FAILURE
        } catch (t: Throwable) {
            Log.printStackTrace(TAG, "安心豆浏览任务推进失败[$appletId]", t)
            return DailyTaskProcessResult.UNKNOWN_FAILURE
        }
    }

    private fun isBeanGuardianQuizCandidate(
        taskMainType: String,
        taskType: String,
        operationType: String,
        taskCategory: String
    ): Boolean {
        if (taskCategory.equals("TRANSFER", ignoreCase = true)) {
            return false
        }
        if (taskMainType == "BROWSE_PAGE" ||
            taskType == "BROWSE_PAGE" ||
            taskMainType == "BROWSE_TASK" ||
            taskType == "BROWSE_TASK" ||
            operationType == "BROWSE_TASK" ||
            operationType == "CLICK_TASK" ||
            operationType == "NORMAL_PENDANT_CLICK_TASK" ||
            taskMainType == "EXPLAIN_INTELLIGENCE" ||
            taskType == "EXPLAIN_INTELLIGENCE" ||
            taskMainType == "COMMON_TASK" ||
            taskType == "COMMON_TASK" ||
            operationType == "COMMON_TASK"
        ) {
            return false
        }
        return taskMainType.isNotBlank() || taskType.isNotBlank() || operationType.isNotBlank()
    }

    private fun resolveBeanTaskCenterTaskId(task: JSONObject): String {
        return sequenceOf(
            task.optString("taskId"),
            task.optString("taskConfigId"),
            task.optString("id"),
            task.optJSONObject("taskBaseInfo")?.optString("taskId").orEmpty()
        ).firstOrNull { it.isNotBlank() }.orEmpty()
    }

    private fun resolveBeanTaskCenterTaskTitle(task: JSONObject, taskId: String): String {
        val displayInfo = task.optJSONObject("taskDisplayInfo")
        return sequenceOf(
            displayInfo?.optString("taskMainTitle").orEmpty(),
            displayInfo?.optString("taskTitle").orEmpty(),
            task.optString("taskMainTitle"),
            task.optString("taskTitle"),
            task.optString("title")
        ).firstOrNull { it.isNotBlank() }.orEmpty().ifBlank { "任务$taskId" }
    }

    private fun buildBeanTaskCenterFailureDetail(responseObject: JSONObject, rawResponse: String): Pair<String, String> {
        val code = sequenceOf(
            responseObject.optString("resultCode"),
            responseObject.optString("code"),
            responseObject.optString("errorCode"),
            responseObject.optString("errCode")
        ).firstOrNull { it.isNotBlank() }.orEmpty()
        val message = sequenceOf(
            responseObject.optString("resultDesc"),
            responseObject.optString("resultMsg"),
            responseObject.optString("memo"),
            responseObject.optString("errorMessage"),
            responseObject.optString("errorMsg"),
            responseObject.optString("desc")
        ).firstOrNull { it.isNotBlank() }.orEmpty().ifBlank { rawResponse }
        return code to message
    }

    private fun classifyBeanTaskCenterFailure(code: String, message: String): GuardianBeanAwardRpcFailureType {
        if (code in beanTaskCenterHandledLimitCodes) {
            return GuardianBeanAwardRpcFailureType.BUSINESS_LIMIT
        }
        return classifyGuardianBeanAwardFailure(code, message)
    }

    private fun detailToString(detail: Pair<String, String>, rawResponse: String): String {
        val (code, message) = detail
        return when {
            code.isNotBlank() && message.isNotBlank() -> "$code/$message"
            code.isNotBlank() -> code
            message.isNotBlank() -> message
            else -> rawResponse
        }
    }

    internal fun beanExchangeRight() {
        try {
            val selectedIds: Set<String> = beanExchangeRightList?.value
                ?.filterNotNull()
                ?.map { it.trim() }
                ?.filter { it.isNotEmpty() }
                ?.toSet()
                ?: emptySet()
            val userId = UserMap.currentUid
            if (selectedIds.isEmpty()) {
                Log.member("安心豆🫘未勾选目标，跳过列表拉取")
                return
            }
            val candidateMap = queryBeanExchangeCandidates(queryBlueBeanBalance())
            val beanRightMap = IdMapManager.getInstance(BeanExchangeRightMap::class.java)
            if (candidateMap.isEmpty()) {
                beanRightMap.save(userId)
                Log.member("安心豆🫘未获取到可兑换权益列表")
                return
            }
            val remainingSelectedIds: MutableSet<String>? = if (selectedIds.isNotEmpty()) selectedIds.toMutableSet() else null
            candidateMap.values.forEach { candidate ->
                beanRightMap.add(candidate.item.id, candidate.item.displayName())
                if (!selectedIds.contains(candidate.item.id)) {
                    return@forEach
                }
                remainingSelectedIds?.remove(candidate.item.id)
                when (candidate.item.safety) {
                    ExchangeSafety.UNAVAILABLE -> {
                        Log.member("安心豆🫘跳过[${candidate.item.displayName()}]#${candidate.item.safetyReason}")
                    }
                    ExchangeSafety.LOG_ONLY -> {
                        Log.member("安心豆🫘已勾选[${candidate.item.displayName()}]#仅提醒，不自动兑换")
                    }
                    ExchangeSafety.AUTO -> {
                        exchangeBeanCandidate(candidate)
                    }
                }
            }
            beanRightMap.save(userId)
            remainingSelectedIds
                ?.forEach { Log.member("安心豆🫘已勾选[$it]#本次列表未返回，保留配置不删除") }
            Log.member("安心豆🫘兑换列表刷新完成#${candidateMap.size}")
        } catch (t: Throwable) {
            Log.printStackTrace(TAG, "beanExchangeRight err:", t)
        }
    }

    internal fun replenishExchangeByNeed(
        need: ExchangeEffectNeed,
        reason: String,
        maxCount: Int,
        onFailure: ((TaskFlowActionResult) -> Unit)? = null,
    ): ExchangeReplenishResult {
        return if (need == ExchangeEffectNeed.MEMBER_GOLD_TICKET) {
            replenishBeanExchangeByNeed(need, reason, maxCount)
        } else {
            replenishMemberPointExchangeByNeed(need, reason, maxCount, onFailure)
        }
    }

    private fun replenishMemberPointExchangeByNeed(
        need: ExchangeEffectNeed,
        reason: String,
        maxCount: Int,
        onFailure: ((TaskFlowActionResult) -> Unit)? = null,
    ): ExchangeReplenishResult {
        if (memberPointExchangeBenefit?.value != true) {
            return ExchangeReplenishResult.NOT_SELECTED
        }
        val selectedIds = ExchangeReplenisher.remainingSelectedIds(
            memberPointExchangeBenefitList?.value, ::canMemberPointExchangeBenefitToday
        )
        if (selectedIds.isEmpty()) {
            return ExchangeReplenishResult.NOT_SELECTED
        }
        var failure: TaskFlowActionResult? = null
        return runCatching {
            val memberInfo = JSONObject(AntMemberRpcCall.queryMemberInfo())
            if (!ResChecker.checkRes(TAG, "会员积分信息查询失败:", memberInfo)) {
                onFailure?.invoke(memberDomainTaskFailureResult(null, memberInfo, memberInfo.toString(), "queryMemberInfo", "缺货补兑查询失败"))
                return@runCatching ExchangeReplenishResult.RETRY_LATER
            }
            val pointBalance = memberInfo.optString("pointBalance")
                .ifEmpty { memberInfo.optInt("pointBalance", 0).toString() }
            val report: (TaskFlowActionResult) -> Unit = { result ->
                failure = result
                onFailure?.invoke(result)
            }
            val candidateMap = queryMemberExchangeCandidates(UserMap.currentUid, pointBalance, 850L, onFailure = report)
            if (failure != null) return@runCatching ExchangeReplenishResult.RETRY_LATER
            var matchedSelected = false
            var exchangedCount = 0
            for (candidate in candidateMap.values.sortedBy { ExchangeEffectCatalog.priorityFor(it.item, need) }) {
                if (exchangedCount >= maxCount.coerceAtLeast(1)) {
                    break
                }
                if (!selectedIds.contains(candidate.item.id) ||
                    candidate.item.effectTags.none { it.need == need }
                ) {
                    continue
                }
                matchedSelected = true
                if (!canMemberPointExchangeBenefitToday(candidate.item.id)) continue
                if (candidate.item.safety == ExchangeSafety.LOG_ONLY) continue
                if (exchangeMemberPointBenefit(candidate, report)) {
                    memberPointExchangeBenefitToday(candidate.item.id)
                    exchangedCount += 1
                    Log.member("会员积分缺货补兑🎐[${candidate.item.name}]#${reason.ifBlank { need.name }}")
                }
                if (failure != null) return@runCatching if (failure?.failureType == TaskRpcFailureType.BUSINESS_LIMIT)
                    ExchangeReplenishResult.BUSINESS_LIMIT else ExchangeReplenishResult.RETRY_LATER
            }
            when {
                exchangedCount > 0 -> ExchangeReplenishResult.EXCHANGED
                matchedSelected -> ExchangeReplenishResult.NOT_AVAILABLE
                else -> ExchangeReplenishResult.NOT_SELECTED
            }
        }.onFailure {
            if (it is CancellationException) throw it
            if (failure == null) onFailure?.invoke(TaskFlowActionResult.failure(TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW,
                rpc = "replenishMemberPointExchangeByNeed", message = it.message.orEmpty(), raw = it.toString()))
            Log.printStackTrace(TAG, "replenishMemberPointExchangeByNeed err:", it)
        }.getOrDefault(ExchangeReplenishResult.RETRY_LATER)
    }

    private fun replenishBeanExchangeByNeed(
        need: ExchangeEffectNeed,
        reason: String,
        maxCount: Int
    ): ExchangeReplenishResult {
        if (beanExchangeRight?.value != true) {
            return ExchangeReplenishResult.NOT_SELECTED
        }
        val selectedIds = beanExchangeRightList?.value
            ?.filterNotNull()
            ?.map { it.trim() }
            ?.filter { it.isNotEmpty() }
            ?.toSet()
            ?: emptySet()
        if (selectedIds.isEmpty()) {
            return ExchangeReplenishResult.NOT_SELECTED
        }
        return runCatching {
            val candidateMap = queryBeanExchangeCandidates(queryBlueBeanBalance())
            var matchedSelected = false
            var attempted = false
            var exchangedCount = 0
            for (candidate in candidateMap.values.sortedBy { ExchangeEffectCatalog.priorityFor(it.item, need) }) {
                if (exchangedCount >= maxCount.coerceAtLeast(1)) {
                    break
                }
                if (!selectedIds.contains(candidate.item.id) ||
                    candidate.item.effectTags.none { it.need == need }
                ) {
                    continue
                }
                matchedSelected = true
                if (!candidate.rightsMetaSubType.equals("GOLD_TICKET", ignoreCase = true) ||
                    candidate.needOrder != 0 ||
                    candidate.assetAmount <= 0 ||
                    candidate.item.safety != ExchangeSafety.AUTO
                ) {
                    continue
                }
                attempted = true
                if (exchangeBeanCandidate(candidate)) {
                    exchangedCount += 1
                    Log.member("安心豆缺货补兑🫘[${candidate.item.name}]#${reason.ifBlank { need.name }}")
                }
            }
            when {
                exchangedCount > 0 -> ExchangeReplenishResult.EXCHANGED
                matchedSelected && attempted -> ExchangeReplenishResult.RETRY_LATER
                matchedSelected -> ExchangeReplenishResult.NOT_AVAILABLE
                else -> ExchangeReplenishResult.NOT_SELECTED
            }
        }.onFailure {
            if (it is CancellationException) throw it
            Log.printStackTrace(TAG, "replenishBeanExchangeByNeed err:", it)
        }.getOrDefault(ExchangeReplenishResult.RETRY_LATER)
    }

    private fun exchangeBeanCandidate(candidate: BeanExchangeCandidate): Boolean {
        val detailResp = JSONObject(AntMemberRpcCall.queryRightsDetail(candidate.rightsId))
        if (!ExchangeSafetyRules.isSuccessResponse(detailResp) &&
            !ResChecker.checkRes(TAG, "安心豆权益详情查询失败:", detailResp)
        ) {
            Log.member("安心豆🫘兑换前详情校验失败[${candidate.item.name}]")
            return false
        }
        val exchangeResult = JSONObject(
            AntMemberRpcCall.rightsExchange(candidate.rightsId, candidate.assetAmount, candidate.needOrder)
        )
        if (ExchangeSafetyRules.isSuccessResponse(exchangeResult) ||
            ResChecker.checkRes(TAG, "安心豆权益兑换失败:", exchangeResult)
        ) {
            Log.member("安心豆🫘兑换[${candidate.item.name}]#消耗${candidate.assetAmount}安心豆")
            runCatching { AntMemberRpcCall.queryRightsExchangeFlows(pageStartIndex = 0, pageSize = 20) }
                .onFailure { Log.printStackTrace(TAG, "exchangeBeanCandidate.postQuery err:", it) }
            return true
        }
        Log.error(TAG, "安心豆🫘兑换失败[${candidate.item.name}]#$exchangeResult")
        return false
    }

    private fun addBeanExchangeCandidates(
        response: JSONObject,
        candidateMap: MutableMap<String, BeanExchangeCandidate>,
        fromHistory: Boolean,
        beanBalance: Int?
    ) {
        val result = extractBeanExchangeResult(response)
        val arrays = listOfNotNull(
            result.optJSONArray("preExchangeDetailList"),
            result.optJSONArray("couponRightsDTOList"),
            result.optJSONArray("rightsList"),
            result.optJSONArray("flowList")
        )
        arrays.forEach { array ->
            for (i in 0 until array.length()) {
                val candidate = buildBeanExchangeCandidate(array.optJSONObject(i) ?: continue, fromHistory, beanBalance) ?: continue
                val existing = candidateMap[candidate.item.id]
                if (fromHistory && existing != null) {
                    continue
                }
                candidateMap[candidate.item.id] = candidate
            }
        }
    }

    private fun extractBeanExchangeResult(response: JSONObject): JSONObject {
        return response.optJSONObject("result")
            ?: response.optJSONObject("data")?.optJSONObject("result")
            ?: response.optJSONObject("data")
            ?: response
    }

    private fun queryBlueBeanBalance(): Int? {
        return runCatching {
            val accountInfo = JSONObject(AntMemberRpcCall.queryAccountSummaryPoint())
            if (!ResChecker.checkRes(TAG, accountInfo)) {
                return@runCatching null
            }
            val result = accountInfo.optJSONObject("result")
                ?: accountInfo.optJSONObject("data")?.optJSONObject("result")
                ?: accountInfo.optJSONObject("data")
                ?: return@runCatching null
            result.optInt("effectPoint", -1).takeIf { it >= 0 }
        }.onFailure {
            Log.printStackTrace(TAG, "queryBlueBeanBalance err:", it)
        }.getOrNull()
    }

    private fun buildBeanExchangeCandidate(raw: JSONObject, fromHistory: Boolean, beanBalance: Int?): BeanExchangeCandidate? {
        val rightsId = sequenceOf(
            raw.optString("rightsId"),
            raw.optString("rightsCode"),
            raw.optString("itemId"),
            raw.optString("id")
        ).firstOrNull { it.isNotBlank() }.orEmpty()
        if (rightsId.isEmpty()) {
            return null
        }
        val name = sequenceOf(
            raw.optString("title"),
            raw.optString("simpleTitle"),
            raw.optString("rightsName"),
            raw.optString("itemName"),
            raw.optString("prizeName")
        ).firstOrNull { it.isNotBlank() } ?: rightsId
        val cash = raw.optString("cash")
        val pointNum = raw.optString("pointNum")
        val status = raw.optString("status")
        val rightsUseLink = raw.optString("rightsUseLink", raw.optString("jumpUrl"))
        val showType = raw.optString("showType")
        val rightsMetaSubType = raw.optString("rightsMetaSubType")
            .ifBlank { raw.optString("rightsSubType") }
        val needOrder = when {
            raw.has("needOrder") -> raw.optInt("needOrder", -1)
            raw.optJSONObject("exchangeRequest")?.has("needOrder") == true ->
                raw.optJSONObject("exchangeRequest")?.optInt("needOrder", -1) ?: -1
            else -> 0
        }
        val assetAmount = when {
            raw.has("assetAmount") -> raw.optInt("assetAmount", -1)
            raw.optJSONObject("exchangeRequest")?.has("assetAmount") == true ->
                raw.optJSONObject("exchangeRequest")?.optInt("assetAmount", -1) ?: -1
            pointNum.toIntOrNull() != null -> pointNum.toInt()
            else -> -1
        }
        val statusParts = mutableListOf<String>()
        if (fromHistory) {
            statusParts.add("已兑换记录")
        }
        if (status.isNotBlank()) {
            statusParts.add(status)
        }
        raw.optString("exchangeTotalNum")
            .takeIf { it.isNotBlank() }
            ?.let { statusParts.add("已兑$it") }
        raw.optInt("lackPointNum", 0)
            .takeIf { it > 0 }
            ?.let { statusParts.add("安心豆不足$it") }
        val balanceNotEnough = if (beanBalance != null && assetAmount > 0) {
            assetAmount > beanBalance
        } else {
            raw.optInt("lackPointNum", 0) > 0
        }
        if (balanceNotEnough) {
            statusParts.add("安心豆不足")
        }

        val unavailable = fromHistory ||
            status.equals("WAIT_EFFECTIVE", true) ||
            status.equals("INVALID", true) ||
            status.equals("USED", true) ||
            balanceNotEnough
        val unsafeByType = showType.equals("GOODS", true) ||
            showType.equals("CASH", true) ||
            (showType.isNotBlank() && !showType.equals("OTHER", true))
        val (baseSafety, baseReason) = ExchangeSafetyRules.classify(
            cashValues = listOf(cash),
            textValues = listOf(name, showType, rightsUseLink, raw.optString("supplyType"), raw.toString()),
            defaultReason = "涉及实付、外跳或下单链路"
        )
        val paramsComplete = assetAmount > 0 && needOrder == 0
        val safety = when {
            unavailable -> ExchangeSafety.UNAVAILABLE
            unsafeByType -> ExchangeSafety.LOG_ONLY
            baseSafety == ExchangeSafety.LOG_ONLY -> ExchangeSafety.LOG_ONLY
            !paramsComplete -> ExchangeSafety.LOG_ONLY
            else -> ExchangeSafety.AUTO
        }
        val safetyReason = when {
            unavailable -> when {
                fromHistory -> "已兑换记录"
                balanceNotEnough -> "安心豆不足"
                else -> statusParts.firstOrNull().orEmpty().ifEmpty { "服务端状态不可兑换" }
            }
            unsafeByType -> "商品/现金/券类权益需手动处理"
            baseReason.isNotEmpty() -> baseReason
            !paramsComplete -> "rightsExchange 参数不完整"
            else -> ""
        }
        val effectTags = ExchangeEffectCatalog.tagsFor(ExchangeEffectCatalog.SOURCE_BEAN_RIGHT, name)
        return BeanExchangeCandidate(
            item = ExchangeItem(
                id = rightsId,
                name = name,
                cost = ExchangeCost(
                    pointText = pointNum.takeIf { it.isNotBlank() }?.let { "${it}安心豆" }.orEmpty(),
                    cashText = cash.takeIf { it.isNotBlank() && it != "0" }?.let { "${it}元" }.orEmpty()
                ),
                limit = ExchangeLimit(
                    statusText = statusParts.joinToString("、")
                ),
                safety = safety,
                safetyReason = safetyReason,
                effectTags = effectTags,
                displayMeta = ExchangeEffectCatalog.displayMeta(
                    ExchangeEffectCatalog.SOURCE_BEAN_RIGHT,
                    name,
                    safety,
                    safetyReason,
                    effectTags
                )
            ),
            rightsId = rightsId,
            assetAmount = assetAmount,
            needOrder = needOrder,
            rightsMetaSubType = rightsMetaSubType
        )
    }



    /**
     * 查询 + 自动领取贴纸
     */
    @SuppressLint("DefaultLocale")
    fun queryAndCollectStickers() {
        if (Status.hasFlagToday(StatusFlags.FLAG_ANTMEMBER_STICKERS_DONE)) {
            Log.member("账单贴纸今日已处理，跳过重复扫描")
            return
        }
        try {
            val now = Date()
            val year = SimpleDateFormat("yyyy", Locale.ENGLISH).format(now)
            val month = SimpleDateFormat("MM", Locale.ENGLISH).format(now)
            val day = SimpleDateFormat("dd", Locale.ENGLISH).format(now)

            val queryResp = AntMemberRpcCall.queryStickerCanReceiveList(year, month)

            val queryJson = JSONObject(queryResp)
            if (!ResChecker.checkRes(TAG, queryJson)) {
                logStickerRpcFailure("查询可领取列表", queryJson)
                return
            }

            val canReceivePageList = queryJson.optJSONArray("canReceivePageList") ?: JSONArray()

            // 用于存储 ID -> Name 的映射
            val stickerNameMap = mutableMapOf<String, String>()
            val stickerConfigIdMap = mutableMapOf<String, String>()
            val allStickerIds = mutableListOf<String>()

            for (i in 0 until canReceivePageList.length()) {
                val page = canReceivePageList.optJSONObject(i)
                val stickerList = page?.optJSONArray("stickerCanReceiveList") ?: continue
                for (j in 0 until stickerList.length()) {
                    val stickerObj = stickerList.optJSONObject(j) ?: continue
                    val id = stickerObj.optString("id")
                    val name = stickerObj.optString("name")
                    if (id.isNotEmpty()) {
                        allStickerIds.add(id)
                        stickerNameMap[id] = name.ifEmpty { "未知贴纸" }
                        stickerConfigIdMap[id] = stickerObj.optString("stickerConfigId")
                    }
                }
            }

            var receivedSticker = false
            if (allStickerIds.isEmpty()) {
                Log.member("贴纸扫描：暂无可领取的贴纸")
            } else {
                // 2. 领取阶段
                val collectResp = AntMemberRpcCall.receiveSticker(
                    year,
                    month,
                    allStickerIds,
                    allStickerIds.mapNotNull { stickerConfigIdMap[it]?.takeIf { configId -> configId.isNotBlank() } }
                )

                val collectJson = JSONObject(collectResp)
                if (!ResChecker.checkRes(TAG, collectJson)) {
                    logStickerRpcFailure("领取贴纸", collectJson)
                    return
                }

                // 3. 结果解析与比对输出
                val specialList = collectJson.optJSONArray("specialStickerList")
                val obtainedIds = collectJson.optJSONArray("obtainedConfigId")
                receivedSticker = (obtainedIds?.length() ?: 0) > 0 || (specialList?.length() ?: 0) > 0

                Log.member("贴纸领取成功，总数：${obtainedIds?.length() ?: 0}")

                if (specialList != null && specialList.length() > 0) {
                    for (i in 0 until specialList.length()) {
                        val special = specialList.optJSONObject(i) ?: continue

                        // 获取领取结果中的 recordId
                        val recordId = special.optString("stickerRecordId")
                        // 从我们之前的 Map 中根据 ID 找到对应的 Name
                        val stickerName = stickerNameMap[recordId] ?: "特殊贴纸"

                        val ranking = special.optString("rankingText")

                        // 仅对特殊贴纸输出会员日志，显示真实的贴纸名称
                        Log.member("获得特殊贴纸 → $stickerName ($ranking)")
                    }
                }
            }

            val followUpResult = handleStickerFollowUps(year, month, day)
            if (receivedSticker) {
                val ackJson = JSONObject(AntMemberRpcCall.ackStickerCanReceiveFirstShow())
                if (!ResChecker.checkRes(TAG, ackJson)) {
                    logStickerRpcFailure("领取后刷新确认", ackJson)
                }
            }
            if (!followUpResult.success) {
                Log.member("贴纸后续处理存在失败，保留后续重试机会")
                return
            }
            Status.setFlagToday(StatusFlags.FLAG_ANTMEMBER_STICKERS_DONE)

        } catch (e: Exception) {
            Log.printStackTrace("$TAG stickerAutoCollect err", e)
        }
    }

    private fun handleStickerFollowUps(year: String, month: String, day: String): StickerFollowUpResult {
        val upgradeResult = upgradeAndCollectStickerBenefits(year, month, day)
        val drawingResult = collectStickerDrawingPrizes()
        return StickerFollowUpResult(
            success = upgradeResult.success && drawingResult.success,
            handled = upgradeResult.handled || drawingResult.handled
        )
    }

    private fun upgradeAndCollectStickerBenefits(year: String, month: String, day: String): StickerFollowUpResult {
        var success = true
        var handled = false
        val benefitCandidates = linkedMapOf<String, String>()
        val upgradeReqList = JSONArray()

        try {
            val homeJson = JSONObject(AntMemberRpcCall.queryStickerHomePage(year, month, day))
            if (!ResChecker.checkRes(TAG, homeJson)) {
                logStickerRpcFailure("查询贴纸首页", homeJson)
                return StickerFollowUpResult(success = false)
            }

            val stickerList = homeJson.optJSONObject("commonStickerRes")
                ?.optJSONArray("stickerDetailList")
                ?: JSONArray()

            for (i in 0 until stickerList.length()) {
                val sticker = stickerList.optJSONObject(i) ?: continue
                val stickerConfigId = sticker.optString("stickerConfigId")
                if (stickerConfigId.isBlank()) continue

                val stickerName = sticker.optString("name", stickerConfigId)
                val status = sticker.optString("status")
                if (sticker.optBoolean("hasBenefit") && !"notReceived".equals(status, ignoreCase = true)) {
                    benefitCandidates[stickerConfigId] = stickerName
                }

                if ("upgradable".equals(status, ignoreCase = true)) {
                    val currentLevelCode = sticker.optJSONObject("currentLevel")
                        ?.optString("levelCode")
                        .orEmpty()
                    val upgradableLevelCode = sticker.optJSONObject("upgradableLevel")
                        ?.optString("levelCode")
                        .orEmpty()
                    if (currentLevelCode.isNotBlank() && upgradableLevelCode.isNotBlank()) {
                        upgradeReqList.put(JSONObject().apply {
                            put("currentLevelCode", currentLevelCode)
                            put("month", month)
                            put("stickerConfigId", stickerConfigId)
                            put("upgradableLevelCode", upgradableLevelCode)
                            put("year", year)
                        })
                    }
                }
            }

            if (upgradeReqList.length() > 0) {
                handled = true
                val upgradeJson = JSONObject(AntMemberRpcCall.upgradeStickerBatch(upgradeReqList))
                if (!ResChecker.checkRes(TAG, upgradeJson)) {
                    logStickerRpcFailure("贴纸升级", upgradeJson)
                    success = false
                } else {
                    val failedList = upgradeJson.optJSONArray("failStickerCfgIdList")
                    if (failedList != null && failedList.length() > 0) {
                        Log.error(TAG, "贴纸升级部分失败：$failedList")
                        success = false
                    } else {
                        Log.member("贴纸升级成功，数量：${upgradeReqList.length()}")
                    }
                }
            }

            for ((stickerConfigId, stickerName) in benefitCandidates) {
                val benefitResult = collectStickerUpgradeBenefit(year, month, stickerConfigId, stickerName)
                handled = handled || benefitResult.handled
                success = success && benefitResult.success
            }
        } catch (e: Exception) {
            Log.printStackTrace("$TAG stickerUpgradeAndBenefit err", e)
            return StickerFollowUpResult(success = false, handled = handled)
        }

        return StickerFollowUpResult(success = success, handled = handled)
    }

    private fun collectStickerUpgradeBenefit(
        year: String,
        month: String,
        stickerConfigId: String,
        stickerName: String
    ): StickerFollowUpResult {
        try {
            val detailJson = JSONObject(AntMemberRpcCall.queryStickerDetailPage(year, month, stickerConfigId))
            if (!ResChecker.checkRes(TAG, detailJson)) {
                logStickerRpcFailure("查询权益详情[$stickerName]", detailJson)
                return StickerFollowUpResult(success = false)
            }

            if (!hasReceivableStickerUpgradeBenefit(detailJson)) {
                return StickerFollowUpResult()
            }

            val triggerJson = JSONObject(AntMemberRpcCall.triggerStickerUpgradePrize(stickerConfigId))
            if (!ResChecker.checkRes(TAG, triggerJson)) {
                logStickerRpcFailure("领取升级权益[$stickerName]", triggerJson)
                return StickerFollowUpResult(success = false, handled = true)
            }

            logStickerPrizeResults("贴纸权益[$stickerName]", triggerJson)
            return StickerFollowUpResult(handled = true)
        } catch (e: Exception) {
            Log.printStackTrace("$TAG collectStickerUpgradeBenefit err", e)
            return StickerFollowUpResult(success = false)
        }
    }

    private fun hasReceivableStickerUpgradeBenefit(detailJson: JSONObject): Boolean {
        val detailList = detailJson.optJSONObject("stickerDetailRes")
            ?.optJSONArray("stickerDetailList")
            ?: return false
        for (i in 0 until detailList.length()) {
            val benefitStatus = detailList.optJSONObject(i)
                ?.optJSONObject("upgradeBenefitModel")
                ?.optString("status")
                .orEmpty()
            if ("can_receive".equals(benefitStatus, ignoreCase = true)) {
                return true
            }
        }
        return false
    }

    private fun collectStickerDrawingPrizes(): StickerFollowUpResult {
        var success = true
        var handled = false
        try {
            val prizeHomeJson = JSONObject(AntMemberRpcCall.queryStickerPrizeHomePage())
            if (!ResChecker.checkRes(TAG, prizeHomeJson)) {
                logStickerRpcFailure("查询抽奖机会", prizeHomeJson)
                return StickerFollowUpResult(success = false)
            }

            val prizeConsumerIdList = prizeHomeJson.optJSONArray("prizeConsumerIdList") ?: return StickerFollowUpResult()
            if (prizeConsumerIdList.length() == 0) {
                return StickerFollowUpResult()
            }

            Log.member("贴纸抽奖机会：${prizeConsumerIdList.length()}次")
            for (i in 0 until prizeConsumerIdList.length()) {
                val prizeQuotaRecordId = prizeConsumerIdList.optString(i)
                if (prizeQuotaRecordId.isBlank()) continue

                handled = true
                val drawJson = JSONObject(AntMemberRpcCall.triggerStickerDrawing(prizeQuotaRecordId))
                if (!ResChecker.checkRes(TAG, drawJson)) {
                    logStickerRpcFailure("抽奖[$prizeQuotaRecordId]", drawJson)
                    success = false
                    continue
                }
                logStickerPrizeResults("贴纸抽奖", drawJson)
            }
        } catch (e: Exception) {
            Log.printStackTrace("$TAG collectStickerDrawingPrizes err", e)
            return StickerFollowUpResult(success = false, handled = handled)
        }

        return StickerFollowUpResult(success = success, handled = handled)
    }

    private fun logStickerRpcFailure(scene: String, response: JSONObject) {
        val code = response.optString("resultCode").ifBlank {
            response.optString("code").ifBlank {
                response.optString("errorCode")
            }
        }
        val message = response.optString("message").ifBlank {
            response.optString("resultDesc").ifBlank {
                response.optString("memo").ifBlank {
                    response.optString("errorMsg").ifBlank {
                        response.optString("resultView")
                    }
                }
            }
        }
        val combined = "$code $message ${response.optString("desc")}"
        val failureType = when {
            containsAny(combined, "已领取", "重复", "已兑换", "已经抽过") ->
                StickerRpcFailureType.DUPLICATE_REWARD

            containsAny(combined, "上限", "频繁", "手速", "稍后", "库存不足", "名额", "资格", "机会不足", "额度不足", "活动太火爆") ->
                StickerRpcFailureType.BUSINESS_LIMIT

            else -> StickerRpcFailureType.NON_RETRYABLE
        }
        val label = when (failureType) {
            StickerRpcFailureType.BUSINESS_LIMIT -> "业务受限"
            StickerRpcFailureType.DUPLICATE_REWARD -> "重复领取"
            StickerRpcFailureType.NON_RETRYABLE -> "接口失败"
        }
        val detail = when {
            code.isNotBlank() && message.isNotBlank() -> "$code/$message"
            code.isNotBlank() -> code
            message.isNotBlank() -> message
            else -> response.toString()
        }
        Log.error(TAG, "贴纸[$scene]#$label:$detail")
    }

    private fun containsAny(value: String, vararg keywords: String): Boolean {
        return keywords.any { value.contains(it, ignoreCase = true) }
    }

    private fun logStickerPrizeResults(scene: String, prizeJson: JSONObject) {
        val prizeResultList = prizeJson.optJSONArray("prizeResultList")
        if (prizeResultList != null && prizeResultList.length() > 0) {
            for (i in 0 until prizeResultList.length()) {
                val prize = prizeResultList.optJSONObject(i) ?: continue
                if (!ResChecker.checkRes(TAG, prize)) {
                    logStickerRpcFailure("$scene 部分奖励", prize)
                    continue
                }
                Log.member("$scene#${resolveStickerPrizeName(prize)}")
            }
            return
        }

        Log.member("$scene#${resolveStickerPrizeName(prizeJson)}")
    }

    private fun resolveStickerPrizeName(prize: JSONObject): String {
        val couponPrize = prize.optJSONObject("couponPrizeRes")
        if (couponPrize != null) {
            val price = couponPrize.optString("price")
            val unit = couponPrize.optString("unit")
            val name = couponPrize.optString("name", couponPrize.optString("title", "优惠券"))
            val condition = couponPrize.optString("condition")
            return buildString {
                if (price.isNotBlank() && unit.isNotBlank() && !name.contains(price)) {
                    append(price).append(unit)
                }
                append(name)
                if (condition.isNotBlank()) {
                    append(" ").append(condition)
                }
            }
        }

        val virtualPrize = prize.optJSONObject("virtualPrizeRes")
        if (virtualPrize != null) {
            val title = virtualPrize.optString("title", "虚拟奖励")
            val count = virtualPrize.optString("count")
            val unit = virtualPrize.optString("unit")
            return buildString {
                append(title)
                if (count.isNotBlank()) {
                    append("*").append(count)
                    if (unit.isNotBlank()) {
                        append(unit)
                    }
                }
            }
        }

        return prize.optString("prizeId", "未知奖励")
    }

    companion object {
        internal const val PERSISTENT_FLOATING_BALL_KIND = "ANT_MEMBER_FLOATING_BALL"
        private val TAG: String = AntMember::class.java.getSimpleName()
        private const val memberTaskBlacklistModule = "会员"
        private const val insuredTaskBlacklistModule = "蚂蚁保"
        private const val memberFloatingBallAdTaskTitle = "会员浮球广告浏览任务"
        private const val MERCHANT_EXAM_TASK_CODE = "JYMWDDJF_TASK"
        private const val MERCHANT_EXAM_PRODUCE_CHANNEL = "GW_MRCHSERVEBASE_DEFAULT"
        private const val MERCHANT_UNCLOSED_AD_TASK_CODE = "SYH_RTB_SHOW_TASK_INDEX_1"
        private const val INSURED_GOLD_WAIT_LIST_QUERY_LIMIT = 3
        private const val MEMBER_CALL_APP_VERIFY_RETRY_LIMIT = 5
        private const val BEAN_DRAW_PLAN_ID = "INSP29990111"


        /**
         * 会员积分收取
         * @param page 第几页
         * @param pageSize 每页数据条数
         */
        internal suspend fun queryPointCert(page: Int, pageSize: Int) {
            try {
                var s = AntMemberRpcCall.queryPointCertV2(page, pageSize)
                var jo = JSONObject(s)
                if (isMemberMarketingRpcRisk("AntMember.memberPoint.queryV2", jo)) {
                    return
                }
                if (ResChecker.checkRes(TAG, "查询会员积分证书失败:", jo) && jo.has("pointToClaim")) {
                    val pointToClaim = jo.optInt("pointToClaim", 0)
                    if (pointToClaim > 0 && jo.optBoolean("showReceiveAllPointFunction")) {
                        s = AntMemberRpcCall.receiveAllPointByUser()
                        val receiveAllObject = JSONObject(s)
                        if (isMemberMarketingRpcRisk("AntMember.memberPoint.receiveAll", receiveAllObject)) {
                            return
                        }
                        val receiveAllSuccess = ResChecker.checkRes(TAG, "会员积分一键领取失败:", receiveAllObject)
                        if (receiveAllSuccess) {
                            val receiveSumPoint = receiveAllObject.optInt("receiveSumPoint", 0)
                            val receiveStatus = receiveAllObject.optString("receiveStatus")
                            if ("SUCCESS" == receiveStatus || receiveSumPoint > 0) {
                                Log.member("会员积分🎖️[一键领取]#${receiveSumPoint}积分")
                                return
                            }
                            if ("DOING" == receiveStatus) {
                                Log.member("会员积分🎖️[一键领取处理中，不等待轮询，回退逐条领取]#receiveStatus=$receiveStatus")
                            } else {
                                Log.member("会员积分🎖️[一键领取未确认成功，回退逐条领取]#receiveStatus=$receiveStatus")
                            }
                        }
                        if (!receiveAllSuccess) {
                            Log.member("会员积分🎖️[一键领取失败，回退逐条领取]")
                        }
                    }
                    claimMemberPointCertList(jo, page, pageSize)
                    return
                }

                s = AntMemberRpcCall.queryPointCert(page, pageSize)
                jo = JSONObject(s)
                if (isMemberMarketingRpcRisk("AntMember.memberPoint.query", jo)) {
                    return
                }
                if (ResChecker.checkRes(TAG, "查询会员积分证书失败:", jo)) {
                    claimMemberPointCertList(jo, page, pageSize)
                } else {
                    Log.member(jo.getString("resultDesc"))
                    Log.member(s)
                }
            } catch (t: Throwable) {
                Log.printStackTrace(TAG, "queryPointCert err:", t)
            }
        }

        private suspend fun claimMemberPointCertList(queryObject: JSONObject, page: Int, pageSize: Int) {
            val hasNextPage = queryObject.optBoolean("hasNextPage")
            val certList = queryObject.optJSONArray("certList") ?: JSONArray()
            for (i in 0 until certList.length()) {
                val certObject = certList.getJSONObject(i)
                val bizTitle = certObject.optString("bizTitle").ifEmpty {
                    certObject.optString("title", "会员积分")
                }
                val id = certObject.optString("id").ifEmpty { certObject.optString("certId") }
                if (id.isEmpty()) {
                    continue
                }
                val pointAmount = certObject.optInt("pointAmount", certObject.optInt("point", 0))
                val response = AntMemberRpcCall.receivePointByUser(id)
                val receiveObject = JSONObject(response)
                if (isMemberMarketingRpcRisk("AntMember.memberPoint.receive", receiveObject)) {
                    return
                }
                if (ResChecker.checkRes(TAG, "会员积分领取失败:", receiveObject)) {
                    Log.member("会员积分🎖️[领取$bizTitle]#${pointAmount}积分")
                } else {
                    Log.member(receiveObject.optString("resultDesc"))
                    Log.member(response)
                }
            }
            if (hasNextPage) {
                queryPointCert(page + 1, pageSize)
            }
        }


        /**
         * 商家开门打卡签到
         */
        private fun kmdkSignIn(): Boolean = CoroutineUtils.run {
            try {
                val s = AntMemberRpcCall.queryActivity()
                val jo = JSONObject(s)
                if (isMemberMarketingRpcRisk("AntMember.merchant.queryActivity", jo)) {
                    return@run false
                }
                if (!ResChecker.checkRes(TAG, jo)) {
                    Log.member("queryActivity $s")
                    return@run false
                }

                when (jo.optString("signInStatus")) {
                    "SIGN_IN_ENABLE" -> {
                        val activityNo = jo.optString("activityNo")
                        if (activityNo.isEmpty()) return@run false
                        val joSignIn = JSONObject(AntMemberRpcCall.signIn(activityNo))
                        if (isMemberMarketingRpcRisk("AntMember.merchant.kmdkSignIn", joSignIn)) {
                            return@run false
                        }
                        if (ResChecker.checkRes(TAG, joSignIn)) {
                            Log.member("商家服务🏬[开门打卡签到成功]")
                            return@run true
                        }
                        Log.member(joSignIn.optString("errorMsg"))
                        Log.member(joSignIn.toString())
                        return@run false
                    }

                    "SIGN_IN_DISABLE" -> return@run true // 通常表示已签到
                }
            } catch (t: Throwable) {
                Log.printStackTrace(TAG, "kmdkSignIn err:", t)
            }
            false
        }

        /**
         * 商家开门打卡报名
         */
        private suspend fun kmdkSignUp(): Boolean = CoroutineUtils.run {
            try {
                for (i in 0..4) {
                    val jo = JSONObject(AntMemberRpcCall.queryActivity())
                    if (isMemberMarketingRpcRisk("AntMember.merchant.queryActivity", jo)) {
                        return@run false
                    }
                    if (ResChecker.checkRes(TAG, jo)) {
                        val activityNo = jo.optString("activityNo")
                        if (activityNo.isEmpty()) {
                            continue
                        }
                        if (TimeUtil.getFormatDate().replace("-", "") != activityNo.split("_".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()[2]) {
                            break
                        }
                        if ("SIGN_UP" == jo.getString("signUpStatus")) {
                            return@run true
                        }
                        if ("UN_SIGN_UP" == jo.getString("signUpStatus")) {
                            val activityPeriodName = jo.getString("activityPeriodName")
                            val joSignUp = JSONObject(AntMemberRpcCall.signUp(activityNo))
                            if (isMemberMarketingRpcRisk("AntMember.merchant.kmdkSignUp", joSignUp)) {
                                return@run false
                            }
                            if (ResChecker.checkRes(TAG, joSignUp)) {
                                Log.member("商家服务🏬[" + activityPeriodName + "开门打卡报名]")
                                return@run true
                            } else {
                                Log.member(joSignUp.getString("errorMsg"))
                                Log.member(joSignUp.toString())
                            }
                        }
                    } else {
                        Log.member("queryActivity")
                        Log.member(jo.toString())
                    }
                }
            } catch (t: Throwable) {
                Log.printStackTrace(TAG, "kmdkSignUp err:", t)
            }
            false
        }

        /**
         * 商家积分签到
         */
        private fun doMerchantSign(): Boolean = CoroutineUtils.run {
            var handled = false
            try {
                if (doMerchantZcjSignIn()) {
                    handled = true
                }
                val homeBeforeSign = queryMerchantHomePage("签到前")
                val signInAvailable = homeBeforeSign?.optJSONObject("data")
                    ?.takeIf { it.has("signIn") }
                    ?.optBoolean("signIn", false)
                if (signInAvailable == false) {
                    Log.member("商家服务🏬[每日签到]#首页未显示可签到，今日按已处理")
                    return@run true
                }
                val s = AntMemberRpcCall.merchantSign()
                var jo = JSONObject(s)
                if (isMemberMarketingRpcRisk("AntMember.merchant.sign", jo)) {
                    return@run handled
                }
                if (!ResChecker.checkRes(TAG, jo)) {
                    if (!handled) {
                        Log.member("doMerchantSign err:$s")
                    }
                    return@run handled
                }
                jo = jo.getJSONObject("data")
                val signResult = jo.optString("signInResult")
                val reward = jo.optString("todayReward")
                if ("SUCCESS" == signResult || "SIGNINED" == signResult) {
                    queryMerchantHomePage("签到后")
                    Log.member("商家服务🏬[每日签到]#获得积分$reward")
                    return@run true
                } else {
                    val homeAfterSign = queryMerchantHomePage("签到后")
                    val signInStillAvailable = homeAfterSign?.optJSONObject("data")
                        ?.takeIf { it.has("signIn") }
                        ?.optBoolean("signIn")
                    if (signInStillAvailable == false) {
                        Log.member("商家服务🏬[每日签到]#服务端确认今日不可重复签到(signInResult=$signResult)")
                        return@run true
                    }
                    Log.error(
                        "AntMember",
                        "商家服务🏬[每日签到] classification=UNKNOWN_NEEDS_REVIEW " +
                            "签到结果未确认 signInResult=$signResult signInStillAvailable=$signInStillAvailable raw=$s",
                    )
                    return@run false
                }
            } catch (t: Throwable) {
                Log.printStackTrace(TAG, "kmdkSignIn err:", t)
            }
            handled
        }

        private fun queryMerchantHomePage(scene: String): JSONObject? = CoroutineUtils.run {
            try {
                val response = JSONObject(AntMemberRpcCall.merchantHomePage())
                if (isMemberMarketingRpcRisk("AntMember.merchant.homePage", response)) {
                    return@run null
                }
                val evaluation = evaluateMerchantRpc(response)
                if (!evaluation.success) {
                    logMerchantRpcFailure("首页回查[$scene]", response, evaluation)
                    return@run null
                }
                return@run response
            } catch (t: Throwable) {
                Log.printStackTrace(TAG, "queryMerchantHomePage err:", t)
            }
            null
        }

        /**
         * 商家积分任务
         */
        private suspend fun doMerchantMoreTask(): Unit = CoroutineUtils.run {
            try {
                val adapter = MerchantTaskFlowAdapter()
                TaskFlowEngine(adapter, roundSleepMs = 425L).run()
                if (adapter.taskListObserved && adapter.taskCount == 0) {
                    Log.member("商家服务🏬[积分任务]#未查询到任务列表")
                }
                if ((adapter.querySucceeded && adapter.taskListObserved && adapter.taskCount == 0) ||
                    adapter.canMarkTodayDone()
                ) {
                    setFlagToday(StatusFlags.FLAG_ANTMEMBER_MERCHANT_MORE_TASK_DONE)
                }
                collectMerchantPointBalls()
            } catch (t: Throwable) {
                Log.printStackTrace(TAG, "merchantTaskFlow err:", t)
            }
        }

        private class MerchantTaskFlowAdapter : TaskFlowAdapter {
            override val moduleName: String = memberTaskBlacklistModule
            override val flowName: String = "商家服务🏬积分任务"

            private data class MerchantTaskGroupSnapshot(
                val group: String,
                val tasks: JSONArray
            )

            private data class MerchantTaskSnapshotQuery(
                val success: Boolean,
                val groups: List<MerchantTaskGroupSnapshot> = emptyList(),
                val moreOrderTaskCode: String = "",
                val failureRpc: String = "",
                val failureResponse: JSONObject = JSONObject(),
                val failureEvaluation: MerchantRpcEvaluation? = null
            )

            var taskCount: Int = 0
                private set
            var querySucceeded: Boolean = false
                private set
            var taskListObserved: Boolean = false
                private set
            private var latestItems: List<TaskFlowItem> = emptyList()
            private var unknownPhaseSeen: Boolean = false
            private var unknownFailureSeen: Boolean = false

            private var moreOrderTaskCode: String = ""
            private val loggedSkipKeys = LinkedHashSet<String>()

            override fun query(): JSONObject {
                return try {
                    val snapshot = queryMerchantTaskSnapshot()
                    moreOrderTaskCode = snapshot.moreOrderTaskCode
                    if (!snapshot.success) {
                        return try {
                            JSONObject(snapshot.failureResponse.toString())
                                .put("_taskFlowQuerySuccess", false)
                                .put("_merchantMoreOrderTaskCode", moreOrderTaskCode)
                        } catch (_: Throwable) {
                            JSONObject()
                                .put("_taskFlowQuerySuccess", false)
                                .put("_merchantMoreOrderTaskCode", moreOrderTaskCode)
                                .put("resultDesc", "查询失败")
                        }
                    }
                    val groups = JSONArray()
                    snapshot.groups.forEach { group ->
                        groups.put(
                            JSONObject().apply {
                                put("group", group.group)
                                put("tasks", group.tasks)
                            }
                        )
                    }
                    JSONObject()
                        .put("_taskFlowQuerySuccess", true)
                        .put("_merchantMoreOrderTaskCode", moreOrderTaskCode)
                        .put("_merchantTaskGroups", groups)
                } catch (t: Throwable) {
                    JSONObject()
                        .put("_taskFlowQuerySuccess", false)
                        .put("resultDesc", "查询异常:${t.message}")
                }
            }

            override fun isQuerySuccess(response: JSONObject): Boolean {
                querySucceeded = response.optBoolean("_taskFlowQuerySuccess", false)
                return querySucceeded
            }

            override fun extractItems(response: JSONObject): List<TaskFlowItem> {
                val groupArray = response.optJSONArray("_merchantTaskGroups") ?: JSONArray()
                taskListObserved = response.has("_merchantTaskGroups")
                val mergedMoreOrderTaskCode = response.optString("_merchantMoreOrderTaskCode")
                val items = mutableListOf<TaskFlowItem>()
                var totalTaskCount = 0
                for (groupIndex in 0 until groupArray.length()) {
                    val group = groupArray.optJSONObject(groupIndex) ?: continue
                    val groupName = group.optString("group")
                    val taskList = group.optJSONArray("tasks") ?: continue
                    totalTaskCount += taskList.length()
                    for (i in 0 until taskList.length()) {
                        val task = taskList.optJSONObject(i) ?: continue
                        task.put("_merchant_group", groupName)
                        task.put("_merchant_more_order_task_code", mergedMoreOrderTaskCode)
                        val taskCode = task.optString("taskCode")
                        val title = task.optString("title", task.optString("taskName", "商家任务"))
                        val status = task.optString("status")
                        val current = extractMerchantTaskCurrent(task)
                        val limit = extractMerchantTaskLimit(task)
                        items.add(
                            TaskFlowItem(
                                id = taskCode.ifBlank { task.optString("pointBallId").ifBlank { title } },
                                title = title,
                                status = status,
                                type = taskCode,
                                actionType = resolveMerchantActionCodes(task).joinToString("|"),
                                blacklistKeys = listOf(taskCode, title).filter { it.isNotBlank() },
                                raw = task,
                                progress = buildMerchantTaskProgress(task, current, limit),
                                current = current,
                                limit = limit
                            )
                        )
                    }
                }
                taskCount = totalTaskCount
                latestItems = items
                return items
            }

            override fun mapPhase(item: TaskFlowItem): TaskFlowPhase {
                val rawTask = item.raw ?: JSONObject()
                val normalizedStatus = item.status.uppercase(Locale.ROOT)
                if (isMerchantRewardReadyStatus(rawTask, normalizedStatus)) {
                    return TaskFlowPhase.REWARD_READY
                }
                return when (normalizedStatus) {
                    "PROCESSING",
                    "PROCESS",
                    "WAIT_COMPLETE",
                    "EXCHANGE_PENDING" -> TaskFlowPhase.READY_TO_COMPLETE
                    "UNRECEIVED" -> TaskFlowPhase.SIGNUP_REQUIRED
                    "RECEIVED",
                    "DONE",
                    "FINISHED",
                    "COMPLETE",
                    "SUCCESS" -> TaskFlowPhase.TERMINAL
                    else -> TaskFlowPhase.UNKNOWN
                }
            }

            override fun shouldSkip(item: TaskFlowItem): Boolean {
                val phase = mapPhase(item)
                val raw = item.raw ?: JSONObject()
                if (item.type == MERCHANT_UNCLOSED_AD_TASK_CODE && isBlacklisted(item)) {
                    return true
                }
                if (phase == TaskFlowPhase.REWARD_READY &&
                    raw.optString("pointBallId").isBlank() &&
                    resolveMerchantBizId(raw).isBlank()
                ) {
                    logSkipOnce(item, "缺少可领取pointBallId/bizId，跳过")
                    return true
                }
                if ((phase == TaskFlowPhase.SIGNUP_REQUIRED || phase == TaskFlowPhase.READY_TO_COMPLETE) &&
                    item.type.isBlank()
                ) {
                    logSkipOnce(item, "缺少taskCode，跳过")
                    return true
                }
                if (phase == TaskFlowPhase.READY_TO_COMPLETE &&
                    item.actionType.isBlank() &&
                    item.type != MERCHANT_EXAM_TASK_CODE
                ) {
                    logSkipOnce(item, "缺少actionCode，跳过")
                    return true
                }
                return false
            }

            override fun isUnresolvedWhenSkipped(item: TaskFlowItem): Boolean =
                isMerchantCompletionPendingStatus(item.raw ?: JSONObject(), item.status)

            override fun isBlacklisted(item: TaskFlowItem): Boolean {
                val blacklisted = super<TaskFlowAdapter>.isBlacklisted(item)
                if (blacklisted) {
                    logSkipOnce(item, "任务在自动跳过列表(黑名单)中，跳过")
                }
                return blacklisted
            }

            override fun receive(item: TaskFlowItem): TaskFlowActionResult {
                val task = item.raw ?: JSONObject()
                val pointBallId = task.optString("pointBallId")
                if (pointBallId.isNotBlank()) {
                    return receiveMerchantPointBallResult(pointBallId, item.title, task.optString("reward", task.optString("point")))
                }
                val bizId = resolveMerchantBizId(task)
                if (bizId.isBlank()) {
                    return TaskFlowActionResult.failure(
                        failureType = TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW,
                        code = "MERCHANT_RECEIVE_ID_MISSING",
                        message = "缺少pointBallId/bizId",
                        rpc = "AntMemberRpcCall.ballReceive/taskFinish",
                        detail = merchantTaskActionDetail(item, "receive")
                    )
                }
                val response = JSONObject(AntMemberRpcCall.taskFinish(bizId))
                val evaluation = evaluateMerchantRpc(response)
                if (!evaluation.success) {
                    return merchantTaskFailureResult(item, "AntMemberRpcCall.taskFinish", response, evaluation)
                }
                Log.member("商家服务🏬[${item.title}]#领取积分${task.optString("reward", task.optString("point"))}")
                return TaskFlowActionResult.success(refreshAfterAction = true)
            }

            override fun signup(item: TaskFlowItem): TaskFlowActionResult {
                val response = JSONObject(AntMemberRpcCall.taskReceive(item.type))
                val evaluation = evaluateMerchantRpc(response)
                if (!evaluation.success) {
                    return merchantTaskFailureResult(item, "AntMemberRpcCall.taskReceive", response, evaluation)
                }
                Log.member("商家服务🏬[${item.title}]#领取任务")
                return TaskFlowActionResult.success(refreshAfterAction = true)
            }

            override fun complete(item: TaskFlowItem): TaskFlowActionResult {
                if (item.type == MERCHANT_EXAM_TASK_CODE) {
                    return completeMerchantExamTask(item)
                }
                val actionCodes = item.actionType.split("|")
                    .map { it.trim() }
                    .filter { it.isNotEmpty() }
                var lastFailure: TaskFlowActionResult? = null
                actionLoop@ for (actionCode in actionCodes) {
                    val queryActivity = JSONObject(AntMemberRpcCall.actioncode(actionCode))
                    val queryEvaluation = evaluateMerchantRpc(queryActivity)
                    if (!queryEvaluation.success) {
                        val failure = merchantTaskFailureResult(
                            item,
                            "AntMemberRpcCall.actioncode",
                            queryActivity,
                            queryEvaluation,
                            actionCode
                        )
                        lastFailure = failure
                        if (queryEvaluation.failureType == MerchantRpcFailureType.NO_ACTIVITY) {
                            logMerchantRpcFailure("查询任务活动[${item.title}/$actionCode]", queryActivity, queryEvaluation)
                            continue
                        }
                        if (failure.failureType == TaskRpcFailureType.RETRYABLE_RPC ||
                            failure.failureType == TaskRpcFailureType.BUSINESS_LIMIT
                        ) {
                            return failure
                        }
                        continue
                    }

                    val produce = JSONObject(AntMemberRpcCall.produce(actionCode))
                    val produceEvaluation = evaluateMerchantRpc(produce)
                    if (!produceEvaluation.success) {
                        val failure = merchantTaskFailureResult(
                            item,
                            "AntMemberRpcCall.produce",
                            produce,
                            produceEvaluation,
                            actionCode
                        )
                        lastFailure = failure
                        if (produceEvaluation.failureType == MerchantRpcFailureType.NO_ACTIVITY) {
                            logMerchantRpcFailure("完成任务[${item.title}/$actionCode]", produce, produceEvaluation)
                            continue@actionLoop
                        }
                        if (failure.failureType == TaskRpcFailureType.RETRYABLE_RPC ||
                            failure.failureType == TaskRpcFailureType.BUSINESS_LIMIT
                        ) {
                            return failure
                        }
                        continue
                    }
                    return confirmMerchantCompletionProgress(item, actionCode)
                }
                return lastFailure ?: TaskFlowActionResult.failure(
                    failureType = TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW,
                    code = "MERCHANT_ACTION_CODE_MISSING",
                    message = "没有可执行actionCode",
                    rpc = "AntMemberRpcCall.actioncode",
                    detail = merchantTaskActionDetail(item, "complete")
                )
            }

            private fun completeMerchantExamTask(item: TaskFlowItem): TaskFlowActionResult {
                val examPage = JSONObject(AntMemberRpcCall.merchantExamPage(item.type))
                val examEvaluation = evaluateMerchantRpc(examPage)
                if (!examEvaluation.success) {
                    return merchantTaskFailureResult(
                        item,
                        "AntMemberRpcCall.merchantExamPage",
                        examPage,
                        examEvaluation,
                        item.type
                    )
                }

                val data = examPage.optJSONObject("data")
                if (data == null || !data.optBoolean("available", false)) {
                    return TaskFlowActionResult.failure(
                        failureType = TaskRpcFailureType.BUSINESS_LIMIT,
                        code = "MERCHANT_EXAM_UNAVAILABLE",
                        message = "答题任务当前不可用",
                        rpc = "AntMemberRpcCall.merchantExamPage",
                        raw = examPage.toString(),
                        detail = merchantTaskActionDetail(item, "examPage")
                    )
                }

                val actionCode = data.optString("actionCode").trim()
                if (actionCode.isEmpty()) {
                    return TaskFlowActionResult.failure(
                        failureType = TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW,
                        code = "MERCHANT_EXAM_ACTION_MISSING",
                        message = "答题任务缺少actionCode",
                        rpc = "AntMemberRpcCall.merchantExamPage",
                        raw = examPage.toString(),
                        detail = merchantTaskActionDetail(item, "examPage")
                    )
                }

                val produce = JSONObject(AntMemberRpcCall.produce(actionCode, MERCHANT_EXAM_PRODUCE_CHANNEL))
                val produceEvaluation = evaluateMerchantRpc(produce)
                if (!produceEvaluation.success) {
                    return merchantTaskFailureResult(
                        item,
                        "AntMemberRpcCall.produce",
                        produce,
                        produceEvaluation,
                        actionCode
                    )
                }

                return confirmMerchantCompletionProgress(item, actionCode)
            }

            override fun actionKey(item: TaskFlowItem, action: TaskFlowAction): String {
                return "${action.logName}:${buildMerchantTaskFlowKey(item)}:${item.status}:${item.progress}"
            }

            override fun afterFailure(
                item: TaskFlowItem,
                action: TaskFlowAction,
                result: TaskFlowActionResult,
                decision: TaskFlowDecision
            ) {
                if (result.failureType == TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW) {
                    unknownFailureSeen = true
                }
            }

            override fun onAllTasksDone(snapshot: TaskFlowSnapshot) {
                logInfo("商家服务🏬[积分任务已处理完成：${snapshot.completedTasks}/${snapshot.totalTasks}]")
            }

            override fun onQueryFailed(response: JSONObject) {
                val evaluation = evaluateMerchantRpc(response)
                logMerchantRpcFailure("积分任务列表", response, evaluation)
            }

            override fun onUnknownPhase(item: TaskFlowItem, phase: TaskFlowPhase) {
                unknownPhaseSeen = true
                Log.member(
                    "商家服务🏬[${item.title}]#未知任务状态，跳过 " +
                        "taskCode=${item.type.ifBlank { "UNKNOWN" }} status=${item.status.ifBlank { "UNKNOWN" }} raw=${item.raw}"
                )
            }

            override fun logInfo(message: String) {
                Log.member(message)
            }

            override fun logError(message: String) {
                Log.error(TAG, message)
            }

            fun canMarkTodayDone(): Boolean {
                if (!querySucceeded || !taskListObserved || unknownPhaseSeen || unknownFailureSeen) {
                    return false
                }
                for (item in latestItems) {
                    val phase = mapPhase(item)
                    if (phase == TaskFlowPhase.UNKNOWN) {
                        return false
                    }
                    if (phase == TaskFlowPhase.TERMINAL) {
                        continue
                    }
                    if (shouldSkip(item)) {
                        continue
                    }
                    if (phase == TaskFlowPhase.REWARD_READY) {
                        return false
                    }
                    if (super<TaskFlowAdapter>.isBlacklisted(item)) {
                        continue
                    }
                    return false
                }
                return true
            }

            private fun queryMerchantTaskSnapshot(): MerchantTaskSnapshotQuery {
                val currentMoreOrderTaskCode = moreOrderTaskCode

                val moreResponse = JSONObject(AntMemberRpcCall.taskMoreQuery(currentMoreOrderTaskCode))
                val moreEvaluation = evaluateMerchantRpc(moreResponse)
                if (!moreEvaluation.success) {
                    return MerchantTaskSnapshotQuery(
                        success = false,
                        moreOrderTaskCode = currentMoreOrderTaskCode,
                        failureRpc = "AntMemberRpcCall.taskMoreQuery",
                        failureResponse = moreResponse,
                        failureEvaluation = moreEvaluation
                    )
                }

                val nextMoreOrderTaskCode = moreResponse.optJSONObject("data")?.optString("orderTaskCode").orEmpty()
                val serviceResponse = JSONObject(AntMemberRpcCall.taskServiceQuery())
                val serviceEvaluation = evaluateMerchantRpc(serviceResponse)
                if (!serviceEvaluation.success) {
                    return MerchantTaskSnapshotQuery(
                        success = false,
                        moreOrderTaskCode = nextMoreOrderTaskCode,
                        failureRpc = "AntMemberRpcCall.taskServiceQuery",
                        failureResponse = serviceResponse,
                        failureEvaluation = serviceEvaluation
                    )
                }

                val groups = mutableListOf<MerchantTaskGroupSnapshot>()
                buildMerchantTaskGroupSnapshot(moreResponse, "MORE", nextMoreOrderTaskCode)?.let(groups::add)
                buildMerchantTaskGroupSnapshot(serviceResponse, "SERVICE", nextMoreOrderTaskCode)?.let(groups::add)
                return MerchantTaskSnapshotQuery(
                    success = true,
                    groups = groups,
                    moreOrderTaskCode = nextMoreOrderTaskCode
                )
            }

            private fun buildMerchantTaskGroupSnapshot(
                response: JSONObject,
                expectedGroup: String,
                nextMoreOrderTaskCode: String
            ): MerchantTaskGroupSnapshot? {
                val data = response.optJSONObject("data") ?: return null
                val planCode = data.optString("planCode")
                if (planCode.isNotBlank() && !planCode.equals(expectedGroup, true)) {
                    return null
                }
                val taskList = data.optJSONArray("taskList") ?: return null
                if (taskList.length() <= 0) {
                    return null
                }
                val tasks = JSONArray()
                for (i in 0 until taskList.length()) {
                    val task = taskList.optJSONObject(i) ?: continue
                    tasks.put(
                        JSONObject(task.toString()).apply {
                            put("_merchant_group", expectedGroup)
                            put("_merchant_more_order_task_code", nextMoreOrderTaskCode)
                        }
                    )
                }
                return MerchantTaskGroupSnapshot(
                    group = expectedGroup,
                    tasks = tasks
                )
            }

            private fun confirmMerchantCompletionProgress(item: TaskFlowItem, actionCode: String): TaskFlowActionResult {
                val snapshot = queryMerchantTaskSnapshot()
                moreOrderTaskCode = snapshot.moreOrderTaskCode
                if (!snapshot.success) {
                    return merchantTaskFailureResult(
                        item,
                        snapshot.failureRpc.ifBlank { "AntMemberRpcCall.taskMoreQuery" },
                        snapshot.failureResponse,
                        snapshot.failureEvaluation ?: evaluateMerchantRpc(snapshot.failureResponse),
                        actionCode
                    )
                }

                val currentGroup = item.raw?.optString("_merchant_group").orEmpty()
                val refreshedTask = queryMerchantTaskByCode(snapshot.groups, item.type, currentGroup)
                if (hasMerchantTaskProgressed(item.raw ?: JSONObject(), refreshedTask)) {
                    Log.member("商家服务🏬[${item.title}]#任务进度已推进")
                    val refreshedStatus = refreshedTask?.optString("status").orEmpty()
                    if (refreshedTask != null && isMerchantCompletionPendingStatus(refreshedTask, refreshedStatus)) {
                        return TaskFlowActionResult.success(refreshAfterAction = true)
                    }
                    return TaskFlowActionResult.success()
                }
                return TaskFlowActionResult.success(refreshAfterAction = true, progressChanged = false)
            }

            private fun queryMerchantTaskByCode(
                groups: List<MerchantTaskGroupSnapshot>,
                taskCode: String,
                expectedGroup: String
            ): JSONObject? {
                if (taskCode.isBlank()) {
                    return null
                }
                for (group in groups) {
                    if (expectedGroup.isNotBlank() && !group.group.equals(expectedGroup, true)) {
                        continue
                    }
                    for (i in 0 until group.tasks.length()) {
                        val task = group.tasks.optJSONObject(i) ?: continue
                        if (taskCode == task.optString("taskCode")) {
                            return task
                        }
                    }
                }
                return null
            }

            private fun hasMerchantTaskProgressed(beforeTask: JSONObject, afterTask: JSONObject?): Boolean {
                if (afterTask == null) {
                    return true
                }

                val beforeCurrent = extractMerchantTaskCurrent(beforeTask)
                val afterCurrent = extractMerchantTaskCurrent(afterTask)
                if (beforeCurrent != null && afterCurrent != null && afterCurrent > beforeCurrent) {
                    return true
                }

                val beforeStatus = beforeTask.optString("status").uppercase(Locale.ROOT)
                val afterStatus = afterTask.optString("status").uppercase(Locale.ROOT)
                if (afterStatus != beforeStatus &&
                    afterStatus in setOf("NEED_RECEIVE", "RECEIVED", "DONE", "FINISHED", "COMPLETE", "SUCCESS")
                ) {
                    return true
                }

                if (beforeTask.optString("pointBallId").isBlank() && afterTask.optString("pointBallId").isNotBlank()) {
                    return true
                }

                return resolveMerchantBizId(beforeTask).isBlank() && resolveMerchantBizId(afterTask).isNotBlank()
            }

            private fun logSkipOnce(item: TaskFlowItem, reason: String) {
                val key = "$reason|${buildMerchantTaskFlowKey(item)}"
                if (loggedSkipKeys.add(key)) {
                    Log.member("商家服务🏬[${item.title}]#$reason")
                }
            }
        }

        private fun isMerchantRewardReadyStatus(task: JSONObject, status: String = task.optString("status")): Boolean {
            return when (status.uppercase(Locale.ROOT)) {
                "NEED_RECEIVE" -> true
                "PROCESSING" -> task.optString("pointBallId").isNotBlank()
                "EXCHANGE_PENDING" -> task.optString("pointBallId").isNotBlank() ||
                    resolveMerchantBizId(task).isNotBlank()
                else -> false
            }
        }

        private fun isMerchantCompletionPendingStatus(task: JSONObject, status: String = task.optString("status")): Boolean {
            return when (status.uppercase(Locale.ROOT)) {
                "UNRECEIVED",
                "PROCESS",
                "WAIT_COMPLETE" -> true
                "PROCESSING",
                "EXCHANGE_PENDING" -> !isMerchantRewardReadyStatus(task, status)
                else -> false
            }
        }

        private enum class MerchantRpcFailureType {
            AUTH_LIMIT,
            NO_ACTIVITY,
            DUPLICATE_REWARD,
            NON_RETRYABLE
        }

        private data class MerchantRpcEvaluation(
            val success: Boolean,
            val code: String,
            val message: String,
            val failureType: MerchantRpcFailureType? = null
        )

        private fun evaluateMerchantRpc(response: JSONObject): MerchantRpcEvaluation {
            val success = response.optBoolean("success") ||
                response.optString("resultCode").equals("SUCCESS", true) ||
                response.optString("errCode") == "0"
            val code = sequenceOf(
                response.optString("errorCode"),
                response.optString("resultCode"),
                response.opt("error")?.toString(),
                response.optString("errorTip"),
                response.optString("errCode"),
                response.opt("errorNo")?.toString()
            ).firstOrNull { !it.isNullOrBlank() && it != "0" }
                .orEmpty()
            val message = sequenceOf(
                response.optString("errorMsg"),
                response.optString("errorMessage"),
                response.optString("resultDesc"),
                response.optString("memo"),
                response.optString("desc")
            ).firstOrNull { it.isNotBlank() }
                .orEmpty()
            if (success) {
                return MerchantRpcEvaluation(
                    success = true,
                    code = code,
                    message = message
                )
            }
            val failureType = when {
                message == "訪問被拒絕" ||
                    message == "访问被拒绝" -> MerchantRpcFailureType.AUTH_LIMIT

                code.equals("RESULT_IS_NULL", true) ||
                    message == "通过actionCode查询的任务活动为空" -> MerchantRpcFailureType.NO_ACTIVITY

                code == "392" ||
                    message == "任务已领取,无法重复领取" ||
                    message == "宝箱奖励已领取" -> MerchantRpcFailureType.DUPLICATE_REWARD

                else -> MerchantRpcFailureType.NON_RETRYABLE
            }
            isMemberMarketingRpcRisk("AntMember.merchant", code, message)
            return MerchantRpcEvaluation(
                success = false,
                code = code,
                message = message,
                failureType = failureType
            )
        }

        private fun buildMerchantRpcFailureDetail(evaluation: MerchantRpcEvaluation, response: JSONObject): String {
            return when {
                evaluation.code.isNotBlank() && evaluation.message.isNotBlank() -> "${evaluation.code}/${evaluation.message}"
                evaluation.code.isNotBlank() -> evaluation.code
                evaluation.message.isNotBlank() -> evaluation.message
                else -> response.toString()
            }
        }

        private fun logMerchantRpcFailure(
            scene: String,
            response: JSONObject,
            evaluation: MerchantRpcEvaluation = evaluateMerchantRpc(response)
        ) {
            val detail = buildMerchantRpcFailureDetail(evaluation, response)
            val fallbackFailureType = classifyMerchantTaskFailure(evaluation.code, evaluation.message, response)
            when (evaluation.failureType) {
                MerchantRpcFailureType.AUTH_LIMIT ->
                    Log.member("商家服务🏬[$scene]#业务受限，本轮跳过:$detail")

                MerchantRpcFailureType.NO_ACTIVITY ->
                    Log.member("商家服务🏬[$scene]#当前无可执行活动，跳过:$detail")

                MerchantRpcFailureType.DUPLICATE_REWARD ->
                    Log.member("商家服务🏬[$scene]#奖励已领取，跳过重复领取:$detail")

                MerchantRpcFailureType.NON_RETRYABLE, null -> when (fallbackFailureType) {
                    TaskRpcFailureType.TERMINAL_DONE ->
                        Log.member("商家服务🏬[$scene]#奖励已领取，跳过重复领取:$detail")

                    TaskRpcFailureType.RETRYABLE_RPC ->
                        Log.member("商家服务🏬[$scene]#接口失败待重试:$detail")

                    TaskRpcFailureType.BUSINESS_LIMIT ->
                        Log.member("商家服务🏬[$scene]#业务受限，本轮跳过:$detail")

                    TaskRpcFailureType.NON_RETRYABLE_INVALID ->
                        Log.member("商家服务🏬[$scene]#参数无效，跳过:$detail")

                    TaskRpcFailureType.UNSUPPORTED_NO_CLOSURE ->
                        Log.member("商家服务🏬[$scene]#当前链路不支持自动闭环:$detail")

                    TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW ->
                        Log.member("商家服务🏬[$scene]#接口失败:$detail")
                }
            }
        }

        private fun merchantTaskFailureResult(
            item: TaskFlowItem,
            rpc: String,
            response: JSONObject,
            evaluation: MerchantRpcEvaluation = evaluateMerchantRpc(response),
            actionCode: String = ""
        ): TaskFlowActionResult {
            val failureType = when (evaluation.failureType) {
                MerchantRpcFailureType.DUPLICATE_REWARD -> TaskRpcFailureType.TERMINAL_DONE
                MerchantRpcFailureType.AUTH_LIMIT -> TaskRpcFailureType.BUSINESS_LIMIT
                MerchantRpcFailureType.NO_ACTIVITY -> TaskRpcFailureType.BUSINESS_LIMIT
                MerchantRpcFailureType.NON_RETRYABLE,
                null -> classifyMerchantTaskFailure(evaluation.code, evaluation.message, response)
            }
            return TaskFlowActionResult.failure(
                failureType = failureType,
                code = evaluation.code,
                message = evaluation.message.ifBlank { buildMerchantRpcFailureDetail(evaluation, response) },
                rpc = rpc,
                raw = response.toString(),
                detail = merchantTaskActionDetail(item, actionCode.ifBlank { rpc.substringAfterLast('.') }),
                stopCurrentRound = failureType == TaskRpcFailureType.RETRYABLE_RPC
            )
        }

        private fun receiveMerchantPointBallResult(
            pointBallId: String,
            title: String,
            reward: String
        ): TaskFlowActionResult {
            val response = JSONObject(AntMemberRpcCall.ballReceive(pointBallId))
            val evaluation = evaluateMerchantRpc(response)
            if (!evaluation.success) {
                return TaskFlowActionResult.failure(
                    failureType = if (evaluation.failureType == MerchantRpcFailureType.DUPLICATE_REWARD) {
                        TaskRpcFailureType.TERMINAL_DONE
                    } else {
                        classifyMerchantTaskFailure(evaluation.code, evaluation.message, response)
                    },
                    code = evaluation.code,
                    message = evaluation.message.ifBlank { buildMerchantRpcFailureDetail(evaluation, response) },
                    rpc = "AntMemberRpcCall.ballReceive",
                    raw = response.toString(),
                    detail = "pointBallId=$pointBallId taskName=$title reward=${reward.ifBlank { "UNKNOWN" }}"
                )
            }
            val pointReceived = response.optJSONObject("data")?.optString("pointReceived").orEmpty()
            if (pointReceived.isNotEmpty()) {
                Log.member("商家服务🏬[$title]#领取积分$pointReceived")
            } else if (reward.isNotEmpty()) {
                Log.member("商家服务🏬[$title]#领取积分$reward")
            } else {
                Log.member("商家服务🏬[$title]#领取积分")
            }
            return TaskFlowActionResult.success()
        }

        private fun classifyMerchantTaskFailure(
            code: String,
            message: String,
            responseObject: JSONObject
        ): TaskRpcFailureType {
            val desc = responseObject.optString("desc")
            val resultView = responseObject.optString("resultView")
            return when {
                message in setOf(
                    "任务已领取,无法重复领取",
                    "宝箱奖励已领取",
                    "任务已领取",
                    "奖励已领取",
                    "已领取",
                    "已完成",
                    "已报名",
                    "已经报名"
                ) -> TaskRpcFailureType.TERMINAL_DONE

                code == "400000040" -> TaskRpcFailureType.UNSUPPORTED_NO_CLOSURE

                code in setOf("20020012", "TASK_ID_INVALID", "ILLEGAL_ARGUMENT", "PROMISE_TEMPLATE_NOT_EXIST") ->
                    TaskRpcFailureType.NON_RETRYABLE_INVALID

                code in setOf("3000", "1009", "I07", "REMOTE_INVOKE_EXCEPTION", "OP_REPEAT_CHECK", "SYSTEM_BUSY", "NETWORK_ERROR") ->
                    TaskRpcFailureType.RETRYABLE_RPC

                code.startsWith("100010") ||
                    code.contains("LIMIT", ignoreCase = true) ||
                    code == "NOT_PROMO_RULE_QUALIFIED" ||
                    message in setOf("訪問被拒絕", "访问被拒绝") ||
                    desc in setOf("訪問被拒絕", "访问被拒绝") ||
                    resultView in setOf("訪問被拒絕", "访问被拒绝") ->
                    TaskRpcFailureType.BUSINESS_LIMIT

                else -> TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW
            }
        }

        private fun buildMerchantTaskFlowKey(item: TaskFlowItem): String {
            return item.id.ifBlank {
                item.raw?.optString("pointBallId").orEmpty().ifBlank { item.title }
            }
        }

        private fun merchantTaskActionDetail(item: TaskFlowItem, action: String): String {
            return "taskCode=${item.type.ifBlank { "UNKNOWN" }} taskName=${item.title.ifBlank { "UNKNOWN" }} " +
                "status=${item.status.ifBlank { "UNKNOWN" }} action=$action " +
                "actionType=${item.actionType.ifBlank { "UNKNOWN" }} progress=${item.progress.ifBlank { "UNKNOWN" }}"
        }

        private fun extractMerchantTaskCurrent(task: JSONObject): Int? {
            val current = task.optInt("current", Int.MIN_VALUE)
            if (current != Int.MIN_VALUE) {
                return current
            }
            val currentCount = task.optInt("currentCount", Int.MIN_VALUE)
            return currentCount.takeIf { it != Int.MIN_VALUE }
        }

        private fun extractMerchantTaskLimit(task: JSONObject): Int? {
            val target = task.optInt("target", Int.MIN_VALUE)
            if (target != Int.MIN_VALUE) {
                return target
            }
            val targetCount = task.optInt("targetCount", Int.MIN_VALUE)
            return targetCount.takeIf { it != Int.MIN_VALUE }
        }

        private fun buildMerchantTaskProgress(task: JSONObject, current: Int?, limit: Int?): String {
            val reward = task.optString("reward", task.optString("point"))
            val progress = if (current != null && limit != null && limit > 0) {
                "$current/$limit"
            } else {
                ""
            }
            return listOf(
                progress.takeIf { it.isNotBlank() }?.let { "progress=$it" },
                reward.takeIf { it.isNotBlank() }?.let { "reward=$it" }
            ).filterNotNull().joinToString(" ")
        }

        private fun canRunMerchantService(): Boolean = CoroutineUtils.run {
            try {
                val jo = JSONObject(AntMemberRpcCall.transcodeCheck())
                val evaluation = evaluateMerchantRpc(jo)
                if (evaluation.success) {
                    val data = jo.optJSONObject("data")
                    if (data?.optBoolean("isOpened") == true) {
                        return@run true
                    }
                    Log.member("商家服务🏬[未开通，本轮跳过]")
                    return@run false
                }
                logMerchantRpcFailure("开通检查", jo, evaluation)
            } catch (t: Throwable) {
                Log.printStackTrace(TAG, "canRunMerchantService err:", t)
            }
            false
        }

        private fun doMerchantZcjSignIn(): Boolean = CoroutineUtils.run {
            try {
                val queryResp = JSONObject(AntMemberRpcCall.zcjSignInQuery())
                if (isMemberMarketingRpcRisk("AntMember.merchant.zcjSignInQuery", queryResp)) {
                    return@run false
                }
                if (!ResChecker.checkRes(TAG, queryResp)) {
                    return@run false
                }
                val button = queryResp.optJSONObject("data")?.optJSONObject("button") ?: return@run false
                when (button.optString("status")) {
                    "RECEIVED" -> return@run true
                    "UNRECEIVED" -> {
                        val executeResp = JSONObject(AntMemberRpcCall.zcjSignInExecute())
                        if (isMemberMarketingRpcRisk("AntMember.merchant.zcjSignInExecute", executeResp)) {
                            return@run false
                        }
                        if (!ResChecker.checkRes(TAG, executeResp)) {
                            Log.member("doMerchantZcjSignIn err:$executeResp")
                            return@run false
                        }
                        val data = executeResp.optJSONObject("data")
                        val reward = data?.optString("todayReward").orEmpty()
                        val widgetName = data?.optString("widgetName").orEmpty().ifEmpty { "招财金签到" }
                        if (reward.isNotEmpty()) {
                            Log.member("商家服务🏬[$widgetName]#获得积分$reward")
                        } else {
                            Log.member("商家服务🏬[$widgetName]")
                        }
                        return@run true
                    }
                }
            } catch (t: Throwable) {
                Log.printStackTrace(TAG, "doMerchantZcjSignIn err:", t)
            }
            false
        }

        private fun resolveMerchantBizId(task: JSONObject): String {
            return task.optJSONObject("extendLog")
                ?.optJSONObject("bizExtMap")
                ?.optString("bizId")
                .orEmpty()
        }

        private fun resolveMerchantActionCodes(task: JSONObject): List<String> {
            if (task.optString("taskCode") == "ZFYLLLRW_TASK") return listOf("ZFYLLLSJ_VIEWED")
            val candidates = LinkedHashSet<String>()
            val buttonActionCode = task.optJSONObject("button")
                ?.optJSONObject("extInfo")
                ?.optString("actionCode")
                .orEmpty()
            addMerchantActionCodeCandidates(candidates, buttonActionCode)

            val taskActionCode = task.optString("actionCode")
            addMerchantActionCodeCandidates(candidates, taskActionCode)

            val taskCode = task.optString("taskCode")
            if (task.has("sendPointImmediately") && taskCode.isNotEmpty()) {
                addMerchantActionCodeCandidate(candidates, "${taskCode}_VIEWED")
            }
            addMerchantActionCodeCandidate(candidates, when (taskCode) {
                "SYH_CPC_DYNAMIC" -> "SYH_CPC_DYNAMIC_VIEWED"
                "JFLLRW_TASK" -> "JFLL_VIEWED"
                "ZFBHYLLRW_TASK" -> "ZFBHYLL_VIEWED"
                "QQKLLRW_TASK" -> "QQKLL_VIEWED"
                "RCR_RWZX_LLRW_TASK" -> "rcr_llrw_VIEWED"
                "SSLLRW_TASK" -> "SSLL_VIEWED"
                "CYLLRW_TASK" -> "CYLLRW_VIEWED"
                "ELMGYLLRW2_TASK" -> "ELMGYLL_VIEWED"
                "ZMXYLLRW_TASK" -> "ZMXYLL_VIEWED"
                "GXYKPDDYH_TASK" -> "xykhkzd_VIEWED"
                "HHKLLRW_TASK" -> "HHKLLX_VIEWED"
                "TBNCLLRW_TASK" -> "TBNCLLRW_TASK_VIEWED"
                else -> null
            })
            return candidates.toList()
        }

        private fun addMerchantActionCodeCandidates(candidates: LinkedHashSet<String>, actionCode: String?) {
            val normalizedActionCode = actionCode.orEmpty().trim()
            if (normalizedActionCode.isEmpty()) {
                return
            }
            candidates.add(normalizedActionCode)
            if (!normalizedActionCode.endsWith("_VIEWED")) {
                candidates.add("${normalizedActionCode}_VIEWED")
            }
        }

        private fun addMerchantActionCodeCandidate(candidates: LinkedHashSet<String>, actionCode: String?) {
            val normalizedActionCode = actionCode.orEmpty().trim()
            if (normalizedActionCode.isNotEmpty()) {
                candidates.add(normalizedActionCode)
            }
        }

        private suspend fun collectMerchantPointBalls(): Boolean = CoroutineUtils.run {
            try {
                val jo = JSONObject(AntMemberRpcCall.merchantBallQuery())
                val evaluation = evaluateMerchantRpc(jo)
                if (!evaluation.success) {
                    logMerchantRpcFailure("查询积分球", jo, evaluation)
                    return@run false
                }
                val pointBalls = jo.optJSONObject("data")?.optJSONArray("pointBalls") ?: return@run false
                var received = false
                for (i in 0..<pointBalls.length()) {
                    val pointBall = pointBalls.optJSONObject(i) ?: continue
                    val ballId = pointBall.optString("id")
                    if (ballId.isEmpty()) {
                        continue
                    }
                    val ballName = pointBall.optString("name", "积分球")
                    val receiveResp = JSONObject(AntMemberRpcCall.ballReceive(ballId))
                    val receiveEvaluation = evaluateMerchantRpc(receiveResp)
                    if (!receiveEvaluation.success) {
                        logMerchantRpcFailure("领取积分球[$ballName]", receiveResp, receiveEvaluation)
                        continue
                    }
                    val pointReceived = receiveResp.optJSONObject("data")?.optString("pointReceived").orEmpty()
                    if (pointReceived.isNotEmpty()) {
                        Log.member("商家服务🏬领取[$ballName]#获得积分$pointReceived")
                    } else {
                        Log.member("商家服务🏬领取[$ballName]")
                    }
                    received = true
                }
                return@run received
            } catch (t: Throwable) {
                Log.printStackTrace(TAG, "collectMerchantPointBalls err:", t)
            }
            false
        }
    }

}
